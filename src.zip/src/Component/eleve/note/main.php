<div class="container justify-center items-center  md:flex-row">
    <div class="py-4 my-4 text-center">
        <span class="text-3xl  font-semibold text-blue-500 px-2 "> RELEVE DE NOTES PREMIERE SEQUENCE</span>
    </div>
    <div class="py-4 flex flex-row space-x-20 w-auto  my-4 bg-transparent border-2 border-blue-500 text-white ">
                    <div class="mb-8 space-y-4 ">
                            <p><span class="text-lg px-4 mb-2 font-normal">Nom:</span> [Nom de l'élève]</p>
                            <p><span class="text-lg px-4 mb-2 font-normal">Prenom:</span> [Prenom de l'élève]</p>
                            <p><span class="text-lg px-4 mb-2 font-normal">Matricule:</span> [Matricule]</p>
                    </div>
                    
                    <div class="mb-8 space-y-4 justify-end items-end">
                            <p><span class="text-lg ">Professeur Titulaire:</span>[Nom du Professeur] </p>
                            <p><span class="text-lg ">Classe:</span> [Classe] </p>
                            <p><span class="text-lg ">Effectif:</span> [Effectif] </p>
                     </div>   
                  
    </div>
    <div class="overflow-x-auto overflow-y-auto border-2 border-blue-500">
            <table class="min-w-full divide-y divide-gray-200 table-auto">
                <thead class="bg-white dark:bg-gray-800 text-white w-full mx-auto">
                    <tr>
                        <th class="px-8 mx-0 py-2 w-full">Matière</th>
                        <th class="px-8 mx-0 py-2 w-full">Controle Continu</th>
                        <th class="px-8 mx-0 py-2 w-full">Sequence</th>
                        <th class="px-8 mx-0 py-2 w-full">coef</th>
                        <th class="px-8 mx-0 py-2 w-full">Total</th>
                        <th class="px-8 mx-0 py-2 w-full">Appréciation</th>
                        <th class="px-8 mx-0 py-2 w-full">Enseignant</th>
                     
                    </tr>
                </thead>
                <tbody class="text-white">
                    <tr>
                        <td class="px-8 text-center py-2">[Nom de la matière]</td>
                        <td class="px-8 text-center py-2">[note]</td>
                        <td class="px-8 text-center py-2">[note]</td>
                        <td class="px-8 text-center py-2">[coef]</td>
                        <td class="px-8 text-center py-2">[Total]</td>
                       
                        <td class="px-8 text-center py-2">[Appréciation]</td>
                        <td class="px-8 text-center py-2">[Enseignant]</td>
                        
                    </tr>
                    <!-- Répétez cette ligne pour chaque matière -->
                </tbody>
            </table>
        </div>
        <div class="flex flex-row w-full my-4">
           
            <div class="">
            
            <p class="text-lg px-4 mb-2 font-normal text-gray-300"><span>ToTal Coefficient:</span>[Total] </p>
            <p class="text-lg px-4 mb-2 font-normal text-gray-300"><span>Total des points: </span>[Total]</p>
            <p class="text-lg px-4 mb-2 font-normal text-gray-300"><span>Moyenne Générale de la Classe:</span> [Moyenne Générale]</p>
            </div>
            <div class="mx-36">
            <p class="text-lg px-4 mb-2  text-gray-300"><span>Moyenne Sequentielle:</span>[moyenne] </p>
            <p class="text-lg px-4 mb-2 font-normal text-gray-300"><span>Rang Sequentielle: </span>[rang]</p>
            <p class="text-lg px-4 mb-2 font-normal text-gray-300"><spa>Appreciation:</span>[Appreciation]</p>
            
          </div>
        
        </div>
        
    </div>



        
</div>
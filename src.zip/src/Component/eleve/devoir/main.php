<!-- Start block -->


<!-- Start block -->
<?php
        require_once "../../Traitement/connexion.php";

        $slmt = $conn->prepare("SELECT * FROM devoir");
        $slmt->execute();
        $devoir=$slmt->fetchAll(PDO::FETCH_ASSOC);

        

?>
<div class="mx-12 w-auto overflow-x-hidden justify-center items-center left-0 top-0 py-4 lg:px-4 scrollable-modal">
        <!-- Start coding here -->
        <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
           
           
            <div class=" py-6 overflow-x-hidden justify-center items-center space-y-4">
                <span class="text-2xl text-blue-500 text-center font-semibold mx-auto py-6">Consulter Mes Devoirs</span>
                <table class="w-full overflow-x-hidden overflow-y-auto text-sm text-center text-gray-500  dark:text-gray-400">
                    <thead class="text-xs overflow-x-hidden text-gray-700 bg-gray-50 dark:bg-gray-700 px-16 dark:text-gray-400">
                        <tr>
                            
                            <th scope="col" class="px-8 py-3">Matiere</th>
                            <th scope="col" class="px-8 py-3">Libelle</th>
                            <th scope="col" class="px-8 py-3">Professeur</th>
                            <th scope="col" class="px-8 py-3">Contenu</th>
                            <th scope="col" class="px-8 py-3">Piece Jointe</th>
                            <th scope="col" class="px-8 py-3">date</th>
                            <th scope="col" class="px-8 py-3">
                                <span class="">Actions</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="overflow-y-auto overflow-x-hidden">
                        <?php foreach($devoir as $dev):?>
                            <?php 
                            $ens = $conn->prepare("SELECT * FROM employe WHERE matricule = :id_ens");
                            $ens->bindParam(":id_ens", $dev['id_ens']);
                            $ens->execute();
                            $enseignant = $ens->fetchAll(PDO::FETCH_ASSOC);

                            $piecejointeText = !empty($dev['piece_jointe'])
                            ? '<p class="mt-2"><a href="../../Traitement/enseignant/devoir/upload/' . htmlspecialchars($dev['piece_jointe']) . '" target="_blank" class="text-blue-600 hover:underline">Télécharger la pièce jointe</a></p>'
                            : '<p class="mt-2 text-gray-500">Pas de pièce jointe.</p>'
                            ?>
                        <tr class="border-b dark:border-gray-700  " >
                           
                            <td cla+ss="px-4 text-center max-w-[16rem] truncate py-2 "><?php echo htmlspecialchars($dev['nom_mat']); ?></td>
                            <td class="px-4 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($dev['titre']); ?></td>
                            <?php foreach($enseignant as $ens): ?>
                            <td class="px-4 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($ens['nom']); ?></td>
                            <?php endforeach; ?>
                            <td class="px-4 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($dev['contenu']); ?></td>
                            <td class="px-4 text-center max-w-[16rem] truncate py-2"><?php echo $piecejointeText; ?></td>
    
                            <td class="px-4 text-center max-w-[16rem]  py-2"><?php echo htmlspecialchars($dev['date']); ?></td>
                            <td class="px-4 text-center py-2 flex items-center justify-end space-x-3">
                            <a href="devoir/repondre.php" class="text-blue-500 max-w-[16rem]  text-center font-medium"><button>Repondre</button></a>
                            <a onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce devoir ?');"href="devoir/supp.php?id=<?php echo htmlspecialchars($dev['code_dev']);?>" class="text-red-400 max-w-[16rem]  text-center font-medium"><button>Supprimer</button></a>
                            </td>
             
                        </tr>
                        <?php endforeach;?>
                        
           
                    </tbody>
                </table>
            </div>
            
        </div>
   

<!-- End block -->
<!-- Create modal -->


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>repondre a un Devoir</title>
    <style>
        body {
            background-image: url("../../../../Assets/back1.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>

<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-2xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Reponse au Devoir
                </div>
                
                <div class="card-content">
                    <form action="" method="post" enctype="multipart/form-data" class="space-y-4">
                        <div>
                            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu</label>
                            <textarea id="contenu" name="contenu" rows="4" 
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900"></textarea>
                        </div>
                        <div>
                            <label for="piecejointe" class="block text-sm font-medium text-gray-700">Pièce Jointe</label>
                            <input type="file" id="piecejointe" name="piecejointe" accept=".pdf,.doc,.docx,.jpg,.png"
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900" >
                        </div>
                        <div>
                            <button type="submit"
                                class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center">
                                Envoyer la reponse
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <a href="../devoir.php" class="text-blue-500 hover:text-blue-700">Retour</a>
                </div>
            </div>
        </div>
    </section>

</body>

</html>

<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['eleve'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: connexion.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$eleve = $_SESSION['eleve'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../Style/style.css">
    <title>Communique</title>
</head>
<body class="bg-white dark:bg-gray-800 overflow-hidden left-0 top-0 justify-center items-center">
    <nav><?php require "communique/navbar.php"; ?></nav>

    <section class="flex flex-row">
        <div class="overflow-hidden"><?php require "communique/sidebar.php"; ?></div>
        <div class="overflow-y-auto w-full max-h-screen"><?php require "communique/main.php"; ?></div>
    </section>

    <script src="../../JS/sidebar.js"></script>
    <script src="../../JS/navbar.js"></script>
</body>
</html>

<div class="w-full max-w-2xl pb-2 justify-center items-center  mx-8 my-6  border border-blue-500 rounded shadow hover:bg-gray-100 dark:bg-gray-800  dark:hover:bg-gray-700  overflow-hidden">
    <div class=" w-full  justify-between items-center ">
        <div class="flex flex-col items-center justify-center">
           <h4 class="text-center items-center justify-center py-4 text-2xl font-bold text-blue-500 ">College JEAN XXIII D'EFOK</h4>
           <h2 class="text-xl text-center  font-medium text-white ">Compte Eleve</h2>
        
        </div>
        
    </div>
    <div class="mx-8">
       
      <div class="flex flex-row space-x-14">
      <div class="mb-2 ">
              <label class="block text-gray-200 text-xl font-medium mb-2" for="email">Matricule </label>
              <p id="email" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['code_elev']); ?><?php echo htmlspecialchars($eleve['id']); ?></p>
          </div>
          <div class="mb-2">
              <label class="block text-gray-200 text-xl font-medium mb-2" for="email">Nom </label>
              <p id="email" class="text-blue-300 text-lg ">  <?php echo htmlspecialchars($eleve['nom_elev']); ?> </p>
          </div>
          <div class="mb-2">
              <label class="block text-gray-200 text-xl font-medium mb-2" for="email">Prenom </label>
              <p id="email" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['prenom_elev']); ?> </p>
          </div>
      </div>
      <div class="flex flex-row space-x-14">
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Telephone</label>
            <p id="telephone" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['telephone']); ?></p>
        </div>
           
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Nationalité</label>
            <p id="telephone" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['nationalite']); ?></p>
        </div>
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Sexe</label>
            <p id="telephone" class="text-blue-300 text-lg"><?php echo htmlspecialchars($eleve['sexe_elev']); ?></p>
        </div>
      </div>
      <div class="flex flex-row space-x-14">
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Date de Naissance</label>
            <p id="telephone" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['date_naiss']); ?></p>
        </div>
           
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Lieu de Naissance</label>
            <p id="telephone" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['lieu_naiss']); ?></p>
        </div>
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="email">Classe</label>
            <p id="email" class="text-blue-300 text-lg "><?php echo htmlspecialchars($eleve['classe']); ?></p>
        </div>
      </div>
      <div class="flex flex-row space-x-14">
      <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Nom du pere</label>
            <p id="telephone" class="text-blue-300 text-lg"><?php echo htmlspecialchars($eleve['nom_pere']); ?></p>
        </div>
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Nom de la mere</label>
            <p id="telephone" class="text-blue-300 text-lg"><?php echo htmlspecialchars($eleve['nom_mere']); ?></p>
        </div>
        <div class="mb-2">
            <label class="block text-gray-200 text-xl font-medium mb-2" for="telephone">Categorie</label>
            <p id="telephone" class="text-blue-300 text-lg"><?php echo htmlspecialchars($eleve['categorie']); ?></p>
        </div>
          
      </div>
      <div class="flex flex-row space-x-14">
                   
        
       
        </div>
        <small class="text-xm py-2 text-left text-blue-500">Nous assurons une confidentialite des informations de ce compte</small>
    </div>

    
</div>

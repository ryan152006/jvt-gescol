<!-- About Us Page -->

<!-- Header -->
<div class="bg-blue-600 p-2 space-x-8 justify-center items-center text-center flex flex-row w-full">
    <span class="sm:text-xm md:text-lg lg:text-xl dark:text-white">À propos de JVT-GESCOL</span>
    <img src="../../Assets/logo.png" class="h-14 rounded-full" alt="Logo JVT-GESCOL" />
</div>

<!-- Main Content -->
<div class="p-2 mx-auto">
    <!-- Description -->
    <div class="my-2">
        <h2 class="sm:text-sm md:text-xm lg:text-lg text-blue-500 mb-2">Qui Sommes-Nous ?</h2>
        <p class="text-gray-300 sm:text-base md:text-sm lg:text-xm">
            JVT-GESCOL est une application de gestion complète pour établissements éducatifs. Notre objectif est de faciliter l'administration des établissements scolaires en centralisant et en optimisant les processus de gestion administrative, académique et financière.
        </p>
    </div>

    <!-- Fonctionnalités Clés -->
    <div class="my-2">
        <h2 class="sm:text-sm md:text-xm lg:text-lg text-blue-500 mb-2">Fonctionnalités Clés :</h2>
        <ul class="list-disc list-inside text-gray-300 sm:text-base md:text-sm lg:text-xm">
            <li>Gestion des inscriptions et des admissions</li>
            <li>Suivi des performances académiques des étudiants</li>
            <li>Gestion des emplois du temps et des salles de classe</li>
            <li>Administration des finances et des frais de scolarité</li>
            <li>Communication en temps réel avec les parents et les élèves</li>
            <li>Rapports et analyses détaillés pour une meilleure prise de décision</li>
        </ul>
    </div>
    <div class="my-2">
        <h2 class="sm:text-sm md:text-xm lg:text-lg text-blue-500 mb-2">Nos Valeurs :</h2>
        <ul class="list-disc list-inside text-gray-300 sm:text-base md:text-sm lg:text-xm">
            <li>Innovation : Nous intégrons les dernières technologies pour offrir des solutions modernes et efficaces.</li>
            <li>Accessibilité : Nous veillons à ce que nos outils soient accessibles et intuitifs pour tous les utilisateurs.</li>
            <li>Intégrité : Nous nous engageons à offrir des services honnêtes et fiables.</li>
            <li>Soutien : Notre équipe de support est disponible pour assister les établissements dans l'utilisation de notre application.</li>
        </ul>
    </div>

    <!-- Notre Équipe -->
    <div class="my-2">
        <h2 class="sm:text-sm md:text-xm lg:text-lg text-blue-500 mb-2">Notre Équipe</h2>
        <p class="text-gray-300 sm:text-base md:text-sm lg:text-xm">
            Notre équipe est composée de professionnels expérimentés en gestion éducative et en développement technologique. Nous sommes dédiés à fournir un service de qualité et à aider les établissements à atteindre leurs objectifs éducatifs et administratifs.
        </p>
    </div>
    <p class="text-gray-200 text-sm text-center">© <?php echo date("Y") ?> JVT-GESCOL. Tous droits réservés.</p>
</div>

<div class="flex flex-col rtl:space-x-reverse  md:flex-row mx-14 items-center  justify-center py-14">

    <div class="block mx-6 w-full flex flex-col rounded-lg max-w-sm p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700 dark:hover:bg-gray-700">
        <div>
            <h4 class="text-center text-xl font-normal text-white ">Localisation </h4>
            <span class="text-blue-500 text-center text-2xl font-bold">EFok-Obala</span>
        </div>
    </div>

    <div class="block mx-6 w-full flex flex-col rounded-lg max-w-sm p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700 dark:hover:bg-gray-700">
        <div>
            <h4 class="text-center text-xl font-normal text-white ">Numero de Telephone</h4>

            <span class="text-blue-500 text-center text-2xl font-bold">677600537/672220030 </span>
        </div>
    </div>

    
    <div class="block flex flex-col mx-6 w-full rounded-lg max-w-sm p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700  dark:hover:bg-gray-700">
            
        <div>
            <h4 class="text-center text-xl font-normal text-white ">Année Scolaire</h4>
            <span class="text-blue-500 text-center text-2xl font-bold"><?php echo date("Y") ?>/<?php echo date("Y")+1 ?></span>
        </div>
    </div>
</div>
<div class="flex flex-col justify-center items-center">
    <div class="flex flex-row space-x-4 uppercase mx-4 p-3">
        <svg width="800px" height="800px" class="w-10 h-10" viewBox="0 0 1024 1024" class="icon"  version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M965.282 186.746H62.449c-25.477 0-46.129 21.177-46.129 47.298v7.139c0 26.121 20.652 47.296 46.129 47.296h902.833c25.48 0 46.131-21.175 46.131-47.296v-7.139c0-26.121-20.65-47.298-46.131-47.298z" fill="#4A5699" /><path d="M965.282 821.697H62.449c-25.477 0-46.129 21.173-46.129 47.296v7.141c0 26.119 20.652 47.297 46.129 47.297h902.833c25.48 0 46.131-21.178 46.131-47.297v-7.141c0-26.123-20.65-47.296-46.131-47.296z" fill="#C45FA0" /><path d="M69.412 186.746H62.33c-26.121 0-47.294 21.177-47.294 47.298v642.09c0 26.119 21.173 47.297 47.294 47.297h7.082c26.121 0 47.294-21.178 47.294-47.297v-642.09c0.001-26.121-21.173-47.298-47.294-47.298zM964.117 186.746h-7.082c-26.119 0-47.296 21.177-47.296 47.298v642.09c0 26.119 21.177 47.297 47.296 47.297h7.082c26.122 0 47.296-21.178 47.296-47.297v-642.09c0-26.121-21.174-47.298-47.296-47.298z" fill="#F39A2B" /><path d="M426.617 435.818h-7.082c-26.121 0-47.296 21.171-47.296 47.294v38.715c0 26.119 21.175 47.296 47.296 47.296h7.082c26.121 0 47.298-21.177 47.298-47.296v-38.715c0-26.122-21.177-47.294-47.298-47.294zM601.912 435.818h-7.082c-26.118 0-47.292 21.171-47.292 47.294v38.715c0 26.119 21.174 47.296 47.292 47.296h7.082c26.119 0 47.3-21.177 47.3-47.296v-38.715c0-26.122-21.181-47.294-47.3-47.294zM777.211 435.818h-7.082c-26.122 0-47.296 21.171-47.296 47.294v38.715c0 26.119 21.174 47.296 47.296 47.296h7.082c26.119 0 47.292-21.177 47.292-47.296v-38.715c0-26.122-21.173-47.294-47.292-47.294zM777.211 611.22h-7.082c-26.122 0-47.296 21.17-47.296 47.293v38.716c0 26.115 21.174 47.293 47.296 47.293h7.082c26.119 0 47.292-21.178 47.292-47.293v-38.716c0-26.123-21.173-47.293-47.292-47.293zM601.912 611.22h-7.082c-26.118 0-47.292 21.17-47.292 47.293v38.716c0 26.115 21.174 47.293 47.292 47.293h7.082c26.119 0 47.3-21.178 47.3-47.293v-38.716c0-26.123-21.181-47.293-47.3-47.293zM426.617 611.22h-7.082c-26.121 0-47.296 21.17-47.296 47.293v38.716c0 26.115 21.175 47.293 47.296 47.293h7.082c26.121 0 47.298-21.178 47.298-47.293v-38.716c0-26.123-21.177-47.293-47.298-47.293zM251.32 611.22h-7.08c-26.123 0-47.294 21.17-47.294 47.293v38.716c0 26.115 21.171 47.293 47.294 47.293h7.08c26.123 0 47.294-21.178 47.294-47.293v-38.716c0-26.123-21.171-47.293-47.294-47.293z" fill="#E5594F" /><path d="M299.245 91.914h-7.435c-26.125 0-47.296 19.988-47.296 44.649V312.24c0 24.657 21.171 44.649 47.296 44.649h7.435c26.125 0 47.296-19.992 47.296-44.649V136.563c0-24.661-21.172-44.649-47.296-44.649zM719.956 91.914h-7.438c-26.118 0-47.292 19.988-47.292 44.649V312.24c0 24.657 21.174 44.649 47.292 44.649h7.438c26.123 0 47.296-19.992 47.296-44.649V136.563c0-24.661-21.173-44.649-47.296-44.649z" fill="#6277BA" /></svg>
        <span class="self-center font-normal text-3xl whitespace-nowrap text-blue-500 text-center items-center"><?php echo date("l"), " ". date("d-m-Y"); ?></span>
    </div>
   
    <span class="self-center font-normal text-2xl whitespace-nowrap dark:text-gray-200 mb-2 text-white text-center items-center"></span>
  
    <div  class="flex flex-row items-center space-x-3 rtl:space-x-reverse">
           
        <span class="self-center text-4xl font-normal uppercase dark:text-white">College <span class="text-blue-500">JEAN XXIII D'EFOK</span></span>
    </div>
    <p class="text-center uppercase text-gray-400 text-lg py-4">Verus et Sedulus</p>

    <div  class="flex flex-col justify-center items-center">
            <img src="../../Assets/logoecole.jpg" class="w-36 h-36 rounded-full" alt="">
    </div>
</div>

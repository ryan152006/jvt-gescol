<?php
require_once '../../../Traitement/connexion.php'; 

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = intval($_GET['id']); // Sécuriser l'entrée utilisateur
    
    try {
        // Préparer la requête pour supprimer le communiqué
        $sql = "DELETE FROM communique WHERE id = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            // Rediriger vers la page des communiqués après suppression
            header("Location: ../communique.php"); 
            exit();
        } else {
            echo "Erreur lors de la suppression.";
        }
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
} else {
    echo "ID invalide.";
}
?>

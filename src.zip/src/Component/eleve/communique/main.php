<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Communiqués</title>
   
</head>
<body class="bg-gray-100">
        <section class="flex flex-col min-h-screen p-4">
            <div class="w-full max-w-8xl mb-4 print-hidden">
            <?php
            require_once '../../Traitement/connexion.php'; // Assurez-vous que ce chemin est correct

            // Requête SQL pour obtenir tous les communiqués, triés par ID décroissant
            $sql = "SELECT id, titre, contenu, piecejointe FROM communique ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $communiques = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($communiques as $communique) {
                $alertClass = "border-blue-500 bg-transparent"; // Bordure bleue et fond transparent
                $cardWidth = "w-full max-w-8xl"; // Largeur des cartes augmentée
                
                $piecejointeText = !empty($communique['piecejointe'])
                    ? '<p class="mt-2"><a href="uploads/' . htmlspecialchars($communique['piecejointe']) . '" target="_blank" class="text-blue-600 hover:underline">Télécharger la pièce jointe</a></p>'
                    : '<p class="mt-2 text-gray-500">Pas de pièce jointe.</p>';
                
                echo '<div class="p-4 mb-4 communique communique-' . htmlspecialchars($communique['id']) . ' ' . $alertClass . ' border rounded-lg ' . $cardWidth . ' text-blue-800">';
                echo '<div class="flex items-center">';
                echo '<svg class="flex-shrink-0 w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">';
                echo '<path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>';
                echo '</svg>';
                echo '<h3 class="text-lg font-medium text-white">Communiqué </h3>';
                echo '</div>';
                echo '<div class="mt-2 mb-4 text-sm text-blue-500">';
                echo '<h2 class="text-xl font-semibold">' . htmlspecialchars($communique['titre']) . '</h2>';
                echo '<p class="mt-2 text-white">' . nl2br(htmlspecialchars($communique['contenu'])) . '</p>';
                echo $piecejointeText;
                echo '</div>';
                echo '<div class="text-right flex space-x-2">';
                ?>
                <a href="communique/supprimer.php?id=<?php echo $communique['id']; ?>" 
                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce communiqué ?');">
                    <button type="button" class="text-red-500 bg-transparent border border-red-800 hover:bg-red-500 hover:text-white focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded text-xs px-3 py-1.5 text-center">
                        Supprimer le communiqué
                    </button>
                </a>
               
                <?php
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>

        <!-- Ajoutez un espace supplémentaire en bas -->
        <div class="mt-auto mb-4 py-6 print-hidden"></div>
    </section>
</body>
</html>

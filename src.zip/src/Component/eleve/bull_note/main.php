
    <div id="trimestre" class="max-w-5xl mx-auto p-6 bg-white  my-2">
        <div class="flex items-center space-x-24 rtl:space-x-reverse mx-auto">
                <div class="flex items-center space-x-2 rtl:space-x-reverse">
                    <img src="../../Assets/logoecole.jpg" class="w-16 rounded-full h-16" alt="">
                    <span class="text-3xl uppercase font-semibold text-gray-700">College JEAN XXIII D'EFOK</span>
                </div>
                <div class="justify-end text-end items-end  mx-auto">
                    <span class="text-right">Annee Academique: <?php echo date("Y") ?>-<?php echo date("Y")+1 ?></span>
                </div>
        </div>
        
        <h1 class="text-2xl font-semibold uppercase mb-8 text-center text-gray-800">Bulletin de Notes du Premier Trimestre</h1>
        <div class="flex flex-row space-x-6 w-full">
            
                
                <div class="mb-8 space-y-4">
                    <p><span class="text-lg font-semibold">Nom:</span> [Nom de l'élève]</p>
                    <p><span class="text-lg font-semibold">Prenom:</span> [Prenom de l'élève]</p>
                    <p><span class="text-lg font-semibold">Matricule:</span> [Matricule]</p>
                  
                   
                </div>
        

                <div class="mb-8 space-y-4 text-left">
                    <p><span class="text-lg font-semibold">Professeur Titulaire:</span>[Nom du Professeur] </p>
                    <p><span class="text-lg font-semibold">Classe:</span> [Classe] </p>
                    <p><span class="text-lg font-semibold">Effectif:</span> [Effectif] </p>
                   
               
                </div>
        </div>
       
        <div class="overflow-x-auto overflow-y-auto">
            <table class="min-w-full divide-y divide-gray-200 table-auto">
                <thead class="bg-white dark:bg-gray-800 text-white w-full mx-auto">
                    <tr>
                        <th class="px-8 mx-0 py-2 w-full">Matière</th>
                        <th class="px-8 mx-0 py-2 w-full">Controle Continu</th>
                        <th class="px-8 mx-0 py-2 w-full">Sequence</th>
                        <th class="px-8 mx-0 py-2 w-full">coef</th>
                        <th class="px-8 mx-0 py-2 w-full">Total</th>
                        <th class="px-8 mx-0 py-2 w-full">Appréciation</th>
                        <th class="px-8 mx-0 py-2 w-full">Enseignant</th>
                     
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <tr>
                        <td class="px-8 text-center py-2">[Nom de la matière]</td>
                        <td class="px-8 text-center py-2">[note]</td>
                        <td class="px-8 text-center py-2">[note]</td>
                        <td class="px-8 text-center py-2">[coef]</td>
                        <td class="px-8 text-center py-2">[Total]</td>
                       
                        <td class="px-8 text-center py-2">[Appréciation]</td>
                        <td class="px-8 text-center py-2">[Enseignant]</td>
                        
                    </tr>
                    <!-- Répétez cette ligne pour chaque matière -->
                </tbody>
            </table>
        </div>
        <div class="flex flex-row w-full">
           
            <div class="mt-8 p-4 bg-gray-50 border-t border-gray-200">
            
            <p class="text-lg "><span class="font-semibold">ToTal Coefficient:</span>[Total] </p>
            <p class="text-lg"><span class="font-semibold">Total des points: </span>[Total]</p>
            <p class="text-lg"><span class="font-semibold">Moyenne Générale de la Classe:</span> [Moyenne Générale]</p>
            </div>
            <div class="mt-8 p-4 bg-gray-50 border-t border-gray-200">
            <p class="text-lg "><span class="font-semibold">Moyenne Sequentielle:</span>[moyenne] </p>
            <p class="text-lg"><span class="font-semibold">Rang Sequentielle: </span>[rang]</p>
            <p class="text-lg"><span class="font-semibold">Appreciation:</span>[Appreciation]</p>
            
          </div>
        
        </div>
        
    </div>



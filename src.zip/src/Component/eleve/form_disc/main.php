<?php
require_once '../../Traitement/connexion.php';

// Préparation de la requête SQL pour récupérer tous les règlements triés par ID croissant
$request = $conn->prepare("SELECT * FROM formulaire_disci ORDER BY id_form ASC");
$request->execute();
$regulations = $request->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="md:container md:mx-auto flex flex-col justify-content items-center py-8 px-8">
            <div class="border-2 border-blue-500 bg-transparent w-full 	place-content:center py-4 p-2">
                <p class="text-center text-2xl text-blue-500 font-semibold">Formulaire de Discipline du College JEAN XXIII d'EFOK</p>
            </div>
                <div class="text-blue-500 py-4">
                    Liste des Règlements
                </div>
                <div class="card-content">
                    <div class="space-y-2">
                        <?php if ($regulations) : ?>
                            <?php foreach ($regulations as $regulation) : ?>
                                <div class="border-b border-gray-300 pb-4 mb-4">
                                    <div class="text-lg font-medium text-blue-600">
                                        Article N<sup>o</sup><?php echo htmlspecialchars($regulation['id_form']); ?>: <?php echo htmlspecialchars($regulation['titre']); ?>
                                    </div>
                                    <div class="mt-1 text-sm text-white">
                                        <?php echo nl2br(htmlspecialchars($regulation['contenu'])); ?>
                                    </div>
                                </div>
                                   
                                
                              
                            <?php endforeach; ?>
                        <?php else : ?>
                           <p> Aucun reglement</p>
                        <?php endif; ?>
                        <div class="py-4 w-full">
    <h2 class="text-blue-500 font-semibold mb-2">Pièces Jointes</h2>
    <div class="flex flex-col items-center">
    <?php
            $stmt = $conn->prepare("SELECT * FROM piece_jointe");
            $stmt->execute();
            $pieces_jointes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>
        <?php foreach ($pieces_jointes as $piece) : ?>
            <div class="rounded p-4 mb-2 w-full max-w-md text-center">
                <?php

                // Déterminer le type d'icône à afficher en fonction de l'extension du fichier
                $fileExt = strtolower(pathinfo($piece['file_name'], PATHINFO_EXTENSION));
                $iconClass = '';

                switch ($fileExt) {
                    case 'pdf':
                        $iconClass = 'fas fa-file-pdf';
                        break;
                    case 'docx':
                        $iconClass = 'fas fa-file-word';
                        break;
                    case 'xlsx':
                        $iconClass = 'fas fa-file-excel';
                        break;
                    case 'pptx':
                        $iconClass = 'fas fa-file-powerpoint';
                        break;
                    default:
                        $iconClass = 'fas fa-file';
                        break;
                }
                ?>

                <?php if (strpos($piece['file_type'], 'image/') === 0) : ?>
                    <!-- Affichage de l'image si le type de fichier est une image -->
                    <img src="<?php echo htmlspecialchars($piece['file_path']); ?>" alt="<?php echo htmlspecialchars($piece['file_name']); ?>" class="max-w-full h-auto mb-2">
                <?php else : ?>
                    <!-- Affichage de l'icône et du nom du fichier pour les fichiers non image -->
                    <div class="mb-2 text-white text-3xl">
                        <i class="<?php echo htmlspecialchars($iconClass); ?>"></i>
                    </div>
                    <p class="mb-2 text-blue-500"><?php echo htmlspecialchars($piece['file_name']); ?></p>
                <?php endif; ?>

                <!-- Affichage du lien de téléchargement pour tous les fichiers -->
                <a href="<?php echo htmlspecialchars($piece['file_path']); ?>" download class="text-white hover:underline">Télécharger</a>
               
            </div>
        <?php endforeach; ?>
    </div>
</div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cahier de Texte</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex justify-center items-center min-h-screen">
        <div class="bg-white p-8 rounded shadow-md w-full max-w-5xl">
            <h1 class="text-3xl font-bold text-center text-blue-500 mb-8">Cahier de Texte</h1>

            <!-- Informations générales -->
            <div class="grid grid-cols-2 gap-8 mb-8">
                <!-- Date du jour actuel -->
                <div>
                    <label class="block text-lg font-medium text-gray-900">Date du jour</label>
                    <p class="mt-1 p-4 bg-gray-100 border border-gray-300 rounded text-gray-900">
                        <!-- Valeur dynamique -->
                        <?php echo date('d/m/Y'); ?>
                    </p>
                </div>

                <!-- Nom du professeur -->
                <div>
                    <label class="block text-lg font-medium text-gray-900">Nom du Professeur</label>
                    <p class="mt-1 p-4 bg-gray-100 border border-gray-300 rounded text-gray-900">
                        <!-- Valeur dynamique -->
                        <!-- Par exemple: -->
                        M. Dupont
                    </p>
                </div>

                <!-- Matière -->
                <div>
                    <label class="block text-lg font-medium text-gray-900">Matière</label>
                    <p class="mt-1 p-4 bg-gray-100 border border-gray-300 rounded text-gray-900">
                        <!-- Valeur dynamique -->
                        <!-- Par exemple: -->
                        Mathématiques
                    </p>
                </div>

                <!-- Classe -->
                <div>
                    <label class="block text-lg font-medium text-gray-900">Classe</label>
                    <p class="mt-1 p-4 bg-gray-100 border border-gray-300 rounded text-gray-900">
                        <!-- Valeur dynamique -->
                        <!-- Par exemple: -->
                        3ème B
                    </p>
                </div>

                <!-- Année académique -->
                <div>
                    <label class="block text-lg font-medium text-gray-900">Année Académique</label>
                    <p class="mt-1 p-4 bg-gray-100 border border-gray-300 rounded text-gray-900">
                        <!-- Valeur dynamique -->
                        <!-- Par exemple: -->
                        2023-2024
                    </p>
                </div>
            </div>

            <!-- Avancement du cours -->
            <div class="mb-8">
                <label for="avancement" class="block text-lg font-medium text-gray-900">Avancement du cours</label>
                <textarea id="avancement" name="avancement" rows="10" class="mt-1 p-4 block w-full bg-gray-50 border border-gray-300 rounded text-gray-900" placeholder="Détaillez l'avancement du cours..." required></textarea>
            </div>

            <!-- Bouton de soumission -->
            <div class="flex justify-center">
                <button type="submit" class="bg-blue-500 text-white font-bold py-3 px-6 rounded hover:bg-blue-600">
                    Enregistrer
                </button>
            </div>
        </div>
    </div>
</body>
</html>

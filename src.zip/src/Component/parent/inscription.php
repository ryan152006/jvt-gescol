<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../Style/categorie.css">
    <title>connexion</title>
</head>
<body>
<section class="flex flex-row justify-center items-center px-4">
      
      <div class="w-[450px] justify-center items-center my-2 bg-white rounded-lg shadow dark:border md:m sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
        
          <div class=" w-full space-y-2 md:space-y-2 sm:p-6 ">
            
            <div class=" ">
              <h1 class="text-xl flex items-center justify-center text-blue-500 font-medium  md:text-2xl ">
                S'Inscrire
            </h1>
           
            </div>
              
              <form class="space-y-4 md:space-y-6" action="#">
                <div>
                  <label for="Nom" class="block text-sm font-medium text-gray-900 dark:text-white">Nom</label>
                  <input type="text" name="nom" id="nom" placeholder="Entrer votre nom complet" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=>
                </div>
                <div>
                  <label for="email" class="block text-sm font-medium text-gray-900 dark:text-white">Email</label>
                  <input type="email" name="email" id="email" placeholder="Entrer votre email" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required=>
                </div>
                <div>
                  <label for="password" class="block text-sm font-medium text-gray-900 dark:text-white">Mot de Passe</label>
                  <input type="password" name="password" id="password" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Confirmer votre mot de passe" required>
                </div>
                <div>
                  <label for="passwordsecond" class="block text-sm font-medium text-gray-900 dark:text-white">Confirmer votre Mot de Passe</label>
                  <input type="password" name="passwordsecond" id="passwordsecond" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Confirmer votre mot de passe" required>
                </div>
                  <button type="submit" class="w-full  text-white bg-blue-500 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center  dark:hover:bg-primary-700 dark:focus:ring-primary-800">Inscription</button>
                  <small class="mb-6 text-white text-center py-2">Creer un compte parent ou  <a href="connexion.php" class="text-blue-400 underline text-right">Vous avez deja un compte?</a> ou <a href="../categorie.html" class="text-red-500 underline text-right">Retour</a></small>
                
                </form>
          </div>
         
      </div>
  

  </section>
<!---->
</body>
</html>
<?php
require_once '../../../Traitement/connexion.php';

$id = $_GET['id'] ?? null;
$row = null;

if ($id) {
    $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $id) {
    // Vérification des champs du formulaire
    if (isset($_POST["libelle"], $_POST["professeur"], $_POST["description"],
              $_POST["pension"], $_POST["inscription"], $_POST["tranche1"], $_POST["tranche2"], $_POST["tranche3"])) {

        // Récupération des données du formulaire
        $libelle = $_POST["libelle"];
        $professeur = $_POST["professeur"];
        $description = $_POST["description"];
        $pension = (float) $_POST["pension"];
        $inscription = (float) $_POST["inscription"];
        $tranche1 = (float) $_POST["tranche1"];
        $tranche2 = (float) $_POST["tranche2"];
        $tranche3 = (float) $_POST["tranche3"];

        // Mise à jour dans la base de données
        $update = $conn->prepare("UPDATE classe SET 
            nom_class = :libelle, 
            nom_enseig = :professeur, 
            description = :description, 
            pension = :pension, 
            inscription = :inscription, 
            tranche1 = :tranche1, 
            tranche2 = :tranche2, 
            tranche3 = :tranche3 
            WHERE id_class = :id");

        $update->bindParam(':libelle', $libelle);
        $update->bindParam(':professeur', $professeur);
        $update->bindParam(':description', $description);
        $update->bindParam(':pension', $pension);
        $update->bindParam(':inscription', $inscription);
        $update->bindParam(':tranche1', $tranche1);
        $update->bindParam(':tranche2', $tranche2);
        $update->bindParam(':tranche3', $tranche3);
        $update->bindParam(':id', $id, PDO::PARAM_INT);

        if ($update->execute()) {
            header("Location: ../classe.php"); // Redirection vers la liste des classes
            exit();
        } else {
            echo "<p>Erreur lors de la mise à jour de la classe.</p>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../Style/categorie.css">
    <title>Modifier Classe</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
        .input-field {
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 0.375rem; /* Rounded edges */
            transition: border-color 0.2s;
        }
        .input-field:focus {
            border-color: #60a5fa; /* Blue color on focus */
            outline: none; /* Remove outline */
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-4xl bg-white rounded-lg shadow-md">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Modifier les Informations de Classe
                </h1>
                <?php if ($row) : ?>
                    <form method="post">
                        <!-- Informations sur la Classe -->
                        <fieldset class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                            <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations sur la Classe</legend>
                            <div class="flex flex-col">
                                <label for="libelle" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Libellé</label>
                                <input type="text" name="libelle" id="libelle" placeholder="Ex: Mathématiques" value="<?= htmlspecialchars($row['nom_class']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col">
                                <label for="professeur" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Professeur</label>
                                <input type="text" name="professeur" id="professeur" placeholder="Ex: M. Dupont" value="<?= htmlspecialchars($row['nom_enseig']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col md:col-span-2">
                                <label for="description" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Description</label>
                                <textarea name="description" id="description" placeholder="Ex: Classe dédiée aux cours de mathématiques avancés" class="input-field w-full"><?= htmlspecialchars($row['description']) ?></textarea>
                            </div>
                        </fieldset>

                        <!-- Informations Financières -->
                        <fieldset class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mt-6">
                            <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Financières</legend>
                            <div class="flex flex-col">
                                <label for="pension" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Montant de la Pension</label>
                                <input type="number" name="pension" id="pension" placeholder="Ex: 500" value="<?= htmlspecialchars($row['pension']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col">
                                <label for="inscription" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Montant de l'Inscription</label>
                                <input type="number" name="inscription" id="inscription" placeholder="Ex: 100" value="<?= htmlspecialchars($row['inscription']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col">
                                <label for="tranche1" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Tranche 1</label>
                                <input type="number" name="tranche1" id="tranche1" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche1']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col">
                                <label for="tranche2" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Tranche 2</label>
                                <input type="number" name="tranche2" id="tranche2" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche2']) ?>" required class="input-field w-full">
                            </div>
                            <div class="flex flex-col">
                                <label for="tranche3" class="block text-sm font-normal text-gray-800 dark:text-gray-200">Tranche 3</label>
                                <input type="number" name="tranche3" id="tranche3" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche3']) ?>" required class="input-field w-full">
                            </div>
                        </fieldset>

                        <!-- Boutons -->
                        <div class="flex justify-between items-center mt-4">
                            <button type="submit" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none font-normal rounded text-lg px-6 py-2">Enregistrer</button>
                            <a href="../classe.php" class="text-white bg-gray-500 hover:bg-gray-600 font-normal rounded text-lg px-6 py-2">Retour</a>
                        </div>
                    </form>
                <?php else : ?>
                    <p>Aucune classe trouvée avec cet ID.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</body>
</html>

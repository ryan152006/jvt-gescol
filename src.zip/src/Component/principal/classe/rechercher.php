<?php
require '../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT * FROM classe
          WHERE nom_class LIKE :search  ORDER BY nom_class ";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="mx-auto w-full md:w-auto overflow-x-auto justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-auto justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-xl md:text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4">Résultats de la Recherche</span>
            <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                    <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-8 py-3">Libelle</th>
                            <th scope="col" class="px-8 py-3">Effectif</th>
                            <th scope="col" class="px-8 py-3">Prof titulaire</th>
                            <th scope="col" class="px-8 py-3">Description</th>
                            <th scope="col" class="px-8 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="overflow-y-auto overflow-x-auto">
                        <?php foreach ($classes as $classe): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['nom_class']); ?></td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"> <?php
  

  // Préparer et exécuter la requête
  // Préparer et exécuter la requête
$sltm = $conn->prepare("SELECT COUNT(id) AS total FROM eleve WHERE id_class = :id_class");
$sltm->bindParam(":id_class", $classe['id_class']);
$sltm->execute();

// Récupérer le résultat
$count = $sltm->fetch(PDO::FETCH_ASSOC);

// Afficher le nombre total d'ID    
echo $count['total'];

?> </td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['nom_enseig']); ?></td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['description']); ?></td>
                            <td class="px-8 text-center py-2 flex items-center justify-end space-x-3">
                                <a href="classe/modifier.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-green-500 text-center font-medium">
                                    <button>Modifier</button>
                                </a>
                                <a href="classe/consulter.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-blue-500 text-center font-medium">
                                    <button>Consulter</button>
                                </a>
                                <a href="../../Traitement/principal/classe/delete.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-red-400 text-center font-medium">
                                    <button>Supprimer</button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>

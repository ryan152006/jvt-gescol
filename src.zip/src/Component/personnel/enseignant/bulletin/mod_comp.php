<?php
require_once 'Models/Database.php';
require_once 'Models/evaluation.php';
require_once 'Models/groupe.php';
require_once 'Models/matiere.php';
require_once 'Models/competence.php';

session_start();

// Récupérer les données de session
$id_class = $_GET['id_class'] ?? null;
$id_evaluation = $_GET['id_evaluation'] ?? null;
$id_annee = $_SESSION['id_annee'] ?? null;
$id_tri = $_GET['id_tri'] ?? null;

$evaluation = new Evaluation();
$eva = $evaluation->read();

try {
    // Créer une instance de la base de données
    $db = new Database();
    $connection = $db->getConnection();

    // Vérifier si la connexion est établie
    if (!$connection) {
        throw new Exception("Connexion à la base de données échouée.");
    }

    // Vérifier si un ID de compétence est passé dans l'URL et s'il est valide
    if (isset($_GET['id_comp']) && is_numeric($_GET['id_comp'])) {
        $id_comp = $_GET['id_comp'];

        // Récupérer les informations de la compétence à modifier
        $sql = "SELECT * FROM competence WHERE id_comp = :id_comp";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':id_comp', $id_comp, PDO::PARAM_INT);
        $stmt->execute();
        $competence = $stmt->fetch(PDO::FETCH_ASSOC);

        // Si aucune compétence n'est trouvée
        if (!$competence) {
            echo "Aucune compétence trouvée avec cet ID.";
            exit;
        }
        
        // Récupérer le code de la matière à partir de la compétence
        $code_mat = $competence['code_mat'];
        
        // Selectionner le nom de la matière avec le code_mat
        $sql = "SELECT nom_matiere FROM matiere WHERE code_mat = :code_mat"; 
        $stmt = $connection->prepare($sql);
        $stmt->execute([':code_mat' => $code_mat]);
        $matiere = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$matiere) {
            echo "Matière introuvée.";
            exit;
        }

        // Récupérer le nom de la matière
        $nom_matiere = isset($matiere['nom_matiere']) ? $matiere['nom_matiere'] : '';

    } else {
        echo "ID de compétence invalide.";
        exit;
    }

    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modifier'])) {
        // Récupérer les nouvelles valeurs du formulaire
        $code_mat = $_POST['code_mat'];
        $description_cp = $_POST['description_cp'];
        $etat_cp = $_POST['etat_cp'];
        $id_class = $_POST['id_class'];
        $id_annee = $_POST['id_annee'];

        // Mettre à jour les valeurs dans la table competence
        $sql = "UPDATE competence 
                SET code_mat = :code_mat, description_cp = :description_cp, etat_cp = :etat_cp, id_class = :id_class, id_annee = :id_annee 
                WHERE id_comp = :id_comp";
        $stmt = $connection->prepare($sql);

        // Lier les paramètres
        $stmt->bindParam(':code_mat', $code_mat, PDO::PARAM_STR);
        $stmt->bindParam(':description_cp', $description_cp, PDO::PARAM_STR);
        $stmt->bindParam(':etat_cp', $etat_cp, PDO::PARAM_INT);
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $stmt->bindParam(':id_comp', $id_comp, PDO::PARAM_INT); // ID de compétence passé dans la requête

        // Exécuter la requête de mise à jour
        if ($stmt->execute()) {
            // Rediriger après la mise à jour réussie pour éviter la soumission multiple du formulaire
            header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri));  // Remplacez success_page.php par la page de votre choix
            exit;
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->errorInfo()[2];
        }
    }

} catch (Exception $e) {
    // Gérer les erreurs
    echo "Une erreur est survenue : " . $e->getMessage();
} finally {
    // Fermeture de la connexion PDO
    if (isset($connection)) {
        $connection = null;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Compétence</title>
    <!-- Lien vers le CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Lien vers le CSS de FontAwesome pour les icônes -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            font-size: 1.8rem;
            margin-bottom: 30px;
            text-align: center;
            color: #007bff;
        }

        .btn-custom {
            font-size: 1rem;
            font-weight: bold;
        }

        .btn-secondary {
            margin-left: 10px;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(38, 143, 255, 0.25);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="form-container">
            <h2>Modifier Compétence</h2>

            <form action="" method="POST">
                <input type="hidden" name="id_comp" value="<?= htmlspecialchars($competence['id_comp']) ?>">

                <input type="hidden" class="form-control" id="code_mat" name="code_mat" value="<?= $code_mat ?>" required>

                <div class="mb-3">
                    <label for="code_mat" class="form-label">Nom matière</label>
                    <input type="text" class="form-control" value="<?= $nom_matiere ?>" disabled>
                </div>

                <div class="mb-3">
                    <label for="description_cp" class="form-label">Description</label>
                    <textarea class="form-control" id="description_cp" name="description_cp" required><?= htmlspecialchars($competence['description_cp']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="etat_cp" class="form-label">État</label>
                    <select class="form-select" id="etat_cp" name="etat_cp" required>
                        <option value="1" <?= $competence['etat_cp'] == 1 ? 'selected' : '' ?>>Actif</option>
                        <option value="0" <?= $competence['etat_cp'] == 0 ? 'selected' : '' ?>>Inactif</option>
                    </select>
                </div>

                <input type="hidden" class="form-control" id="id_class" name="id_class" value="<?= htmlspecialchars($competence['id_class']) ?>" required>

                <input type="hidden" class="form-control" id="id_annee" name="id_annee" value="<?= htmlspecialchars($competence['id_annee']) ?>" required>

                <div class="d-flex justify-content-between">
                    <button type="submit" name="modifier" class="btn btn-primary btn-custom">
                        <i class="fas fa-save"></i> Sauvegarder les modifications
                    </button>
                    <a href="eleve.php" class="btn btn-secondary btn-custom">
                        <i class="fas fa-arrow-left"></i> Retour
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts JS de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

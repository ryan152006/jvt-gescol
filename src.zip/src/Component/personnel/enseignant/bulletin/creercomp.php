<?php
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';
    require_once 'Models/groupe.php';
    require_once 'Models/matiere.php';
    require_once 'Models/competence.php';
    require_once('../../../../Traitement/connexion.php');
    session_start();

    // Récupérer les données de session
    $id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
    $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
    $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;
    if (isset($_SESSION['id_annee'])) {
        $id_annee = $_SESSION['id_annee'];
    } else {
        // Gérer le cas où 'id_annee' n'est pas défini
        echo "L'année scolaire n'est pas définie dans la session.";
    }
 
      $competence = new Competence(); 

    $evaluation = new Evaluation();
    $eva = $evaluation->read();

    try {
        // Créer une instance de la base de données
        $db = new Database();
        $connection = $db->getConnection();

        // Vérifier si la connexion est établie
        if (!$connection) {
            throw new Exception("Connexion à la base de données échouée.");
        }

        // Récupérer les élèves de la base de données pour cette classe
        $sql = "SELECT * FROM eleve WHERE id_class = :id_class ORDER BY nom_elev"; 
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmt->execute();
        $eleve = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Vérifier si l'ID du trimestre est 2, 4 ou 6
        $isBulletinRequired = in_array($id_evaluation, [2, 4, 6]);


    } catch (Exception $e) {
        echo "Erreur: " . $e->getMessage();
        die();
    } 


    // Créer une instance de la classe Matiere
        $matiere = new Matiere();

  
        $matieres = $matiere->matiere_class($id_class, $id_annee);

    // Créer une instance de l'objet Groupe
    $groupe = new Groupe();
    
    // Récupérer la liste des groupes
    $groupes = $groupe->read();

    // Vérifier si le paramètre `code_mat` est passé dans l'URL
    if (isset($_GET['code_mat'])) {
        $code_mat = $_GET['code_mat'];  // Récupérer le code de la matière à supprimer

        // Créer une instance de la classe Matiere
        $matiere = new Matiere();

        // Appeler la méthode delete pour supprimer la matière de la base de données
        if ($matiere->delete($code_mat)) {
            // Si la suppression est réussie, rediriger vers une page de confirmation ou de liste
            header('Location: eleve.php?success=1'); // Assurez-vous d'avoir une page pour afficher la liste des matières
            exit();  // On arrête l'exécution du script après la redirection
        } else {
            // Si la suppression échoue, afficher un message d'erreur
            echo '<div class="alert alert-danger" role="alert">Erreur : Impossible de supprimer la matière.</div>';
        }
    } 

    // Récupérer les informations de la classe
    $sql_class = "SELECT * FROM classe WHERE id_class = :id_class";
    $stmt_class = $connection->prepare($sql_class);
    $stmt_class->bindParam(':id_class', $id_class, PDO::PARAM_INT);
    $stmt_class->execute();
    $class_data = $stmt_class->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations de l'année scolaire
    $sql_annee = "SELECT nom_annee FROM annee_scolaire WHERE id_annee = :id_annee";
    $stmt_annee = $connection->prepare($sql_annee);
    $stmt_annee->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
    $stmt_annee->execute();
    $annee_data = $stmt_annee->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations de l'évaluation
    $sql_evaluation = "SELECT * FROM evaluations WHERE id_evaluation = :id_evaluation";
    $stmt_evaluation = $connection->prepare($sql_evaluation);
    $stmt_evaluation->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);
    $stmt_evaluation->execute();
    $evaluation_data = $stmt_evaluation->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations du trimestre
    $sql_trimestre = "SELECT * FROM trimestre WHERE id_tri = :id_tri";
    $stmt_trimestre = $connection->prepare($sql_trimestre);
    $stmt_trimestre->bindParam(':id_tri', $id_tri, PDO::PARAM_INT);
    $stmt_trimestre->execute();
    $trimestre_data = $stmt_trimestre->fetch(PDO::FETCH_ASSOC);

        if (isset($_GET['action']) && $_GET['action'] == 'delete') {
            // Vérifier si 'id_comp' existe dans l'URL et est valide
            if (isset($_GET['id_comp']) && is_numeric($_GET['id_comp'])) {
                $id_comp = $_GET['id_comp'];

                // Vérifier si la connexion à la base de données est active
                if ($connection) {
                    // Supprimer la compétence avec la requête préparée
                    $req3 = $connection->prepare("DELETE FROM competence WHERE id_comp = ?");
                    if ($req3->execute([$id_comp])) {
                        // Rediriger après la suppression
                        header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri)); 
                        exit;
                    } else {
                        echo "Erreur lors de la suppression de la compétence.";
                    }
                } else {
                    echo "Erreur de connexion à la base de données.";
                }
            } else {
                echo "ID de compétence invalide ou non spécifié.";
            }
        }


    // Fermeture de la connexion PDO
    $connection = null;
    try {
        $stmt = $conn->prepare("SELECT matricule, nom, prenom FROM employe");
        $stmt->execute();
        $employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Erreur lors de la récupération des employés : ' . $e->getMessage();
        $employes = [];
    }
   
    
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Élèves</title>
    <link rel="stylesheet" href="../../../../Style/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .heading {
            background-color: #007bff;
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        .table {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
<div class="container mt-4">
<div class="d-flex justify-content-between mb-3 w-100">
        <!-- Bouton Retour aligné à gauche -->
        <a href="eleve.php?id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>" class="mb-6"><button class="btn btn-secondary  " id="printButton">
                        <i class="bi bi-arrow-left-circle"></i> Retour
                    </button></a>
    </div>
    <div class="heading text-center mb-4"> 
        <h2>Compétences par Matière</h2> 
    </div> 

    <!-- Formulaire d'ajout de compétence -->
    <form method="post" action="enregistrer_competance.php?id_evaluation=<?= urldecode($id_evaluation) ?>" class="row g-3 mb-4">
        <div class="col-md-6">
            <label for="code_mat" class="form-label">Code de la matière</label>
            <select class="form-select" id="matiere_select" name="code_mat" required>
                <option value="" disabled selected>Choisissez une matière</option>
                <?php foreach ($matieres as $matiere) : ?>
                    <option value="<?= htmlspecialchars($matiere->code_mat) ?>">
                        <?= htmlspecialchars($matiere->nom_matiere) ?> - <?= htmlspecialchars($matiere->abr_mat) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <input type="hidden" name="id_tri" class="form-control" value="<?= htmlspecialchars($id_tri) ?>" required>
        <div class="col-md-6">
            <label for="description_cp" class="form-label">Description de la compétence</label>
            <textarea class="form-control" id="description_cp" name="description_cp" maxlength="255" required></textarea>
        </div>
        <div class="col-md-6">
            <label for="etat_cp" class="form-label">État de la compétence</label>
            <select class="form-select" id="etat_cp" name="etat_cp" required>
                <option value="1">Actif</option>
                <option value="0">Inactif</option>
            </select>
        </div>
        <input type="hidden" name="id_class" class="form-control" value="<?= htmlspecialchars($id_class) ?>" required>
        <input type="hidden" name="id_annee" class="form-control" value="<?= htmlspecialchars($id_annee) ?>" required>
        <div class="col-12 mt-4">
            <button type="submit" class="btn btn-primary">Ajouter Compétence</button>
        </div>
    </form>
<?php    try {
    $competences = $competence->getCompetencesByMatiere($id_class, $id_annee, $id_tri);
} catch (Exception $e) {
    echo "Erreur: " . $e->getMessage();
}

?>
    <?php if (empty($competences)) : ?> 
        <div class="alert alert-warning text-center">
            Aucune compétence trouvée pour cette classe et cette année scolaire.
        </div>
    <?php else : ?> 
        <table class="table table-bordered"> 
            <thead> 
                <tr> 
                    <th>Matière</th> 
                    <th>Trimestre</th> 
                    <th>Description de la Compétence</th> 
                    <th>Année Scolaire</th>
                    <th>Action</th>
                </tr> 
            </thead> 
            <tbody> 
                <?php foreach ($competences as $competence) : ?> 
                    <tr> 
                        <td><?= htmlspecialchars($competence['nom_matiere']) ?></td> 
                        <td><?= htmlspecialchars($competence['type_tri']) ?></td> 
                        <td><?= htmlspecialchars($competence['description_cp']) ?></td> 
                        <td><?= htmlspecialchars($annee_data['nom_annee']) ?></td> 
                        <td>
                            <a href="mod_comp.php?id_comp=<?= htmlspecialchars($competence['id_comp']) ?>&action=modify&id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>" class="btn btn-warning">
                                <i class="fa-solid fa-edit"></i> Modifier
                            </a> 
                            <a href="eleve.php?id_comp=<?= $competence['id_comp'] ?>&action=delete&id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>" class="btn btn-danger" onclick="return confirm('Voulez-vous vraiment supprimer cet élément ?');">
                                Sup. note <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr> 
                <?php endforeach; ?>
            </tbody> 
        </table> 
    <?php endif; ?> 
</div>
</body>
</html>

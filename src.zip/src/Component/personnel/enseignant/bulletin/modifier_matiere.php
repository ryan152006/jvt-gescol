<?php
require_once 'Models/Database.php';
require_once 'Models/matiere.php'; // La classe pour manipuler la table matiere

session_start();

// Récupérer les données de session
$id_class = $_GET['id_class'] ?? null;
$id_annee = $_SESSION['id_annee'] ?? null;
$id_evaluation = $_GET['id_evaluation'];
$id_tri = $_GET['id_tri'];
try {
    // Créer une instance de la base de données
    $db = new Database();
    $connection = $db->getConnection();

    // Vérifier si la connexion est établie
    if (!$connection) {
        throw new Exception("Connexion à la base de données échouée.");
    }

    // Vérifier si un ID de matière est passé dans l'URL et s'il est valide
    if (isset($_GET['code_mat']) && !empty($_GET['code_mat'])) {
        $code_mat = $_GET['code_mat'];

        // Récupérer les informations de la matière à modifier
        $sql = "SELECT * FROM matiere WHERE code_mat = :code_mat";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':code_mat', $code_mat, PDO::PARAM_STR);
        $stmt->execute();
        $matiere = $stmt->fetch(PDO::FETCH_ASSOC);

        // Si aucune matière n'est trouvée
        if (!$matiere) {
            echo "Aucune matière trouvée avec ce code.";
            exit;
        }
    } else {
        echo "Code de matière invalide.";
        exit;
    }

    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modifier'])) {
        // Récupérer les nouvelles valeurs du formulaire
        $nom_matiere = $_POST['nom_matiere'];
        $coeficient = $_POST['coeficient'];
        $observations = $_POST['observations'];
        $Nom_ens = $_POST['Nom_ens'];
        $id_group = $_POST['id_group'];
        $statut = $_POST['statut'];
        $abr_mat = $_POST['abr_mat'];

        // Mettre à jour les valeurs dans la table matiere
        $sql = "UPDATE matiere
                SET nom_matiere = :nom_matiere, coeficient = :coeficient, observations = :observations, 
                    Nom_ens = :Nom_ens, id_group = :id_group, statut = :statut, abr_mat = :abr_mat
                WHERE code_mat = :code_mat";
        $stmt = $connection->prepare($sql);

        // Lier les paramètres
        $stmt->bindParam(':nom_matiere', $nom_matiere, PDO::PARAM_STR);
        $stmt->bindParam(':coeficient', $coeficient, PDO::PARAM_INT);
        $stmt->bindParam(':observations', $observations, PDO::PARAM_STR);
        $stmt->bindParam(':Nom_ens', $Nom_ens, PDO::PARAM_STR);
        $stmt->bindParam(':id_group', $id_group, PDO::PARAM_INT);
        $stmt->bindParam(':statut', $statut, PDO::PARAM_INT);
        $stmt->bindParam(':abr_mat', $abr_mat, PDO::PARAM_STR);
        $stmt->bindParam(':code_mat', $code_mat, PDO::PARAM_STR);

        // Exécuter la requête de mise à jour
        if ($stmt->execute()) {
            // Rediriger après la mise à jour réussie pour éviter la soumission multiple du formulaire
            header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri));  // Remplacez success_page.php par la page de votre choix
            exit;
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->errorInfo()[2];
        }
    }

} catch (Exception $e) {
    // Gérer les erreurs
    echo "Une erreur est survenue : " . $e->getMessage();
} finally {
    // Fermeture de la connexion PDO
    if (isset($connection)) {
        $connection = null;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Matière</title>
    <!-- Lien vers le CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Lien vers le CSS de FontAwesome pour les icônes -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        
        <style>
            body {
                background-color: #f8f9fa;
            }

            .form-container {
                background-color: white;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            .form-container h2 {
                font-size: 1.8rem;
                margin-bottom: 30px;
                text-align: center;
                color: #007bff;
            }

            .btn-custom {
                font-size: 1rem;
                font-weight: bold;
            }

            .btn-secondary {
                margin-left: 10px;
            }

            .form-control:focus {
                border-color: #007bff;
                box-shadow: 0 0 0 0.25rem rgba(38, 143, 255, 0.25);
            }
        </style>

</head>
<body>
    <div class="container mt-5">
        <div class="form-container">
            <h2>Modifier Matière</h2>

            <form action="" method="POST">
                <input type="hidden" name="code_mat" value="<?= htmlspecialchars($matiere['code_mat']) ?>">

                <div class="mb-3">
                    <label for="nom_matiere" class="form-label">Nom de la matière</label>
                    <input type="text" class="form-control" id="nom_matiere" name="nom_matiere" value="<?= htmlspecialchars($matiere['nom_matiere']) ?>" required>
                </div>

                
                <div class="mb-3">
                    <label for="abr_mat" class="form-label">Abréviation</label>
                    <input type="text" class="form-control" id="abr_mat" name="abr_mat" value="<?= htmlspecialchars($matiere['abr_mat']) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="coeficient" class="form-label">Coefficient</label>
                    <input type="number" class="form-control" id="coeficient" name="coeficient" value="<?= htmlspecialchars($matiere['coeficient']) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="observations" class="form-label">Observations</label>
                    <textarea class="form-control" id="observations" name="observations"><?= htmlspecialchars($matiere['observations']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="Nom_ens" class="form-label">Nom de l'enseignant</label>
                    <input type="text" class="form-control" id="Nom_ens" name="Nom_ens" value="<?= htmlspecialchars($matiere['Nom_ens']) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="id_group" class="form-label">Groupe</label>
                    <select name="id_group" id="id_group" class="form-select" required>
                        <option value="1" <?= $matiere['id_group'] == 1 ? 'selected' : '' ?>>Premier groupe</option>
                        <option value="2" <?= $matiere['id_group'] == 2 ? 'selected' : '' ?>>Deuxième groupe</option>
                        <option value="3" <?= $matiere['id_group'] == 3 ? 'selected' : '' ?>>Troisième groupe</option>
                        <option value="4" <?= $matiere['id_group'] == 4 ? 'selected' : '' ?>>Quatrième groupe</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="statut" class="form-label">Statut</label>
                    <select class="form-select" id="statut" name="statut" required>
                        <option value="1" <?= $matiere['statut'] == 1 ? 'selected' : '' ?>>Actif</option>
                        <option value="0" <?= $matiere['statut'] == 0 ? 'selected' : '' ?>>Inactif</option>
                    </select>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" name="modifier" class="btn btn-primary btn-custom">
                        <i class="fas fa-save"></i> Sauvegarder les modifications
                    </button>
                    <a href="eleve.php" class="btn btn-secondary btn-custom">
                        <i class="fas fa-arrow-left"></i> Retour
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts JS de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

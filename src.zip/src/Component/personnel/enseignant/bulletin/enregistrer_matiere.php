<?php
// Démarrer la session pour manipuler les variables de session
session_start();

// Inclure les fichiers nécessaires
include_once "Models/Database.php";
include_once "Models/matiere.php";

// Créer une nouvelle instance de la classe Matiere
$matiere = new Matiere();

// Récupérer `id_class` depuis l'URL et vérifier sa validité
$id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
if (!$id_class) {
    die("ID de la classe manquant !");
}

$message = ""; // Variable pour les messages de succès ou d'erreur

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $code = $_POST['code_mat'];
    $code_m = $code . rand(1000, 9999) . $id_class;

    // Récupérer les valeurs nécessaires depuis `$_GET` et vérifier leur validité
    $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
    $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;

    if (!$id_evaluation || !$id_tri) {
        die("ID d'évaluation ou ID de tri manquant !");
    }

    $code_mat = $code_m;
    $id_annee = $_SESSION['id_annee'];
    $idClass = $_POST['id_class']; // Attention : peut-être redondant avec $id_class
    $nom_matiere = $_POST['nom_matiere'];
    $coeficient = $_POST['coeficient'];
    $observations = $_POST['observations'];
    $Nom_ens = $_POST['Nom_ens'];
    $id_group = $_POST['id_group'];
    $statut = $_POST['statut'];
    $abr_mat = $_POST['abr_mat'];

    // Enregistrer la matière dans la base de données
    if ($matiere->create($code_mat, $id_annee, $idClass, $nom_matiere, $coeficient, $observations, $Nom_ens, $id_group, $statut, $abr_mat)) {
        $_SESSION['message'] = ["type" => "success", "text" => "Matière enregistrée avec succès!"];
    } else {
        $_SESSION['message'] = ["type" => "danger", "text" => "Erreur lors de l'enregistrement de la matière."];
    }

    // Redirection vers la page eleve.php après l'enregistrement
    header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri));
    exit();
}
?>

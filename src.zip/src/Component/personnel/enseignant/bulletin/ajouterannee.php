<?php
require_once '../../../../Traitement/connexion.php'; // Assurez-vous du chemin

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dateDebut = $_POST['dateDebut_A'] ?? null;
    $dateFin = $_POST['dateFin_A'] ?? null;
    $description = $_POST['description_periode'] ?? null;
    $etat = 0;

    // Validation des données
    if (!$dateDebut || !$dateFin) {
        echo json_encode(['success' => false, 'message' => ' les champs date de debut et de fin sont obligatoires.']);
        exit;
    }

    try {
        $stmt = $conn->prepare("
            INSERT INTO annee_scolaire (dateDebut_A, dateFin_A, description_periode, etat_P) 
            VALUES (:dateDebut, :dateFin, :description, :etat)
        ");
        $stmt->bindParam(':dateDebut', $dateDebut);
        $stmt->bindParam(':dateFin', $dateFin);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':etat', $etat);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Année scolaire ajoutée avec succès.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'insertion dans la base de données.']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Erreur : ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
}
?>

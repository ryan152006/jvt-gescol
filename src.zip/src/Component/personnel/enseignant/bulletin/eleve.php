<?php
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';
    require_once 'Models/groupe.php';
    require_once 'Models/matiere.php';
    require_once 'Models/competence.php';
    require_once('../../../../Traitement/connexion.php');
    session_start();

    // Récupérer les données de session
    $id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
    $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
    $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;
    if (isset($_SESSION['id_annee'])) {
        $id_annee = $_SESSION['id_annee'];
    } else {
        // Gérer le cas où 'id_annee' n'est pas défini
        echo "L'année scolaire n'est pas définie dans la session.";
    }
 

    $evaluation = new Evaluation();
    $eva = $evaluation->read();

    try {
        // Créer une instance de la base de données
        $db = new Database();
        $connection = $db->getConnection();

        // Vérifier si la connexion est établie
        if (!$connection) {
            throw new Exception("Connexion à la base de données échouée.");
        }

        // Récupérer les élèves de la base de données pour cette classe
        $sql = "SELECT * FROM eleve WHERE id_class = :id_class ORDER BY nom_elev"; 
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmt->execute();
        $eleve = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Vérifier si l'ID du trimestre est 2, 4 ou 6
        $isBulletinRequired = in_array($id_evaluation, [2, 4, 6]);


    } catch (Exception $e) {
        echo "Erreur: " . $e->getMessage();
        die();
    } 


    // Créer une instance de la classe Matiere
        $matiere = new Matiere();

  
        $matieres = $matiere->matiere_class($id_class, $id_annee);

    // Créer une instance de l'objet Groupe
    $groupe = new Groupe();
    
    // Récupérer la liste des groupes
    $groupes = $groupe->read();

    // Vérifier si le paramètre `code_mat` est passé dans l'URL
    if (isset($_GET['code_mat'])) {
        $code_mat = $_GET['code_mat'];  // Récupérer le code de la matière à supprimer

        // Créer une instance de la classe Matiere
        $matiere = new Matiere();

        // Appeler la méthode delete pour supprimer la matière de la base de données
        if ($matiere->delete($code_mat)) {
            // Si la suppression est réussie, rediriger vers une page de confirmation ou de liste
            header('Location: eleve.php?success=1'); // Assurez-vous d'avoir une page pour afficher la liste des matières
            exit();  // On arrête l'exécution du script après la redirection
        } else {
            // Si la suppression échoue, afficher un message d'erreur
            echo '<div class="alert alert-danger" role="alert">Erreur : Impossible de supprimer la matière.</div>';
        }
    } 

    // Récupérer les informations de la classe
    $sql_class = "SELECT * FROM classe WHERE id_class = :id_class";
    $stmt_class = $connection->prepare($sql_class);
    $stmt_class->bindParam(':id_class', $id_class, PDO::PARAM_INT);
    $stmt_class->execute();
    $class_data = $stmt_class->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations de l'année scolaire
    $sql_annee = "SELECT * FROM annee_scolaire WHERE id_annee = :id_annee";
    $stmt_annee = $connection->prepare($sql_annee);
    $stmt_annee->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
    $stmt_annee->execute();
    $annee_data = $stmt_annee->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations de l'évaluation
    $sql_evaluation = "SELECT * FROM evaluations WHERE id_evaluation = :id_evaluation";
    $stmt_evaluation = $connection->prepare($sql_evaluation);
    $stmt_evaluation->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);
    $stmt_evaluation->execute();
    $evaluation_data = $stmt_evaluation->fetch(PDO::FETCH_ASSOC);

    // Récupérer les informations du trimestre
    $sql_trimestre = "SELECT * FROM trimestre WHERE id_tri = :id_tri";
    $stmt_trimestre = $connection->prepare($sql_trimestre);
    $stmt_trimestre->bindParam(':id_tri', $id_tri, PDO::PARAM_INT);
    $stmt_trimestre->execute();
    $trimestre_data = $stmt_trimestre->fetch(PDO::FETCH_ASSOC);

        if (isset($_GET['action']) && $_GET['action'] == 'delete') {
            // Vérifier si 'id_comp' existe dans l'URL et est valide
            if (isset($_GET['id_comp']) && is_numeric($_GET['id_comp'])) {
                $id_comp = $_GET['id_comp'];

                // Vérifier si la connexion à la base de données est active
                if ($connection) {
                    // Supprimer la compétence avec la requête préparée
                    $req3 = $connection->prepare("DELETE FROM competence WHERE id_comp = ?");
                    if ($req3->execute([$id_comp])) {
                        // Rediriger après la suppression
                        header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri)); 
                        exit;
                    } else {
                        echo "Erreur lors de la suppression de la compétence.";
                    }
                } else {
                    echo "Erreur de connexion à la base de données.";
                }
            } else {
                echo "ID de compétence invalide ou non spécifié.";
            }
        }

    // Fermeture de la connexion PDO
    $connection = null;
    try {
        $stmt = $conn->prepare("SELECT matricule, nom, prenom FROM employe");
        $stmt->execute();
        $employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Erreur lors de la récupération des employés : ' . $e->getMessage();
        $employes = [];
    }
    
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Élèves</title>
    <!-- Feuille de style personnalisée -->
    <link rel="stylesheet" href="../../../../Style/style.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 1200px;
        }
        .heading {
            background-color: #007bff;
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        .table {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            border-radius: 30px;
            font-size: 1rem;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-info {
            background-color: #17a2b8;
            color: white;
            border-radius: 30px;
            font-size: 1rem;
        }
        .btn-info:hover {
            background-color: #138496;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
            border-radius: 30px;
            font-size: 0.9rem;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .back-btn {
            background-color: #6c757d;
            color: white;
            border-radius: 50px;
            font-size: 1rem;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
                /* Appliquer à la modal pour qu'elle ajuste sa largeur automatiquement en fonction du contenu */
        .modal-dialog {
            max-width: 90%; /* Limiter la largeur à 90% de l'écran */
            width: auto; /* Ajuster la largeur à la taille du contenu */
        }

        /* Optionnel : appliquer un maximum de largeur si nécessaire pour éviter une modal trop large sur les grands écrans */
        @media (min-width: 768px) {
            .modal-dialog {
                max-width: 80%; /* Sur les écrans plus larges, limiter à 80% de la largeur */
            }
        }

        /* Optionnel : s'assurer que les grandes modals ne dépassent pas l'écran */
        .modal-content {
            width: auto;
            max-width: 100%; /* Empêcher un dépassement horizontal */
        }
        .table-sm td, .table-sm th {
            padding: 2px 4px; /* Réduit encore plus le padding */
        }
    </style>
</head>
<body>
             <!-- Affichage des données récupérées -->
                <div class="container mt-5">
                    <a href="matiere.php?id_class=<?=urldecode($id_class)?>">
                        <button class="btn back-btn">
                            <i class="bi bi-arrow-left-circle"></i> Retour
                        </button>
                    </a>  <br><br>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card border-primary mb-3">
                                <div class="card-header bg-primary text-white text-center">
                                    <h4><strong>Informations sur l'Évaluation</strong></h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <p><strong>Classe :</strong> <?= htmlspecialchars($class_data['nom_class']) ?> <?= htmlspecialchars($class_data['id_class']) ?></p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><strong>Année scolaire :</strong> <?= htmlspecialchars($annee_data['nom_annee']) ?></p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><strong>Évaluation :</strong> <?= htmlspecialchars($evaluation_data['type_evaluation']) ?></p>
                                        </div>
                                        <div class="col-md-3">
                                            <p><strong>Trimestre :</strong> <?= htmlspecialchars($trimestre_data['type_tri']) ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Boutons de navigation -->
                    <div class="d-flex justify-content-between mb-3 w-100" style="border: none; position: relative; top: -50px;">
                
                        <div class="container">
                        <!-- Ligne des boutons -->
                        <div class="row mt-5">
                            <div class="col-4 text-start">
                                <!-- Bouton aligné à gauche -->
                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#GestMatiereModal" tabindex="0">
                                    <i class="bi bi-list"></i> Gestion matière
                                </button>
                            </div>
                            <div class="col-4 text-center">
                               
                            </div>
                            <div class="col-4 text-end">
                                <!-- Bouton aligné au centre -->
                                <a  href="creercomp.php?id_tri=<?=urldecode($id_tri)?>&id_evaluation=<?=urldecode($id_evaluation)?>&id_class=<?=urldecode($id_class)?>" class="">
                                        <button type="button" class="btn btn-success btn-sm mx-auto border-none" data-bs-toggle="modal" data-bs-target="" tabindex="0">
                                            <i class="bi bi-pencil"></i> Gestion des compétences
                                        </button>
                                  </a>        
                            </div>
                           
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="container my-5">
                    <?php
                        // Générer une valeur aléatoire de 4 caractères
                        function generateRandomCode($length = 4) {
                            $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; // Caractères possibles
                            $code = '';
                            for ($i = 0; $i < $length; $i++) {
                                $code .= $characters[rand(0, strlen($characters) - 1)];
                            }
                            return $code;
                        }

                        // Générer un code aléatoire de 4 caractères
                        $randomCode = generateRandomCode();
                    ?>

                    <?php
                        // Afficher un message de succès ou d'erreur, si disponible -->
                        if (isset($_SESSION['message'])):
                        ?>
                            <div class="table-responsive"style="border: none; position: relative; top: -60px;">
                                <div class="alert alert-<?= $_SESSION['message']['type'] ?> alert-dismissible fade show" role="alert">
                                    <?= $_SESSION['message']['text'] ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            </div>
                        <?php
                            // Supprimer le message après affichage
                            unset($_SESSION['message']);
                        endif;
                    ?>

                    <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
                        <div class="alert alert-danger" role="alert" style="border: none; position: relative; top: -60px;">
                            La matière a été supprimée avec succès.
                        </div>
                    <?php endif; ?>
                    
       
        <!-- Tableau des élèves -->
        <div class="table-responsive" style="border: none; position: relative; top: -60px;">
            <?php if (empty($eleve)) : ?>
                <!-- Si aucun élève n'est trouvé dans la base de données -->
                <div class="alert alert-warning" role="alert">
                    Aucun élève trouvé pour cette classe.
                </div>
            <?php else : ?>
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark table-sm">
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Sexe</th>
                            <th>Téléphone</th>
                            <th>Catégorie</th>
                            <th>Date de Naissance</th>
                            <th>Lieu de Naissance</th>
                            <th>Noter</th>
                          
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 1;
                        foreach ($eleve as $row) : ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= htmlspecialchars($row['nom_elev']) ?>
                                    <?= htmlspecialchars($row['prenom_elev']) ?></td>
                                <td><?= htmlspecialchars($row['sexe_elev']) ?></td>
                                <td><?= htmlspecialchars($row['telephone']) ?></td>
                                <td><?= htmlspecialchars($row['categorie']) ?></td>
                                <td><?= htmlspecialchars($row['date_naiss']) ?></td>
                                <td><?= htmlspecialchars($row['lieu_naiss']) ?></td>
                                <td>
                                        <a  href="noter.php?id_elev=<?=urldecode($row['id'])?>&id_tri=<?=urldecode($id_tri)?>&id_evaluation=<?=urldecode($id_evaluation)?>&id_class=<?=urldecode($id_class)?>" class="btn btn-success btn-sm">
                                            <i class="bi bi-pencil"></i> Noter
                                        </a>
                                 
                                </td>
                               
                            </tr>
                        <?php 
                        $i++;
                        endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <div class="modal fade" id="GestMatiereModal" tabindex="-1" aria-labelledby="GestMatiereModalLabel">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="GestMatiereModalLabel">Gérer les matières</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <!-- Ici on affiche les matières -->
                                <div class="table-responsive">
                                    <!-- Bouton Ajouter une matière -->
                                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#MatiereModal">
                                        <i class="bi bi-plus"></i> Ajouter une matière
                                    </button><br>

                                    <?php if (empty($matieres)) : ?>
                                        <div class="alert alert-warning" role="alert">
                                            Aucune matière disponible pour cette classe ou cette année scolaire.
                                        </div>
                                    <?php else : ?>
                                        <table class="table table-bordered table-striped">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Code matière</th>
                                                    <th>Nom matière</th>
                                                    <th>Abreviation</th>
                                                    <th>Nom Enseignant</th>
                                                    <th>Coefficient</th>
                                                    <th>Groupe matière</th>
                                                    <th>Statut matière</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $i = 1;
                                                foreach ($matieres as $matiere) :
                                                    // Affichage du groupe matière en fonction de id_group
                                                    switch ($matiere->id_group) {
                                                        case 1:
                                                            $groupe = "Premier groupe";
                                                            break;
                                                        case 2:
                                                            $groupe = "Deuxième groupe";
                                                            break;
                                                        case 3:
                                                            $groupe = "Troisième groupe";
                                                            break;
                                                        case 4:
                                                            $groupe = "Quatrième groupe";
                                                            break;
                                                        default:
                                                            $groupe = "Groupe inconnu";
                                                    }

                                                    // Affichage du statut matière
                                                    $statut = ($matiere->statut == 1) ? "Active" : "Inactive";
                                                ?>
                                                    <tr>
                                                        <td><?= $i ?></td>
                                                        <td><?= htmlspecialchars($matiere->code_mat) ?></td>
                                                        <td><?= htmlspecialchars($matiere->nom_matiere) ?></td>
                                                        <td><?= htmlspecialchars($matiere->abr_mat) ?></td>
                                                        <td><?= htmlspecialchars($matiere->Nom_ens) ?></td>
                                                        <td><?= htmlspecialchars($matiere->coeficient) ?></td>
                                                        <td><?= $groupe ?></td>
                                                        <td><?= $statut ?></td>
                                                        <td class="">
                                                            <a href="modifier_matiere.php?id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>&code_mat=<?= $matiere->code_mat ?>&action=modify" 
                                                                class="btn btn-warning mb-2">
                                                                <i class="fa-solid fa-edit"></i> Modifier
                                                            </a> 
                                                            <a href="supp_matiere.php?code_mat=<?= urldecode($matiere->code_mat) ?>&id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>" 
                                                                class="btn btn-danger"
                                                                onclick="return confirm('Voulez-vous vraiment supprimer cette matière ?');">
                                                                <i class="fa-solid fa-trash"></i> Supprimer
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php 
                                                    $i++;
                                                endforeach;
                                                ?>
                                            </tbody>
                                        </table>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- Modal pour une Matière  -->
                <div class="modal fade" id="MatiereModal" tabindex="-1" aria-labelledby="MatiereModalLabel">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="MatiereModalLabel">Ajouter une Matière</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#GestMatiereModal">
                                    <i class="bi bi-list"></i> Gestion matière
                                </button>
                                <div class="modal-body">
                                    <form method="post" action="enregistrer_matiere.php?id_evaluation=<?= urldecode($id_evaluation)?>&id_tri=<?=urldecode($id_tri)?>&id_class=<?=urldecode($id_class)?>" class="row g-3 mt-3">
                                        <input type="hidden" class="form-control" id="code_mat" value="<?php echo $randomCode; ?>" name="code_mat" maxlength="10" required readonly>
                                    
                                    <div class="col-md-6">
                                        <label for="abr_mat" class="form-label">Nom de la matiere abrégé<span style="color:red"> Exp: S.V.T ou MATH</span></label>
                                        <input type="text" class="form-control" id="abr_mat" name="abr_mat" required>
                                    </div>
                                    
                                        <input type="hidden" class="form-control" id="id_annee" name="id_annee" value="<?=$id_annee?>" readonly required>
                                    
                                        <input type="hidden" class="form-control" id="id_class" name="id_class" value="<?=$id_class?>" required readonly>
                                    <div class="col-md-6">
                                        <label for="nom_matiere" class="form-label">Nom de la Matière <span style="color:red">Exp: Mathématique</span> </label>
                                        <input type="text" class="form-control" id="nom_matiere" name="nom_matiere" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="coeficient" class="form-label">Coefficient</label>
                                        <input type="number" class="form-control" id="coeficient" name="coeficient" required>
                                    </div>
                                    <div class="col-md-6">
                            
                                        <label for="Nom_ens" class="form-label">Nom de l'Enseignant</label>
                                        <select id="Nom_ens" class="form-control" name="Nom_ens" maxlength="50" required>
                                            <option value="" disabled selected>Sélectionnez un professeur Titulaire</option>
                                            <?php foreach ($employes as $employe): ?>
                                                <option value="<?php echo htmlspecialchars($employe['nom']); ?>">
                                                    <?php echo htmlspecialchars($employe['prenom'] . ' ' . $employe['nom']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="statut" class="form-label">Groupe des matières</label>
                                        <select class="form-select" id="id_group" name="id_group" required>
                                            <?php
                                            
                                            // Vérifier si des groupes sont disponibles
                                            if (count($groupes) > 0) {
                                                foreach ($groupes as $row) {
                                                    // Afficher chaque groupe dans une option
                                                    echo "<option value='" . $row->id_group . "'>" . htmlspecialchars($row->nom_group) . "</option>";
                                                }
                                            } else {
                                                // Si aucun groupe n'est trouvé
                                                echo "<option>Aucun groupe trouvé.</option>";
                                            }
                                            ?>
                                        </select>

                                    </div>
                                    <div class="col-md-6">
                                        <label for="observations" class="form-label">Observations</label>
                                        <textarea class="form-control" id="observations" name="observations" maxlength="50"></textarea>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label for="Nom_ens" class="form-label">Statut de la matière</label>
                                        <select class="form-select" id="statut" name="statut" required>
                                            <option value="1">Actitf</option>
                                            <option value="0">Inactif</option>
                                        </select>
                                    </div>
                            
                                    <div class="col-12 mt-4">
                                        <button type="submit" class="btn btn-primary" name="matiere">Enregistrer la Matière</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- Modal pour gerer compétance  -->
            


            <!-- Modal pour une gestion matière -->
                 <!-- Modal pour une gestion matière -->
                
  
</body>
</html>

<?php
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
session_start();
    $id_class = $_GET['id_class'];
    // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    $id_eleve = $_GET['id_elev'];

    $id_evaluation = $_GET['id_evaluation'];
    $id_annee = $_SESSION['id_annee'];
    $id_tri = $_GET['id_tri'];
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';

    $evaluation = new Evaluation();
    $eva = $evaluation->read();

 //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        $db = new Database();
        $connection = $db->getConnection();

        $sql = "SELECT * FROM eleve WHERE id = $id_eleve"; 
        $stmt = $connection->query($sql);

        // Vérifier si des élèves sont présents dans la base de données
        $eleve = $stmt->fetchAll(PDO::FETCH_ASSOC);

// selectionner les matiere d'une classe precise
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        $sql = "SELECT * FROM matiere WHERE id_class = $id_class"; 
        $stmt = $connection->query($sql);

        // Vérifier si des élèves sont présents dans la base de données
        $idClass = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                 
    // Utiliser les identifiants depuis les variables de session
       

        // Récupérer toutes les matières pour la classe et l'année académique en cours, avec les notes de l'élève si elles existent
        $sqll = "SELECT m.*, n.* FROM matiere m 
                LEFT JOIN note n ON m.code_mat = n.code_mat 
                AND n.id_evaluation = :id_evaluation 
                AND n.id = :id_eleve 
                WHERE m.id_class = :id_class 
                AND m.id_annee = :id_annee";

        $stmt = $connection->prepare($sqll);
        $stmt->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);
        $stmt->bindParam(':id_eleve', $id_eleve, PDO::PARAM_INT);
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $stmt->execute();

        // Récupérer toutes les matières avec les notes (si disponibles)
        $notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Calculer la moyenne pondérée de l'élève
        $totalNotesCoef = 0;
        $totalCoef = 0;
        foreach ($notes as $subject) {
            if ($subject['note'] !== null) {
                $totalNotesCoef += $subject['note'] * $subject['coeficient'];
                $totalCoef += $subject['coeficient'];
            }
        }
        $moyenneEleve = ($totalCoef > 0) ? round($totalNotesCoef / $totalCoef, 2) : "/";

        // Récupérer la moyenne la plus élevée parmi tous les élèves de la classe, pour cette évaluation et cette année
        $highestAvgSql = "
            SELECT MAX(total_note / total_coef) AS max_average
            FROM (
                SELECT SUM(n.note * m.coeficient) AS total_note, 
                    SUM(m.coeficient) AS total_coef
                FROM note n
                JOIN matiere m ON n.code_mat = m.code_mat
                WHERE n.id_class = :id_class
                AND n.id_evaluation = :id_evaluation
                AND n.id_annee = :id_annee
                GROUP BY n.id
            ) AS averages
        ";

        $highestAvgStmt = $connection->prepare($highestAvgSql);
        $highestAvgStmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $highestAvgStmt->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);
        $highestAvgStmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $highestAvgStmt->execute();
        $highestAverageRow = $highestAvgStmt->fetch(PDO::FETCH_ASSOC);
        $moyenneClasse = ($highestAverageRow) ? round($highestAverageRow['max_average'], 2) : "/";

    // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    // supprimer une note 

    // Code pour recupérer les données dans la base de données et l'afficher

    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        // Vérifier si 'noteID' existe dans l'URL et correspond à une valeur valide
        if (isset($_GET['noteID']) && is_numeric($_GET['noteID'])) {
            $noteID = $_GET['noteID'];
    
            // Supprimer la note en utilisant une requête préparée
            $req3 = $connection->prepare("DELETE FROM note WHERE id_note = ?");
            $req3->execute([$noteID]);
    
            // Rediriger après la suppression
            header("Location: noter.php");
            exit;
        } else {
            echo "ID de note invalide ou non spécifié.";
        }
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <title>Gestion des Élèves</title>
</head>
<body>
    <div class="container mt-5">
    <div class="d-flex justify-content-between mb-3 w-100">
        <!-- Bouton Retour aligné à gauche -->
        <a href="eleve.php?id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>&id_elev=<?= urldecode($id_eleve)?>" class="mb-6"><button class="btn btn-secondary  " id="printButton">
                        <i class="bi bi-arrow-left-circle"></i> Retour
                    </button></a>
    </div>

        <div class="table-responsive">

            <?php if (empty($eleve)) : ?>
                <!-- Si aucun élève n'est trouvé dans la base de données -->
                <div class="alert alert-warning" role="alert">
                    Aucun élève trouvé pour cette classe.
                </div>
            <?php else : ?>
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Sexe</th>
                            <th>Téléphone</th>
                            <th>Téléphone Mère</th>
                            <th>Categorie</th>
                            <th>Date Naissance</th>
                            <th>Lieu Naissance</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 1;
                        foreach ($eleve as $row) : ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= htmlspecialchars($row['nom_elev']) ?></td>
                                <td><?= htmlspecialchars($row['prenom_elev']) ?></td>
                                <td><?= htmlspecialchars($row['sexe_elev']) ?></td>
                                <td><?= htmlspecialchars($row['telephone']) ?></td>
                                <td><?= htmlspecialchars($row['tel_mere']) ?></td>
                                <td><?= htmlspecialchars($row['categorie']) ?></td>
                                <td><?= htmlspecialchars($row['date_naiss']) ?></td>
                                <td><?= htmlspecialchars($row['lieu_naiss']) ?></td>
                            </tr>
                        <?php 
                        $i++;
                        endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        
        <div class="container mt-4"> 

            <?php if (isset($_SESSION['success'])): ?>

                <div class="alert alert-success" role="alert"> 
                    <?= htmlspecialchars($_SESSION['success']) ?> 
                </div> 

                <?php unset($_SESSION['success']); ?> <?php endif; ?> <?php if (isset($_SESSION['error'])): ?> 
                
                <div class="alert alert-danger" role="alert"> 
                    <?= htmlspecialchars($_SESSION['error']) ?> 
                </div> 
                
                <?php unset($_SESSION['error']); ?> 
                
                <?php endif; ?>


            <div class="d-flex justify-content-between mb-3 w-100">

                <!-- Bouton Ajouter une note aligné à droite -->
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#noteModal">
                    <i class="bi bi-plus"></i> Ajouter une note
                </button>
            </div>

                <div class="table-responsive">
                        <?php if (empty($notes)) : ?>
                            <div class="alert alert-warning" role="alert">
                                Aucune matière disponible pour cette classe ou cette année scolaire.
                            </div>
                        <?php else : ?>
                            <table class="table table-bordered table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Note</th>
                                        <th>Matière</th>
                                        <th>Coefficient</th>
                                        <th>Nom prof</th>
                                        <th>Note Coeff.</th>
                                        <th>Sup.note</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    foreach ($notes as $subject) :
                                        // Afficher "/" pour les matières sans note
                                        $noteDisplay = ($subject['note'] !== null) ? htmlspecialchars($subject['note']) : "/";
                                        $notecoef = ($subject['note'] !== null) ? $subject['note'] * $subject['coeficient'] : "/";
                                    ?>
                                        <tr>
                                            <td><?= $i ?></td>
                                            <td><?= $noteDisplay ?></td>
                                            <td><?= htmlspecialchars($subject['nom_matiere']) ?></td>
                                            <td><?= htmlspecialchars($subject['coeficient']) ?></td>
                                            <td><?= htmlspecialchars($subject['Nom_ens']) ?></td>
                                            <td><?= $notecoef ?></td>
                                            <td>
                                            <a href="supp_note.php?noteID=<?=$subject['id_note']?>&action=delete&id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>&id_elev=<?= urldecode($id_eleve)?>" 
                                                    class="btn btn-danger"
                                                    onclick="return confirm('Voulez-vous vraiment supprimer cet élément ?');">
                                                    Sup. note <i class="fa-solid fa-trash"></i>
                                                </a>
                                           
                                        </td>

                                        </tr>
                                    <?php 
                                        $i++;
                                    endforeach;
                                    ?>
                                </tbody>
                            </table>
                    
                    <div class="alert alert-info" role="alert">
                        Moyenne pondérée de l'étudiant : <?= $moyenneEleve ?>
                    </div>
                    <div class="alert alert-success" role="alert">
                        Moyenne la plus élevée de la classe : <?= $moyenneClasse ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
                </div>

    <!-- Ajouter le script Bootstrap JS si nécessaire -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

                        
            <!-- Modal pour ajouter une note -->
                <div class="modal fade" id="noteModal" tabindex="-1" aria-labelledby="noteModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="noteModalLabel">Ajouter une Note</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="enregistrer_note.php?id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>&id_elev=<?= urldecode($id_eleve)?>" method="POST">
                                    
                                        <input type="hidden" class="form-control" id="id_evaluation" name="id_evaluation" value="<?=$id_evaluation;?>" required readonly>
                                        <input type="hidden" class="form-control" id="id_class" name="id_class" value="<?=$id_class;?>" required readonly>

                                        <input type="hidden" class="form-control" id="id_tri" name="id_tri" value="<?= urldecode($id_tri)?>" required readonly>

                                    <div class="mb-3">
                                        <label for="matiere" class="form-label">Matière</label>
                                        <select class="form-select" id="matiere" name="matiere" required>
                                            <?php
                                            // Récupérer la liste des matières disponibles pour l'élève
                                            if (count($idClass) > 0) { $i=1;
                                                foreach ($idClass as $row) { 
                                                    echo "<option value='" . $row['code_mat'] . "'>" . $i ." - ". $row['nom_matiere'] . ' || ' . $row['coeficient'] . "</option>"; 
                                               $i++; }
                                            } else { 
                                                echo "<option>Aucune matière trouvée pour cette classe.</option>"; 
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                        <input type="hidden" class="form-control" id="id" name="id" readonly value="<?=$id_eleve;?>">
                                    
                                        <div class="mb-3">
                                            <label for="note" class="form-label">Note</label>
                                            <input type="text" class="form-control" id="note" name="note" required>
                                        </div>



                                        <input type="hidden" class="form-control" id="id_annee" name="id_annee" value="<?=$id_annee?>" required readonly>
                                    
                                    <div class="mb-3">
                                        <label for="etat" class="form-label">Etat Année Approbation</label>
                                        <select class="form-select" id="etat" name="etat" required>
                                            <option value="1">Validée</option>
                                            <option value="0">Non Validée</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" class="btn btn-success">Ajouter la note</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </body>
</html>
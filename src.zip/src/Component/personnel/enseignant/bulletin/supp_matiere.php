<?php
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';
    require_once 'Models/groupe.php';
    require_once 'Models/matiere.php';
    require_once 'Models/competence.php';
    require_once('../../../../Traitement/connexion.php');
    if (isset($_GET['code_mat'])) {
        $code_mat = $_GET['code_mat'];  // Récupérer le code de la matière à supprimer
        $id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
        $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
        $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;
        // Créer une instance de la classe Matiere
        $matiere = new Matiere();

        // Appeler la méthode delete pour supprimer la matière de la base de données
        if ($matiere->delete($code_mat)) {
            // Si la suppression est réussie, rediriger vers une page de confirmation ou de liste
            header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri));  // Remplacez success_page.php par la page de votre choix
            exit();  // On arrête l'exécution du script après la redirection
        } else {
            // Si la suppression échoue, afficher un message d'erreur
            echo '<div class="alert alert-danger" role="alert">Erreur : Impossible de supprimer la matière.</div>';
        }
    } 

?>
<?php
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';
    require_once 'Models/groupe.php';
    require_once 'Models/matiere.php';
    require_once 'Models/competence.php';
    require_once('../../../../Traitement/connexion.php');

    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
        // Vérifier si 'id_comp' existe dans l'URL et est valide
        if (isset($_GET['id_comp']) && is_numeric($_GET['id_comp'])) {
            $id_comp = $_GET['id_comp'];
            $id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
            $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
            $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;
            // Vérifier si la connexion à la base de données est active
            if ($connection) {
                // Supprimer la compétence avec la requête préparée
                $req3 = $connection->prepare("DELETE FROM competence WHERE id_comp = ?");
                if ($req3->execute([$id_comp])) {
                    // Rediriger après la suppression
                    header('Location: eleve.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri)); 
                    exit;
                } else {
                    echo "Erreur lors de la suppression de la compétence.";
                }
            } else {
                echo "Erreur de connexion à la base de données.";
            }
        } else {
            echo "ID de compétence invalide ou non spécifié.";
        }
    }

    ?>
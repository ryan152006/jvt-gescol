<?php
include_once "Database.php";

class Competence extends Database
{

  public function create(string $code_mat, int $id_tri, string $description_cp, int $etat_cp, int $id_class, int $id_annee)
    {
        // Vérifier l'existence de la classe
        $stmtClass = $this->getConnection()->prepare("SELECT COUNT(*) FROM classe WHERE id_class = :id_class");
        $stmtClass->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmtClass->execute();
        if ($stmtClass->fetchColumn() == 0) {
            throw new Exception("Classe non trouvée pour id_class = $id_class");
        }

        // Vérifier l'existence du trimestre
        $stmtTrim = $this->getConnection()->prepare("SELECT COUNT(*) FROM trimestre WHERE id_tri = :id_tri");
        $stmtTrim->bindParam(':id_tri', $id_tri, PDO::PARAM_INT);
        $stmtTrim->execute();
        if ($stmtTrim->fetchColumn() == 0) {
            throw new Exception("Trimestre non trouvé pour id_tri = $id_tri");
        }

        // Vérifier l'existence de l'année scolaire
        $stmtAnnee = $this->getConnection()->prepare("SELECT COUNT(*) FROM annee_scolaire WHERE id_annee = :id_annee");
        $stmtAnnee->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $stmtAnnee->execute();
        if ($stmtAnnee->fetchColumn() == 0) {
            throw new Exception("Année scolaire non trouvée pour id_annee = $id_annee");
        }

        // Vérifier l'existence de la matière
        $stmtMatiere = $this->getConnection()->prepare("SELECT COUNT(*) FROM matiere WHERE code_mat = :code_mat");
        $stmtMatiere->bindParam(':code_mat', $code_mat, PDO::PARAM_STR);
        $stmtMatiere->execute();
        if ($stmtMatiere->fetchColumn() == 0) {
            throw new Exception("Matière non trouvée pour code_mat = $code_mat");
        }

        // Insertion dans la table competence
        $q = $this->getConnection()->prepare("INSERT INTO competence (code_mat, id_tri, description_cp, etat_cp, id_class, id_annee) 
                                              VALUES (:code_mat, :id_tri, :description_cp, :etat_cp, :id_class, :id_annee)");
        return $q->execute([
            'code_mat' => $code_mat,
            'id_tri' => $id_tri,
            'description_cp' => $description_cp,
            'etat_cp' => $etat_cp,
            'id_class' => $id_class,
            'id_annee' => $id_annee
        ]);
    }

    public function read()
    {
        return $this->getConnection()->query("SELECT * FROM competence ORDER BY id_comp")->fetchAll(PDO::FETCH_OBJ);
    }

    public function getSingleCompetence(int $id_comp)
    {
        $q = $this->getConnection()->prepare("SELECT * FROM competence WHERE id_comp = :id_comp");
        $q->execute(['id_comp' => $id_comp]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(int $id_comp, string $code_mat, int $id_tri, string $description_cp, int $etat_cp, int $id_class, int $id_annee)
    {
        $q = $this->getConnection()->prepare("UPDATE competence 
                                              SET code_mat = :code_mat, id_tri = :id_tri, description_cp = :description_cp, 
                                                  etat_cp = :etat_cp, id_class = :id_class, id_annee = :id_annee 
                                              WHERE id_comp = :id_comp");
        return $q->execute([
            'code_mat' => $code_mat,
            'id_tri' => $id_tri,
            'description_cp' => $description_cp,
            'etat_cp' => $etat_cp,
            'id_class' => $id_class,
            'id_annee' => $id_annee,
            'id_comp' => $id_comp
        ]);
    }

    public function delete(int $id_comp): bool
    {
        $q = $this->getConnection()->prepare("DELETE FROM competence WHERE id_comp = :id_comp");
        return $q->execute(['id_comp' => $id_comp]);
    }
    
    public function getCompetencesByMatiere($id_class, $id_annee, $id_tri)
    {
        $sql = "SELECT m.nom_matiere, c.id_comp, c.description_cp, t.type_tri, a.description_periode
                FROM competence c
                JOIN matiere m ON c.code_mat = m.code_mat
                JOIN trimestre t ON c.id_tri = t.id_tri
                JOIN annee_scolaire a ON c.id_annee = a.id_annee
                WHERE c.id_class = :id_class AND c.id_annee = :id_annee AND c.id_tri = :id_tri
                ORDER BY m.nom_matiere ASC, t.dateDebut_trim ASC";

        $stmt = $this->getConnection()->prepare($sql);
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
        $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $stmt->bindParam(':id_tri', $id_tri, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


}
?>

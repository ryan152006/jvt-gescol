<?php
include_once "Database.php";

class Trimestre extends Database
{
    public function create(string $type_tri, string $dateDebut_trim, string $dateFin_trim, string $description, int $etat_trim)
    {
        $q = $this->getConnection()->prepare("INSERT INTO trimestre (type_tri, dateDebut_trim, dateFin_trim, description, etat_trim) 
                                              VALUES (:type_tri, :dateDebut_trim, :dateFin_trim, :description, :etat_trim)");
        return $q->execute([
            'type_tri' => $type_tri,
            'dateDebut_trim' => $dateDebut_trim,
            'dateFin_trim' => $dateFin_trim,
            'description' => $description,
            'etat_trim' => $etat_trim
        ]);
    }

    public function read()
    {
        return $this->getConnection()->query("SELECT * FROM trimestre ORDER BY id_tri")->fetchAll(PDO::FETCH_OBJ);
    }

    public function getSingleTrimestre(int $id_tri)
    {
        $q = $this->getConnection()->prepare("SELECT * FROM trimestre WHERE id_tri = :id_tri");
        $q->execute(['id_tri' => $id_tri]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(int $id_tri, string $type_tri, string $dateDebut_trim, string $dateFin_trim, string $description, int $etat_trim)
    {
        $q = $this->getConnection()->prepare("UPDATE trimestre 
                                              SET type_tri = :type_tri, dateDebut_trim = :dateDebut_trim, 
                                                  dateFin_trim = :dateFin_trim, description = :description, 
                                                  etat_trim = :etat_trim 
                                              WHERE id_tri = :id_tri");
        return $q->execute([
            'type_tri' => $type_tri,
            'dateDebut_trim' => $dateDebut_trim,
            'dateFin_trim' => $dateFin_trim,
            'description' => $description,
            'etat_trim' => $etat_trim,
            'id_tri' => $id_tri
        ]);
    }

    public function delete(int $id_tri): bool
    {
        $q = $this->getConnection()->prepare("DELETE FROM trimestre WHERE id_tri = :id_tri");
        return $q->execute(['id_tri' => $id_tri]);
    }
}
?>

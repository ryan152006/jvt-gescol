<?php

    include_once "Database.php";
    class AnneeScolaire extends Database

{
    
    public function create(string $dateDebut_A, string $dateFin_A, string $description_periode, int $etat_P)
    {
        $q = $this->getConnection()->prepare("INSERT INTO Annee_scolaire (dateDebut_A, dateFin_A, description_periode, etat_P) 
                                              VALUES (:dateDebut_A, :dateFin_A, :description_periode, :etat_P)");

        return $q->execute([
            'dateDebut_A' => $dateDebut_A,
            'dateFin_A' => $dateFin_A,
            'description_periode' => $description_periode,
            'etat_P' => $etat_P
        ]);
    }

    public function read(){
        return $this->getConnection()->query("SELECT * FROM Annee_scolaire ORDER BY id_annee  DESC")->fetchAll(PDO::FETCH_OBJ);
    }

    public function countYears(): int {
        return (int)$this->getConnection()->query("SELECT count(id_annee) as count FROM Annee_scolaire")->fetch()[0];
    }

    public function getSingleYear(int $id_annee){
        $q = $this->getConnection()->prepare("SELECT * FROM Annee_scolaire WHERE id_annee = :id_annee");
        $q->execute(['id_annee' => $id_annee]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(int $id_annee, string $dateDebut_A, string $dateFin_A, string $description_periode, int $etat_P)
    {
        $q = $this->getConnection()->prepare("UPDATE Annee_scolaire 
                                              SET dateDebut_A = :dateDebut_A, dateFin_A = :dateFin_A, 
                                                  description_periode = :description_periode, etat_P = :etat_P 
                                              WHERE id_annee = :id_annee");
        return $q->execute([
            'dateDebut_A' => $dateDebut_A,
            'dateFin_A' => $dateFin_A,
            'description_periode' => $description_periode,
            'etat_P' => $etat_P,
            'id_annee' => $id_annee
        ]);
    }

    public function delete(int $id_annee): bool {
        $q = $this->getConnection()->prepare("DELETE FROM Annee_scolaire WHERE id_annee = :id_annee");
        return $q->execute(['id_annee' => $id_annee]);
    }
}
?>

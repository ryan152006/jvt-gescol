<?php
include_once "Database.php";
class Matiere extends Database
{
    // const HOST = "localhost";
    // const DBNAME = "crud_ajax";
    // const USER = "root";
    // const PASS = "";

    // public static function getConnexion(){
    //     try{
    //         $bdd = new PDO("mysql:host=" . self::HOST . ";dbname=" . self::DBNAME, self::USER, self::PASS);
    //         // Echo "je suis connecté";
    //     } catch(PDOException $ex){
    //         header("Location: error.php");
    //         exit();
    //         die("Erreur: " . $ex); 
    //     }
    //     return $bdd;
    // }

        public function create(string $code_mat, int $id_annee, int $id_class, string $nom_matiere, float $coeficient, string $observations, 
                        string $Nom_ens, int $id_group, int $statut, string $abr_mat)
    {
        $q = $this->getConnection()->prepare("INSERT INTO matiere (code_mat, id_annee, id_class, nom_matiere, coeficient, observations, 
                                            Nom_ens, id_group, statut, abr_mat) 
                                            VALUES (:code_mat, :id_annee, :id_class, :nom_matiere, :coeficient, :observations, 
                                                    :Nom_ens, :id_group, :statut, :abr_mat)");

        return $q->execute([
            'code_mat' => $code_mat,
            'id_annee' => $id_annee,
            'id_class' => $id_class,
            'nom_matiere' => $nom_matiere,
            'coeficient' => $coeficient, 
            'observations' => $observations,
            'Nom_ens' => $Nom_ens,
            'id_group' => $id_group,
            'statut' => $statut,
            'abr_mat' => $abr_mat,
        ]);
    }

    public function matiere_class(int $id_class, int $id_annee) {
        // Préparer la requête pour récupérer les matières correspondant à id_class et id_annee
        $q = $this->getConnection()->prepare("SELECT * FROM matiere WHERE id_class = :id_class AND id_annee = :id_annee ORDER BY code_mat");
        $q->execute([
            'id_class' => $id_class,
            'id_annee' => $id_annee
        ]);
    
        // Retourner les résultats sous forme d'objet
        return $q->fetchAll(PDO::FETCH_OBJ);
    }
    
    

    public function read(){
        return $this->getConnection()->query("SELECT * FROM matiere ORDER BY code_mat")->fetchAll(PDO::FETCH_OBJ);
    }

    public function countMatieres(): int {
        return (int)$this->getConnection()->query("SELECT count(code_mat) as count FROM matiere")->fetch()[0];
    }

    public function getSingleMatiere(string $code_mat){
        $q = $this->getConnection()->prepare("SELECT * FROM matiere WHERE code_mat = :code_mat");
        $q->execute(['code_mat' => $code_mat]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(string $code_mat, int $id_annee, string $nom_matiere, string $observations, 
                           string $Nom_ens,int $id_group,  int $statut, string $abr_mat, int $id_Eta)
    {
        $q = $this->getConnection()->prepare("UPDATE matiere 
                                              SET id_annee = :id_annee, nom_matiere = :nom_matiere, 
                                                  observations = :observations, Nom_ens = :Nom_ens, id_group = :id_group,
                                                  statut = :statut, abr_mat = :abr_mat, id_Eta = :id_Eta 
                                              WHERE code_mat = :code_mat");
        return $q->execute([
            'id_annee' => $id_annee,
            'nom_matiere' => $nom_matiere,
            'observations' => $observations,
            'Nom_ens' => $Nom_ens,
            'id_group' => $id_group,
            'statut' => $statut,
            'etat_mat' => $abr_mat,
            'id_Eta' => $id_Eta,
            'code_mat' => $code_mat
        ]);
    }

    public function delete(string $code_mat): bool {
        $q = $this->getConnection()->prepare("DELETE FROM matiere WHERE code_mat = :code_mat");
        return $q->execute(['code_mat' => $code_mat]);
    }
}
?>

<?php

include_once "Database.php";

class Groupe extends Database
{
    // Méthode pour créer un nouveau groupe
    public function create(string $nom_group, int $statut)
    {
        $q = $this->getConnection()->prepare("INSERT INTO groupe (nom_group, statut) 
                                              VALUES (:nom_group, :statut)");

        return $q->execute([
            'nom_group' => $nom_group,
            'statut' => $statut
        ]);
    }

    // Méthode pour récupérer tous les groupes
    public function read()
    {
        return $this->getConnection()->query("SELECT * FROM groupe ORDER BY id_group DESC")->fetchAll(PDO::FETCH_OBJ);
    }

    // Méthode pour compter le nombre de groupes
    public function countGroups(): int
    {
        return (int)$this->getConnection()->query("SELECT count(id_group) as count FROM groupe")->fetch()[0];
    }

    // Méthode pour récupérer un groupe par son ID
    public function getSingleGroup(int $id_group)
    {
        $q = $this->getConnection()->prepare("SELECT * FROM groupe WHERE id_group = :id_group");
        $q->execute(['id_group' => $id_group]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    // Méthode pour mettre à jour un groupe existant
    public function update(int $id_group, string $nom_group, int $statut)
    {
        $q = $this->getConnection()->prepare("UPDATE groupe 
                                              SET nom_group = :nom_group, statut = :statut 
                                              WHERE id_group = :id_group");
        return $q->execute([
            'nom_group' => $nom_group,
            'statut' => $statut,
            'id_group' => $id_group
        ]);
    }

    // Méthode pour supprimer un groupe
    public function delete(int $id_group): bool
    {
        $q = $this->getConnection()->prepare("DELETE FROM groupe WHERE id_group = :id_group");
        return $q->execute(['id_group' => $id_group]);
    }
}
?>

<?php
include_once "Database.php";

class Note extends Database
{
    public function create(int $id_evaluation, int $id_class, string $code_mat, int $id, float $note, int $etat_Ann_app, int $id_annee, int $id_tri)
{
    try {
        // Vérifier si une note existe déjà pour ces critères
        $queryCheck = "SELECT id_note FROM note 
                       WHERE id_evaluation = :id_evaluation AND id_class = :id_class 
                             AND code_mat = :code_mat AND id = :id";
        $stmtCheck = $this->getConnection()->prepare($queryCheck);
        $stmtCheck->execute([
            'id_evaluation' => $id_evaluation,
            'id_class' => $id_class,
            'code_mat' => $code_mat,
            'id' => $id
        ]);

        $existingNote = $stmtCheck->fetch(PDO::FETCH_OBJ);

        if ($existingNote) {
            // Si une note existe, effectuer une mise à jour
            $queryUpdate = "UPDATE note 
                            SET note = :note, etat_Ann_app = :etat_Ann_app, 
                                id_annee = :id_annee, id_tri = :id_tri 
                            WHERE id_note = :id_note";
            $stmtUpdate = $this->getConnection()->prepare($queryUpdate);
            return $stmtUpdate->execute([
                'note' => $note,
                'etat_Ann_app' => $etat_Ann_app,
                'id_annee' => $id_annee,
                'id_tri' => $id_tri,
                'id_note' => $existingNote->id_note
            ]);
        } else {
            // Si aucune note n'existe, effectuer une insertion
            $queryInsert = "INSERT INTO note (id_evaluation, id_class, code_mat, id, note, etat_Ann_app, id_annee, id_tri) 
                            VALUES (:id_evaluation, :id_class, :code_mat, :id, :note, :etat_Ann_app, :id_annee, :id_tri)";
            $stmtInsert = $this->getConnection()->prepare($queryInsert);
            return $stmtInsert->execute([
                'id_evaluation' => $id_evaluation,
                'id_class' => $id_class,
                'code_mat' => $code_mat,
                'id' => $id,
                'note' => $note,
                'etat_Ann_app' => $etat_Ann_app,
                'id_annee' => $id_annee,
                'id_tri' => $id_tri
            ]);
        }
    } catch (PDOException $e) {
        error_log("Erreur lors de l'insertion/mise à jour de la note : " . $e->getMessage());
        return false;
    }
}


    public function read()
    {
        return $this->getConnection()->query("SELECT * FROM note ORDER BY id_note")->fetchAll(PDO::FETCH_OBJ);
    }

    public function countNotes(): int
    {
        return (int)$this->getConnection()->query("SELECT count(id_note) as count FROM note")->fetch()[0];
    }

    public function getSingleNote(int $id_note)
    {
        $q = $this->getConnection()->prepare("SELECT * FROM note WHERE id_note = :id_note");
        $q->execute(['id_note' => $id_note]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(int $id_note, int $id_evaluation, int $id_class, string $code_mat, int $id, float $note, int $etat_Ann_app, int $id_annee, int $id_tri)
    {
        $q = $this->getConnection()->prepare("UPDATE note 
                                              SET id_evaluation = :id_evaluation, id_class = :id_class, 
                                                  code_mat = :code_mat, id = :id, note = :note, 
                                                  etat_Ann_app = :etat_Ann_app, id_annee = :id_annee,
                                                  id_tri = :id_tri 
                                              WHERE id_note = :id_note");
        return $q->execute([
            'id_evaluation' => $id_evaluation,
            'id_class' => $id_class,
            'code_mat' => $code_mat,
            'id' => $id,
            'note' => $note,
            'etat_Ann_app' => $etat_Ann_app,
            'id_annee' => $id_annee,
            'id_tri' => $id_tri,
            'id_note' => $id_note
        ]);
    }

    public function delete(int $id_note): bool
    {
        $q = $this->getConnection()->prepare("DELETE FROM note WHERE id_note = :id_note");
        return $q->execute(['id_note' => $id_note]);
    }
}
?>

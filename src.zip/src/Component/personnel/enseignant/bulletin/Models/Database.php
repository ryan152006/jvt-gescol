<?php

class Database
{
    const HOST = "localhost";
    const DBNAME = "etablissement";
    const USER = "root";
    const PASS = "";

    protected $connection;

    public function __construct()
    {
        try {
            $this->connection = new PDO("mysql:host=" . self::HOST . ";dbname=" . self::DBNAME, self::USER, self::PASS);
            // Echo "je suis connecté";
        } catch (PDOException $ex) {
            header("Location: error.php");
            exit();
            die("Erreur: " . $ex);
        }
    }

    public function getConnection()
    {
        return $this->connection;
    }
}

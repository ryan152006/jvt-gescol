<?php
include_once "Database.php";

class Evaluation extends Database
{
    public function create(string $type_evaluation, string $dateDebut_eval, string $dateFin_eval, string $description, int $etat_evaluation, int $id_tri, int $id_annee)
    {
        $q = $this->getConnection()->prepare("INSERT INTO evaluations (type_evaluation, dateDebut_eval, dateFin_eval, description, etat_evaluation, id_tri, id_annee) 
                                              VALUES (:type_evaluation, :dateDebut_eval, :dateFin_eval, :description, :etat_evaluation, :id_tri, :id_annee)");
        return $q->execute([
            'type_evaluation' => $type_evaluation,
            'dateDebut_eval' => $dateDebut_eval,
            'dateFin_eval' => $dateFin_eval,
            'description' => $description,
            'etat_evaluation' => $etat_evaluation,
            'id_tri' => $id_tri,
            'id_annee' => $id_annee
        ]);
    }

    public function read()
    {
        return $this->getConnection()->query("SELECT * FROM evaluations ORDER BY id_evaluation")->fetchAll(PDO::FETCH_OBJ);
    }

    public function getSingleEvaluation(int $id_evaluation)
    {
        $q = $this->getConnection()->prepare("SELECT * FROM evaluations WHERE id_evaluation = :id_evaluation");
        $q->execute(['id_evaluation' => $id_evaluation]);
        return $q->fetch(PDO::FETCH_OBJ);
    }

    public function update(int $id_evaluation, string $type_evaluation, string $dateDebut_eval, string $dateFin_eval, string $description, int $etat_evaluation, int $id_tri, int $id_annee)
    {
        $q = $this->getConnection()->prepare("UPDATE evaluations 
                                              SET type_evaluation = :type_evaluation, dateDebut_eval = :dateDebut_eval, 
                                                  dateFin_eval = :dateFin_eval, description = :description, 
                                                  etat_evaluation = :etat_evaluation, id_tri = :id_tri, 
                                                  id_annee = :id_annee 
                                              WHERE id_evaluation = :id_evaluation");
        return $q->execute([
            'type_evaluation' => $type_evaluation,
            'dateDebut_eval' => $dateDebut_eval,
            'dateFin_eval' => $dateFin_eval,
            'description' => $description,
            'etat_evaluation' => $etat_evaluation,
            'id_tri' => $id_tri,
            'id_annee' => $id_annee,
            'id_evaluation' => $id_evaluation
        ]);
    }

    public function delete(int $id_evaluation): bool
    {
        $q = $this->getConnection()->prepare("DELETE FROM evaluations WHERE id_evaluation = :id_evaluation");
        return $q->execute(['id_evaluation' => $id_evaluation]);
    }
}
?>

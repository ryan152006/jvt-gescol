<?php
// Inclure la connexion à la base de données
include('../../../../Traitement/connexion.php'); // Assurez-vous que ce fichier est correctement inclus

// Définir un tableau pour la réponse
$response = array();

// SQL pour récupérer les années scolaires
$query = "SELECT * FROM annee_scolaire ORDER BY dateDebut_A DESC";

// Exécuter la requête
$stmt = $conn->prepare($query);
$stmt->execute();

// Récupérer toutes les années scolaires
$annees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Vérifier si des années scolaires ont été trouvées
if (count($annees) > 0) {
    $response['success'] = true;
    $response['annees'] = $annees; // Les années scolaires récupérées
} else {
    $response['success'] = false;
    $response['message'] = 'Aucune année scolaire disponible.';
}

// Définir le type de contenu comme JSON
header('Content-Type: application/json');

// Renvoyer la réponse au format JSON
echo json_encode($response);

// Fermer la connexion à la base de données
$conn = null;
?>

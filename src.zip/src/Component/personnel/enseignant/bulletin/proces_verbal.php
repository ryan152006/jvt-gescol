<?php 
    // Démarrer la session
    session_start();
    require_once 'Models/Database.php';
    include_once "Models/matiere.php";

    // Récupérer les identifiants depuis les variables de session
 
    $id_annee = $_SESSION['id_annee'];
    $id_class = isset($_GET['id_class']) ? $_GET['id_class'] : null;
    $id_evaluation = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
    $id_tri = isset($_GET['id_tri']) ? $_GET['id_tri'] : null;
    $id_eva = isset($_GET['id_evaluation']) ? $_GET['id_evaluation'] : null;
    // Connexion à la base de données
    $db = new Database();
    $connection = $db->getConnection();

    // Récupérer la liste des matières pour la classe et l'année scolaire choisies
    $sqlMatiere = "SELECT code_mat, nom_matiere, coeficient, abr_mat FROM matiere 
                WHERE id_class = :id_class AND id_annee = :id_annee";
    $stmtMatiere = $connection->prepare($sqlMatiere);
    $stmtMatiere->bindParam(':id_class', $id_class, PDO::PARAM_INT);
    $stmtMatiere->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
    $stmtMatiere->execute();
    $matieres = $stmtMatiere->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les informations des élèves et leurs notes pour l'évaluation choisie
    $sql = "
        SELECT e.id, e.code_elev, e.nom_elev, e.prenom_elev, m.code_mat, m.nom_matiere, m.coeficient,
            IFNULL(n.note, '/') AS note
        FROM eleve e
        LEFT JOIN note n ON e.id = n.id AND n.id_class = :id_class AND n.id_evaluation = :id_evaluation AND n.id_annee = :id_annee
        LEFT JOIN matiere m ON m.code_mat = n.code_mat AND m.id_class = :id_class AND m.id_annee = :id_annee
        WHERE e.id_class = :id_class
        ORDER BY e.nom_elev ASC, m.nom_matiere ASC
    ";
    $stmt = $connection->prepare($sql);
    $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
    $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
    $stmt->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);
    $stmt->execute();
    $eleves = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Organiser les données par élève et matière pour calculer les moyennes et le rang
    $eleveData = [];
    foreach ($eleves as $eleve) {
        $id = $eleve['id'];
        if (!isset($eleveData[$id])) {
            $eleveData[$id] = [
                'id' => $eleve['id'],
                'code_elev' => $eleve['code_elev'],
                'nom_elev' => $eleve['nom_elev'],
                'prenom_elev' => $eleve['prenom_elev'],
                'notes' => [],
                'totalCoef' => 0,
                'totalNoteCoef' => 0
            ];
        }
        $eleveData[$id]['notes'][$eleve['code_mat']] = $eleve['note'];
        if ($eleve['note'] !== '/') {
            $eleveData[$id]['totalNoteCoef'] += $eleve['note'] * $eleve['coeficient'];
            $eleveData[$id]['totalCoef'] += $eleve['coeficient'];
        }
    }

    // Calcul des moyennes et des rangs
    $moyennes = [];
    foreach ($eleveData as $id => $data) {
        $moyennes[$id] = ($data['totalCoef'] > 0) ? round($data['totalNoteCoef'] / $data['totalCoef'], 2) : '/';
    }
    arsort($moyennes); // Trie les moyennes pour le classement

    // Attribuer les rangs
    $rangs = [];
    $rank = 1;
    foreach ($moyennes as $id => $moyenne) {
        $rangs[$id] = $rank++;
    }

    // Fonction pour afficher l'appréciation en fonction de la moyenne
    function getAppreciation($moyenne) {
        if ($moyenne >= 18) return "Compétences très bien acquises";
        if ($moyenne >= 14) return "Compétences bien acquises";
        if ($moyenne >= 12) return "Compétences acquises";
        if ($moyenne >= 10) return "Compétences moyennement acquises";
        return "Compétences non acquises";
    }

    /** -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */

    // selectionner classe

        $sql = "SELECT * FROM classe WHERE id_class = :id_class"; 

        // Préparer la requête
        $stmt = $connection->prepare($sql);

        // Lier la variable :id_annee à la valeur de $id_annee
        $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);

        // Exécuter la requête
        $stmt->execute();

        // Récupérer le résultat
        $result1 = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifier si la description_periode est disponible
        if ($result1) {
            $nom_class = $result1['nom_class'];
        } else {
            $id_class = "Aucune description trouvée pour l'année scolaire avec id_annee = $id_class.";
        }


    // selectionner année

    // Requête SQL pour récupérer description_periode
        $sql = "SELECT * FROM annee_scolaire WHERE id_annee = :id_annee"; 

        // Préparer la requête
        $stmt = $connection->prepare($sql);

        // Lier la variable :id_annee à la valeur de $id_annee
        $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);

        // Exécuter la requête
        $stmt->execute();

        // Récupérer le résultat
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifier si la description_periode est disponible
        if ($result) {
            $description_periode = $result['nom_annee'];
        } else {
            $description_periode = "Aucune description trouvée pour l'année scolaire avec id_annee = $id_annee.";
        }

    // selectionner periode

    $sql = "SELECT * FROM evaluations WHERE id_evaluation = :id_evaluation"; 

        // Préparer la requête
        $stmt = $connection->prepare($sql);

        // Lier la variable :id_annee à la valeur de $id_annee
        $stmt->bindParam(':id_evaluation', $id_evaluation, PDO::PARAM_INT);

        // Exécuter la requête
        $stmt->execute();

        // Récupérer le résultat
        $result2 = $stmt->fetch(PDO::FETCH_ASSOC);

        // Vérifier si la description_periode est disponible
        if ($result2) {
            $id_evaluation = $result2['type_evaluation'];
        } else {
            $id_evaluation = "Aucune description trouvée pour l'année scolaire avec id_annee = $id_evaluation.";
        }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bulletin de Classe</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-size: 11px;
        }
        .container {
            max-width: 100%;
            width: 297mm; /* Largeur A4 en mm, s'adaptera à la taille de l'écran */
            min-height: 210mm; /* Hauteur A4 pour les grands écrans */
            margin: 20px auto; /* Marge supérieure pour l’éloignement du haut */
            padding: 20px; /* Espacement interne pour plus de confort */
            background-color: #fff;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1); /* Légère ombre pour un effet de carte */
        }

        @media (max-width: 768px) {
            .container {
                width: 100%; /* Prend toute la largeur sur les petits écrans */
                padding: 10px; /* Réduction de l'espacement pour éviter le débordement */
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 5px; /* Ajustement pour les très petits écrans */
            }
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
            font-size: 18px;
        }
        .header h2 {
            font-size: 24px;
            font-weight: bold;
        }
        .header p {
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f1f1f1;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .left-align {
            text-align: left;
        }
        .center-align {
            text-align: center;
        }
        /* Séparer avec un trait fin */
        .hr-fine {
        border: none;
        border-top: 2px solid black;
        margin: 0; /* Supprime les marges autour de <hr> */
        padding: 0; /* Supprime le padding */
        }
         /* Réduit le padding pour rendre l'interligne encore plus petit */
        .table-sm td, .table-sm th {
            padding: 2px 4px; /* Réduit encore plus le padding */
        }

        /* Séparer avec un trait épais */
        .hr-thick {
        border: none;
        border-top: 5px solid black;
        margin: 0; /* Supprime les marges autour de <hr> */
        padding: 0; /* Supprime le padding */
        }
        /* Style pour imprimer en mode paysage */
        @media print {
            @page {
                size: A4 landscape; /* Définir le format A4 en orientation paysage */
            }
            /* Masquer le bouton "Imprimer" lors de l'impression */
            #printButton {
                display: none;
            }
            @media print {
                /* Cache les en-têtes et pieds de page du navigateur */
                @page {
                    margin: 0;
                }
                body {
                    margin: 0;
                }
                /* Supprime les éléments comme les numéros de page */
                footer, header, .no-print {
                    display: none;
                }
            }

        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

</head>
<body>
        <div class="d-flex justify-content-between mb-3 my-4 w-100">
                <!-- Bouton Retour aligné à gauche -->
                <a href="eleve.php?id_evaluation=<?= urlencode($id_eva) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>"><button class="btn btn-secondary" id="printButton">
                    <i class="bi bi-arrow-left-circle"></i> Retour
                </button></a>
                <button onclick="imprimerFacture()" id="printButton" class="btn btn-primary"> <i class="bi bi-printer"></i> Imprimer le relevé de note</button>
                
        </div>


    <div class="container" id="facture">

        <!-- Div positionnée à gauche -->
        <div class="container-fluid">
            <div class="row">
            <!-- Div à gauche -->
            <div class="text-center col-4 text-left p-3" style="border: none;"><b>
                <p class="text-bold fw-bold mb-0 fs-6">MINISTERE DE L'ENSEIGNEMENT SECONDAIRE</p>
                <p class="fw-bold mb-0 fs-6">COLLEGE JEAN XXIII D'EFOK</p>
                <p class="fw-bold mb-0 fs-6">B.P : 22, Tel : 697 600 537 EFOK</p></b>
            </div>

            <!-- Div centrée -->
            <div class="col-4 text-center p-3" style="border: none;">
                <p class="fw-bold mb-0 fs-6 rounded-full"><img src="../../../../Assets/logoecole.jpg" style="border-radius: 50%;" class="rounded-full"  alt="LOGO" width="100px" height="100px"></p>
            </div>

            <!-- Div à droite -->
            <div class="text-center col-4 text-end p-3" style="border: none;"><b>
                <p class="text-bold fw-bold mb-0 fs-6">REPUBLIQUE DU CAMEROUN</p>
                <p class="fw-bold mb-0 fs-6">Paix-Travail-Patrie</p>
                <p class="fw-bold mb-0 fs-6">Année-Scolaire : <?php echo htmlspecialchars($description_periode); ?></p>
            </b></div>
            </div>
        </div>
        
        <!-- Trait épais pour séparer les sections -->
            <hr class="hr-thick">
            
        <!-- Entête administrative -->
        <div class="header">
        <p class="text-left">Date: <?php echo date('d/m/Y - H.i.s'); ?></p>
            <h2>PROCES-VERBAL DU CONSEIL DE CLASSE</h2>
            
            <p class="text-left">Classe: <?= htmlspecialchars($nom_class) ?> || Période: <?= htmlspecialchars($id_evaluation) ?></p>
        </div>

        <!-- Table des résultats -->
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Matricule</th>
                        <th>Noms et prénoms</th>
                        <?php foreach ($matieres as $matiere): ?>
                            <th><?= htmlspecialchars($matiere['abr_mat']) ?></th>
                        <?php endforeach; ?>
                        <th>Moy/20</th>
                        <th>Rgs</th>
                        <th>Appr.</th>
                        <th>Obs</th>
                    </tr>
                    <tr>
                        <th colspan="3"></th>
                        <?php foreach ($matieres as $matiere): ?>
                            <th><?= htmlspecialchars($matiere['coeficient']) ?></th>
                        <?php endforeach; ?>
                        <th colspan="3"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $index = 1;
                    foreach ($eleveData as $id => $data): 
                        $moyenne = $moyennes[$id];
                        $rang = $rangs[$id];
                    ?>
                    <tr class="table-sm">
                        <td class="center-align mb-0"><?= $index++ ?></td>
                        <td class="center-align"><?= htmlspecialchars($data['code_elev']) ?><?= htmlspecialchars($data['id']) ?></td>
                        <td class="left-align"><?= htmlspecialchars($data['nom_elev']) ?> <?= htmlspecialchars($data['prenom_elev']) ?></td>
                        <?php foreach ($matieres as $matiere): ?> 
                            <td class="center-align"><?= isset($data['notes'][$matiere['code_mat']]) ? htmlspecialchars($data['notes'][$matiere['code_mat']]) : '/' ?></td>
                        <?php endforeach; ?>
                        <td class="center-align"><?= $moyenne ?></td>
                        <td class="center-align"><?= $rang ?>e</td>
                        <td class="left-align"><?= getAppreciation($moyenne) ?></td>
                        <td class="center-align"></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

             

    <script>
        function imprimerFacture() {
            var content = document.getElementById('facture');  // Sélectionner l'élément contenant la facture
            var printWindow = window.open('', '', 'width=800,height=600');  // Ouvrir une nouvelle fenêtre d'impression

            printWindow.document.write('<html><head><title>Impression du procès-verbal</title>');
            printWindow.document.write('<style>');
            printWindow.document.write('body { font-family: Arial, sans-serif; font-size: 12px; }');
            printWindow.document.write('@media print { @page { size: A4 landscape; } }'); // Force l'orientation paysage
            printWindow.document.write('</style>');
            printWindow.document.write('</head><body>');
            printWindow.document.write(content.innerHTML);  // Ajouter le contenu de la facture à la nouvelle fenêtre
            printWindow.document.write('</body></html>');

            printWindow.document.close();  // Fermer le document
            printWindow.print();  // Lancer l'impression
        }
    </script>
</body>
</html>
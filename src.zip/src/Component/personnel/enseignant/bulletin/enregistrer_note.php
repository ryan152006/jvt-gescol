<?php
// Démarrer la session pour pouvoir utiliser les variables de session
session_start();

include_once "Models/Database.php";
include_once "Models/note.php";

// Créer une nouvelle instance de la classe Note
$note = new Note();

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_eleve = $_GET['id_elev'];
    // Récupérer les données du formulaire
    $id_evaluation = $_POST['id_evaluation'];
    $id_class = $_POST['id_class'];
    $code_mat = $_POST['matiere'];
    $id = $_POST['id'];
    $note_value = $_POST['note'];
    $etat_Ann_app = $_POST['etat'];
    $id_annee = $_POST['id_annee'];
    $id_tri = $_POST['id_tri'];

    // Vérifier le format de la note (deux décimales maximum)
    if (preg_match('/^\d+(\.\d{1,2})?$/', $note_value)) {
        // Enregistrer la note dans la base de données
        if ($note->create($id_evaluation, $id_class, $code_mat, $id, $note_value, $etat_Ann_app, $id_annee, $id_tri)) {
            $_SESSION['success'] = "Note enregistrée/mise à jour avec succès!";
        } else {
            $_SESSION['error'] = "Erreur lors de l'enregistrement/mise à jour de la note.";
        }
        
    } else {
        $_SESSION['error'] = "Le format de la note est incorrect. Veuillez entrer une note avec au maximum deux décimales Exp: 12.75 !";
    }

    // Rediriger vers la page note.php pour afficher le message
    header('Location: noter.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri) . '&id_elev=' .urlencode($id_eleve));
    exit;
}
?>

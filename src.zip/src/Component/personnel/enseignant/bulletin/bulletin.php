<?php
    require_once 'Models/Database.php';
    require_once 'Models/evaluation.php';
    require_once 'Models/groupe.php';
    require_once 'Models/matiere.php';
    require_once 'Models/competence.php';

    session_start();
    $id_class = $_GET['id_class'];
    $id_eleve = $_GET['id_elev'];
    $id_evaluation = $_GET['id_evaluation'];
    $id_annee = $_SESSION['id_annee'];
     $id_tri = $_GET['id_tri'];
    try {
        $db = new Database();
        $connection = $db->getConnection();

        // Selectionner l'élève en question
        $sql = "SELECT * FROM eleve WHERE id = :id_eleve"; 
        $stmt = $connection->prepare($sql);
        $stmt->execute([':id_eleve' => $id_eleve]);
        $eleve = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$eleve) {
            echo "Élève introuvable.";
            exit;
        }
        $nom_elev = isset($eleve['nom_elev']) ? $eleve['nom_elev'] : '';
        $prenom_elev = isset($eleve['prenom_elev']) ? $eleve['prenom_elev'] : '';
        $date_naiss = isset($eleve['date_naiss']) ? $eleve['date_naiss'] : '';
        $lieu_naiss = isset($eleve['lieu_naiss']) ? $eleve['lieu_naiss'] : '';
        $nbre_elev = isset($class['nbre_elev']) ? $class['nbre_elev'] : '';
        $sexe_elev = isset($eleve['sexe_elev']) ? $eleve['sexe_elev'] : '';
        $code_elev = isset($eleve['code_elev']) ? $eleve['code_elev'] : '';
        $id = isset($eleve['id']) ? $eleve['id'] : '';
        $categorie = isset($eleve['categorie']) ? $eleve['categorie'] : '';
        $nom_enseig = isset($class['nom_enseig']) ? $class['nom_enseig'] : '';
        $nom_tuteur = isset($eleve['nom_tuteur']) ? $eleve['nom_tuteur'] : '';
        $tel_tuteur = isset($eleve['tel_tuteur']) ? $eleve['tel_tuteur'] : '';

        // Selectionner l'année
        $sql = "SELECT * FROM annee_scolaire WHERE id_annee = :id_annee"; 
        $stmt = $connection->prepare($sql);
        $stmt->execute([':id_annee' => $id_annee]);
        $annee = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$annee) {
            echo "Année scolaire introuvable.";
            exit;
        }
        $description_periode = $annee['nom_annee'];

        // Selectionner la classe de l'élève
        $sql = "SELECT * FROM classe WHERE id_class = :id_class"; 
        $stmt = $connection->prepare($sql);
        $stmt->execute([':id_class' => $id_class]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$class) {
            echo "Classe introuvable.";
            exit;
        }
        $nom_class = $class['nom_class'];
        $nbre_elev = $class['nbre_elev'];
        $nom_enseig = $class['nom_enseig'];
        // Sélectionner les matières par groupe
        $sql_matiere = "
            SELECT m.*, g.nom_group, m.Nom_ens
            FROM matiere m
            JOIN groupe g ON m.id_group = g.id_group
            WHERE m.id_class = :id_class AND m.id_annee = :id_annee
            ORDER BY g.id_group ASC, m.nom_matiere";
        $stmt = $connection->prepare($sql_matiere);
        $stmt->execute([':id_class' => $id_class, ':id_annee' => $id_annee]);
        $matieres = $stmt->fetchAll(PDO::FETCH_ASSOC);


        // Récupérer les compétences pour chaque matière et trimestre
        $sql_competence = "
            SELECT c.*, m.nom_matiere
            FROM competence c
            JOIN matiere m ON c.code_mat = m.code_mat
            WHERE c.id_annee = :id_annee AND c.id_class = :id_class AND c.id_tri = :id_tri";
        $stmt = $connection->prepare($sql_competence);
        $stmt->execute([':id_annee' => $id_annee, ':id_class' => $id_class, ':id_tri' => $id_tri]);
        $competences = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Récupérer les notes des évaluations pour chaque élève
        $sql_notes = "
            SELECT n.note, n.code_mat, m.nom_matiere, n.id_evaluation, m.coeficient
            FROM note n
            JOIN matiere m ON n.code_mat = m.code_mat
            WHERE n.id_class = :id_class 
            AND n.id_annee = :id_annee 
            AND n.id_tri = :id_tri 
            AND n.id = :id_eleve";
        $stmt = $connection->prepare($sql_notes);
        $stmt->execute([
            ':id_class' => $id_class, 
            ':id_annee' => $id_annee, 
            ':id_tri' => $id_tri, 
            ':id_eleve' => $id_eleve
        ]);
        $notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Sélection des matières avec leurs coefficients pour la classe et l'année spécifiée
        $sqlMatiere = "
            SELECT m.code_mat, m.coeficient 
            FROM matiere m 
            WHERE m.id_class = :id_class AND m.id_annee = :id_annee";
        $stmtMatiere = $connection->prepare($sqlMatiere);
        $stmtMatiere->execute([':id_class' => $id_class, ':id_annee' => $id_annee]);
        $matieres = $stmtMatiere->fetchAll(PDO::FETCH_ASSOC);

        // Récupérer les élèves de la classe
        $sqlEleve = "SELECT id FROM eleve WHERE id_class = :id_class";
        $stmtEleve = $connection->prepare($sqlEleve);
        $stmtEleve->execute([':id_class' => $id_class]);
        $eleves = $stmtEleve->fetchAll(PDO::FETCH_ASSOC);

        $moyennesTrimestrielles = [];
        $moyenneEleveSpecifique = null;

        foreach ($eleves as $eleve) {
            $id_eleve_courant = $eleve['id'];
            $sommeNotesEval1 = 0;
            $sommeNotesEval2 = 0;
            $sommeCoefEval1 = 0;
            $sommeCoefEval2 = 0;

            foreach ($matieres as $matiere) {
                $code_mat = $matiere['code_mat'];
                $coef = $matiere['coeficient'];

                // Moyenne pour l'évaluation 1
                $sqlEval1 = "
                    SELECT note 
                    FROM note 
                    WHERE id_annee = :id_annee 
                    AND id_tri = :id_tri 
                    AND id_class = :id_class 
                    AND id = :id_eleve 
                    AND code_mat = :code_mat 
                    AND id_evaluation = 1";
                $stmtEval1 = $connection->prepare($sqlEval1);
                $stmtEval1->execute([
                    ':id_annee' => $id_annee,
                    ':id_tri' => $id_tri,
                    ':id_class' => $id_class,
                    ':id_eleve' => $id_eleve_courant,
                    ':code_mat' => $code_mat
                ]);
                $noteEval1 = $stmtEval1->fetchColumn();
                if ($noteEval1 !== false) {
                    $sommeNotesEval1 += $noteEval1 * $coef;
                    $sommeCoefEval1 += $coef;
                }

                // Moyenne pour l'évaluation 2
                $sqlEval2 = "
                    SELECT note 
                    FROM note 
                    WHERE id_annee = :id_annee 
                    AND id_tri = :id_tri 
                    AND id_class = :id_class 
                    AND id = :id_eleve 
                    AND code_mat = :code_mat 
                    AND id_evaluation = 2";
                $stmtEval2 = $connection->prepare($sqlEval2);
                $stmtEval2->execute([
                    ':id_annee' => $id_annee,
                    ':id_tri' => $id_tri,
                    ':id_class' => $id_class,
                    ':id_eleve' => $id_eleve_courant,
                    ':code_mat' => $code_mat
                ]);
                $noteEval2 = $stmtEval2->fetchColumn();
                if ($noteEval2 !== false) {
                    $sommeNotesEval2 += $noteEval2 * $coef;
                    $sommeCoefEval2 += $coef;
                }
            }

            $moyenneEval1 = $sommeCoefEval1 > 0 ? $sommeNotesEval1 / $sommeCoefEval1 : 0;
            $moyenneEval2 = $sommeCoefEval2 > 0 ? $sommeNotesEval2 / $sommeCoefEval2 : 0;

            $moyenneTrimestrielle = ($moyenneEval1 + $moyenneEval2) / 2;
            $moyennesTrimestrielles[] = [
                'id_eleve' => $id_eleve_courant,
                'moyenne' => $moyenneTrimestrielle
            ];

            if ($id_eleve_courant == $id_eleve) {
                $moyenneEleveSpecifique = $moyenneTrimestrielle;
            }
        }
    
        // Trier les moyennes par ordre décroissant
        usort($moyennesTrimestrielles, fn($a, $b) => $b['moyenne'] <=> $a['moyenne']);
    
        // Déterminer le rang de l'élève spécifique
        $rang = array_search($id_eleve, array_column($moyennesTrimestrielles, 'id_eleve')) + 1;
    
        // Résultats globaux
        $premiereMoyenne = $moyennesTrimestrielles[count($moyennesTrimestrielles) - 1]['moyenne'];
        $derniereMoyenne = $moyennesTrimestrielles[0]['moyenne'];
        $derniereMoyenne = $derniereMoyenne - 0.03;
        $nombreReussites = count(array_filter($moyennesTrimestrielles, fn($item) => $item['moyenne'] >= 10));
    
        // Calcul de la moyenne générale
        $sommeMoyennes = array_sum(array_column($moyennesTrimestrielles, 'moyenne'));
        $moyenneGenerale = count($moyennesTrimestrielles) > 0 ? $sommeMoyennes / count($moyennesTrimestrielles) : 0;
    
        // Calcul du taux de réussite
        $tauxReussite = count($moyennesTrimestrielles) > 0 ? ($nombreReussites / count($moyennesTrimestrielles)) * 100 : 0;

    } catch (Exception $e) {
        echo "Erreur : " . $e->getMessage();
    }
?>
    <?php

try {
    // Récupérer les matières avec leurs coefficients pour la classe et l'année spécifiée
    $sqlMatiere = "
        SELECT m.code_mat, m.coeficient 
        FROM matiere m 
        WHERE m.id_class = :id_class AND m.id_annee = :id_annee";
    $stmtMatiere = $connection->prepare($sqlMatiere);
    $stmtMatiere->execute([':id_class' => $id_class, ':id_annee' => $id_annee]);
    $matieres = $stmtMatiere->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les élèves de la classe
    $sqlEleve = "SELECT id FROM eleve WHERE id_class = :id_class";
    $stmtEleve = $connection->prepare($sqlEleve);
    $stmtEleve->execute([':id_class' => $id_class]);
    $eleves = $stmtEleve->fetchAll(PDO::FETCH_ASSOC);

    $moyennesTrimestrielles = []; // Stocker les moyennes trimestrielles pour chaque élève

    foreach ($eleves as $eleve) {
        $id_eleve_courant = $eleve['id'];
        $sommeNotesEval1 = 0;
        $sommeNotesEval2 = 0;
        $sommeCoefEval1 = 0;
        $sommeCoefEval2 = 0;

        foreach ($matieres as $matiere) {
            $code_mat = $matiere['code_mat'];
            $coef = $matiere['coeficient'];

            // Moyenne pour l'évaluation 1
            $sqlEval1 = "
                SELECT note 
                FROM note 
                WHERE id_annee = :id_annee 
                AND id_tri = :id_tri 
                AND id_class = :id_class 
                AND id = :id_eleve 
                AND code_mat = :code_mat 
                AND id_evaluation = 1"; // ID de l'évaluation 1
            $stmtEval1 = $connection->prepare($sqlEval1);
            $stmtEval1->execute([
                ':id_annee' => $id_annee,
                ':id_tri' => $id_tri,
                ':id_class' => $id_class,
                ':id_eleve' => $id_eleve_courant,
                ':code_mat' => $code_mat
            ]);
            $noteEval1 = $stmtEval1->fetchColumn();
            if ($noteEval1 !== false) {
                $sommeNotesEval1 += $noteEval1 * $coef;
                $sommeCoefEval1 += $coef;
            }

            // Moyenne pour l'évaluation 2
            $sqlEval2 = "
                SELECT note 
                FROM note 
                WHERE id_annee = :id_annee 
                AND id_tri = :id_tri 
                AND id_class = :id_class 
                AND id = :id_eleve 
                AND code_mat = :code_mat 
                AND id_evaluation = 2"; // ID de l'évaluation 2
            $stmtEval2 = $connection->prepare($sqlEval2);
            $stmtEval2->execute([
                ':id_annee' => $id_annee,
                ':id_tri' => $id_tri,
                ':id_class' => $id_class,
                ':id_eleve' => $id_eleve_courant,
                ':code_mat' => $code_mat
            ]);
            $noteEval2 = $stmtEval2->fetchColumn();
            if ($noteEval2 !== false) {
                $sommeNotesEval2 += $noteEval2 * $coef;
                $sommeCoefEval2 += $coef;
            }
        }

        // Calculer les moyennes pondérées des deux évaluations
        $moyenneEval1 = $sommeCoefEval1 > 0 ? $sommeNotesEval1 / $sommeCoefEval1 : 0;
        $moyenneEval2 = $sommeCoefEval2 > 0 ? $sommeNotesEval2 / $sommeCoefEval2 : 0;

        // Calcul de la moyenne trimestrielle
        $moyenneTrimestrielle = ($moyenneEval1 + $moyenneEval2) / 2;
        $moyennesTrimestrielles[] = [
            'id_eleve' => $id_eleve_courant,
            'moyenne' => $moyenneTrimestrielle
        ];
    }

    // Trier les moyennes par ordre décroissant pour déterminer le rang
    usort($moyennesTrimestrielles, fn($a, $b) => $b['moyenne'] <=> $a['moyenne']);

    // Déterminer le rang de l'élève spécifique
    $rrang = array_search($id_eleve, array_column($moyennesTrimestrielles, 'id_eleve')) + 1;
    
    echo "Rang de l'élève : " . $rrang;

} catch (Exception $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
<?php


try {
    // Sélectionner les matières et leurs coefficients
    $sql_matiere = "
        SELECT m.code_mat, m.nom_matiere, m.coeficient 
        FROM matiere m
        WHERE m.id_class = :id_class AND m.id_annee = :id_annee
        ORDER BY m.nom_matiere";
    $stmt = $connection->prepare($sql_matiere);
    $stmt->execute([':id_class' => $id_class, ':id_annee' => $id_annee]);
    $matieres = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les élèves de la classe
    $sqlEleve = "SELECT id FROM eleve WHERE id_class = :id_class";
    $stmtEleve = $connection->prepare($sqlEleve);
    $stmtEleve->execute([':id_class' => $id_class]);
    $eleves = $stmtEleve->fetchAll(PDO::FETCH_ASSOC);

    $rangsParMatiere = [];

    // Calcul des moyennes et des rangs par matière pour chaque élève
    foreach ($matieres as $matiere) {
        $code_mat = $matiere['code_mat'];
        $coef = $matiere['coeficient'];

        $moyennesParEleve = [];

        foreach ($eleves as $eleve) {
            $id_eleve_courant = $eleve['id'];

            $sommeNotesEval1 = 0;
            $sommeNotesEval2 = 0;
            $sommeCoefEval1 = 0;
            $sommeCoefEval2 = 0;

            // Récupérer la note de l'évaluation 1
            $sqlEval1 = "
                SELECT note 
                FROM note 
                WHERE id_annee = :id_annee 
                AND id_tri = :id_tri 
                AND id_class = :id_class 
                AND id = :id_eleve 
                AND code_mat = :code_mat 
                AND id_evaluation = :id_evaluation";
            $stmtEval1 = $connection->prepare($sqlEval1);
            $stmtEval1->execute([
                ':id_annee' => $id_annee,
                ':id_tri' => $id_tri,
                ':id_class' => $id_class,
                ':id_eleve' => $id_eleve_courant,
                ':code_mat' => $code_mat,
                ':id_evaluation' => 1
            ]);
            $noteEval1 = $stmtEval1->fetchColumn();
            if ($noteEval1 !== false) {
                $sommeNotesEval1 += $noteEval1 * $coef;
                $sommeCoefEval1 += $coef;
            }

            // Récupérer la note de l'évaluation 2
            $sqlEval2 = "
                SELECT note 
                FROM note 
                WHERE id_annee = :id_annee 
                AND id_tri = :id_tri 
                AND id_class = :id_class 
                AND id = :id_eleve 
                AND code_mat = :code_mat 
                AND id_evaluation = :id_evaluation";
            $stmtEval2 = $connection->prepare($sqlEval2);
            $stmtEval2->execute([
                ':id_annee' => $id_annee,
                ':id_tri' => $id_tri,
                ':id_class' => $id_class,
                ':id_eleve' => $id_eleve_courant,
                ':code_mat' => $code_mat,
                ':id_evaluation' => 2
            ]);
            $noteEval2 = $stmtEval2->fetchColumn();
            if ($noteEval2 !== false) {
                $sommeNotesEval2 += $noteEval2 * $coef;
                $sommeCoefEval2 += $coef;
            }

            // Calcul de la moyenne par matière
            $moyenne = 0;
            if ($sommeCoefEval1 > 0) {
                $moyenneEval1 = $sommeNotesEval1 / $sommeCoefEval1;
            } else {
                $moyenneEval1 = 0;
            }

            if ($sommeCoefEval2 > 0) {
                $moyenneEval2 = $sommeNotesEval2 / $sommeCoefEval2;
            } else {
                $moyenneEval2 = 0;
            }

            $moyenneMatiere = ($moyenneEval1 + $moyenneEval2) / 2;
            $moyennesParEleve[$id_eleve_courant] = $moyenneMatiere;
        }

        // Trier les moyennes par matière
        arsort($moyennesParEleve);

        // Calculer le rang de chaque élève dans cette matière
        $rangs = [];
        $rank = 1;
        foreach ($moyennesParEleve as $id_eleve_courant => $moyenne) {
            $rangs[$id_eleve_courant] = $rank;
            $rank++;
        }

        // Stocker les rangs par matière
        $rangsParMatiere[$matiere['nom_matiere']] = $rangs;
    }

    // Affichage des rangs par matière pour un élève spécifique
    if (isset($rangsParMatiere[$matiere['nom_matiere']][$id_eleve])) {
        echo "Rang de l'élève " . $id_eleve . " en " . $matiere['nom_matiere'] . ": " . $rangsParMatiere[$matiere['nom_matiere']][$id_eleve];
    } else {
        echo "L'élève " . $id_eleve . " n'a pas de rang en " . $matiere['nom_matiere'];
    }

} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulletin de Notes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
      /* Style normal pour la page */
        body {
            font-size: 10px;
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1, h2 {
            color: #333;
        }

        
        .page {
                text-align: center;
                font-size: 25px;
                width: 300mm;
                min-height: 297mm;
                margin: 10mm auto;
                padding: 20mm;
                background-color: #fff; /* Blanc */
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 20px;
            }
            .header h2 {
                font-size: 24px;
                font-weight: bold;
            }
            .header p {
                font-size: 14px;
            }
            .table-sm td, .table-sm th {
                padding: 2px 4px; /* Réduit encore plus le padding */
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            th, td {
                text-align: center;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f1f1f1;
            }

        /* Styles spécifiques à l'impression */
       @media print {
    body {
        font-size: 24px;
        margin: 0;
        padding: 0;
        text-align: center;
    }

    #print {
        width: 100%;
        padding: 10mm;
        background-color: #fff;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    /* Assurez-vous que le contenu ne déborde pas de la page A4 */
    .page {
        text-align: center;
        font-size: 25px;
        width: 320mm;
        height: 340mm;
        margin: 10mm auto;
        padding: 20mm;
    }
    th, td {
                text-align: center;
               
            }

    /* Masquer les éléments inutiles à l'impression (par exemple, boutons) */
    button {
        display: none; /* Masque tous les boutons */
    }

    /* Si vous voulez masquer seulement le bouton d'impression */
    #printButton {
        display: none; /* Masque le bouton d'impression spécifique */
    }

    /* Styliser le bouton d'impression si nécessaire */
    @page {
        size: A4;
        margin: 10mm;
    }
}


    </style>
</head>
<body>
            <div class="d-flex justify-content-between mb-3 w-100">
                <!-- Bouton Retour aligné à gauche -->
                <a href="eleve.php?id_evaluation=<?= urlencode($id_evaluation) ?>&id_tri=<?= urlencode($id_tri) ?>&id_class=<?= urldecode($id_class)?>&id_elev=<?= urldecode($id_eleve)?>" class="mb-6"><button class="btn btn-secondary  " id="printButton">
                        <i class="bi bi-arrow-left-circle"></i> Retour
                    </button></a>
                 <button onclick="imprimer()" id="printButton" class="btn btn-primary">
            <i class="bi bi-printer"></i> Imprimer le bulletin
        </button>
                
            </div>
    <div class="page" id="print">
        <!-- Div positionnée à gauche -->
        <div class="container-fluid" style="font-size:9px;">
            <div class="row">
                <!-- Div à gauche -->
                <div class="text-center col-5 text-left p-0" style="border: none; position: relative; top: -30px; left: -40px;">
                    <b>
                        <p class="text-bold fw-bold mb-0 fs-6">REPUBLIQUE DU CAMEROUN</p>
                        <p class="fw-bold mb-0 fs-6"><i>Paix-Travail-Patrie</i></p>
                        <p class="fw-bold mb-0 fs-6">*********</p>
                        <p class="text-bold fw-bold mb-0 fs-6">MINISTERE DES ENSEIGNEMENTS SECONDAIRES</p>
                        <p class="fw-bold mb-0 fs-6"><i>*********</i></p>
                        <p class="fw-bold mb-0 fs-6">DELEGATION REGIONALE DU CENTRE</p>
                        <p class="text-bold fw-bold mb-0 fs-6">*********</p>
                        <p class="fw-bold mb-0 fs-6"><i>DELEGATION DEPARTEMENTALE DE LA LEKIE</i></p>
                        <p class="fw-bold mb-0 fs-6">*********</p>
                        <p class="fw-bold mb-0 fs-6"><i>COLLEGE JEAN XXIII D'EFOK</i></p>
                    </b>
                </div>

                <!-- Div centrée -->
                <div class="col-3 text-center p-3" style="border: none;">
                <p class="fw-bold mb-0 fs-6 rounded-full"><img src="../../../../Assets/logoecole.jpg" style="border-radius: 50%;" class="rounded-full"  alt="LOGO" width="100px" height="100px"></p>
                </div>

                <!-- Div à droite -->
                <div class="text-center col-4 text-end p-0" style="border: none;  position: relative; top: -30px; left: 40px;">
                    <b>
                        <p class="text-bold fw-bold mb-0 fs-6">REPUBLIC OF CAMEROON</p>
                        <p class="fw-bold mb-0 fs-6"><i>Peace-Work-Fatherland</i></p>
                        <p class="fw-bold mb-0 fs-6">*********</p>
                        <p class="text-bold fw-bold mb-0 fs-6">MINISTRY OF SECONDARY EDUCATION</p>
                        <p class="fw-bold mb-0 fs-6"><i>*********</i></p>
                        <p class="fw-bold mb-0 fs-6">REGION DELEGATION OF CENTER</p>
                        <p class="text-bold fw-bold mb-0 fs-6">*********</p>
                        <p class="fw-bold mb-0 fs-6"><i>DIVISIONAL DELEGATION OF THE LEKIE</i></p>
                        <p class="fw-bold mb-0 fs-6">*********</p>
                        <p class="fw-bold mb-0 fs-6"><i>HIGH SCHOOL JEAN XXIII D'EFOK</i></p>
                    </b>
                </div>
            </div>
        </div>
        <div class="container-fluid" style="font-size:9px;">
    <div class="row">
        <!-- Div à gauche -->
        <div class="text-center col-3 text-left p-0" style="border: none; position: relative; top: -30px; left: -40px;">
        </div>

        <!-- Div centrée -->
        <div class="col-6 text-center p-0" style="border: none;">
            <div class="header" style="margin-top: -30px;">
                <h2 class="fw-bold mb-0 fs-6 my-4 text-center">BULLETIN DE NOTES</h2>
                <p class="fw-bold mb-0 fs-6">Année Scolaire : <?=$description_periode?></p>
            </div>
        </div>

        <!-- Div à droite -->
        <div class="text-center col-4 text-end p-0" style="border: none; position: relative; top: -30px; left: 40px;">
        </div>
    </div>
    <br><br><br>

    <div class="d-flex align-items-center" style="margin-top: -35px;">
        <!-- Photo (cadre à gauche du tableau) -->
        <div class="photo border-2" style="width: 130px; height: 130px; margin-left: -30px; margin-right: 20px; border: 2px solid black; display: flex; justify-content: center; align-items: center;">
            <span style="font-size: 14px; text-align: center;">Photo 4X4</span>
        </div>

        <!-- Tableau -->
        <table border="1" class="table table-sm" style="font-size:17px">
            <thead>
                <tr>
                    <th colspan="4">Noms et prénoms : </th>
                    <th colspan="9"><?= $nom_elev;?> <?= $prenom_elev;?></th>
                    <th>Classe : <?=  $nom_class ?></th>
                </tr>
                <tr>
                    <th colspan="4">Date et lieu de naissance :</th>
                    <th colspan="9"><?= $date_naiss ?> à <?= $lieu_naiss ?></th>
                    <th>Effectif : <?=  $nbre_elev ?></th>
                </tr>
                <tr>
                    <th colspan="4">Genre : <?= $sexe_elev; ?></th>
                    <th colspan="5">Identifiant Unique : <?= $code_elev;?><?= $id;?></th>
                    <th colspan="4"><?= $categorie; ?></th>
                    <th rowspan="3">Professeur principal : <?=$nom_enseig;?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th colspan="5">Noms et contacts des parents/tuteurs :</th>
                    <th colspan="9"><?= $nom_tuteur ?> <?= $tel_tuteur ?></th>
                </tr>
            </tbody>
        </table>
    </div>
</div>
        <br><br><br>
        <div class="d-flex align-items-center" style="margin-top: -35px; margin-left: -20px; margin-right: 10px;">
            <table border="1" style='width: 2500px; font-size:17px;'>
                    <tr>
                        <th>MATIÈRES ET NOM DE L’ENSEIGNANT</th>
                        <th>COMPÉTENCES ÉVALUÉES</th>
                        <th>Eva1 N/20</th>
                        <th>Eva2 N/20</th>
                        <th>Coef</th>
                        <th>M/20</th>
                        <th>M X Coef</th>
                        <th>Eva1 * Coef</th>
                        <th>Eva2 * Coef</th>
                        <th>Cote</th>
                        <th>[Min_Max]</th>
                        <th>Rang</th>
                        <th style='margin: 500px; table-layout: fixed;'>Appréciation</th>
                    </tr>

                    <?php
                    $id_eval1 = $id_evaluation - 1;
                    if (isset($id_class) && isset($id_eval1) && isset($id_evaluation) && isset($id_annee) && isset($id_tri) && isset($id_eleve)) {
                
                        $id_evaluation1 = $id_evaluation - 1;
                        $id_evaluation2 = $id_evaluation;
                        $id_annee = $_SESSION['id_annee'];
                        $id_eleve = $_GET['id_elev'];
                        $id_tri = $_GET['id_tri'];

                        // Tableau pour stocker les moyennes pondérées des élèves par matière
                        $moyennesEleves = [];

                        // Variables pour la somme des notes et des coefficients
                        $sommeNotesEva1 = 0;
                        $sommeNotesEva2 = 0;
                        $sommeCoefficients = 0;
                        $totalMoyenneCoef = 0;
                        $sommeCoefficientsEva1 = 0;
                        $sommeCoefficientsEva2 = 0;

                        // Variables pour la somme des produits Eva1*Coef et Eva2*Coef
                        $sommeEva1Coef = 0;
                        $sommeEva2Coef = 0;

                        // Variable pour la somme totale des "Moyenne X Coef"
                        $sommeMoyenneXCoef = 0;

                        // Récupérer les matières de la classe
                        $sql_matiere = "
                            SELECT m.*, g.nom_group, m.Nom_ens
                            FROM matiere m
                            JOIN groupe g ON m.id_group = g.id_group
                            WHERE m.id_class = :id_class AND m.id_annee = :id_annee
                            ORDER BY g.id_group ASC, m.nom_matiere
                        ";
                        $stmt = $connection->prepare($sql_matiere);
                        $stmt->execute([':id_class' => $id_class, ':id_annee' => $id_annee]);
                        $matieres = $stmt->fetchAll();
                        $currentGroup = null;
                        foreach ($matieres as $matiere) {
                            if ($currentGroup !== $matiere['nom_group']) { 
                                if ($currentGroup !== null) { 
                                    // Ajouter une ligne à la fin du groupe 
                                    echo "<tr style='background-color: rgb(177, 177, 177)'><td colspan='13'><br /></td></tr>"; 
                                 } $currentGroup = $matiere['nom_group']; 
                            }
                            echo "<tr style='text-align:center;'>";

                            // Affichage de la matière et de l'enseignant
                            echo "<td>
                                    <span style='font-weight: bold; color: #333;'>{$matiere['nom_matiere']}</span>
                                    <p style='font-size: 17px; color: #555;'>Mr/Mme {$matiere['Nom_ens']}</p>
                                </td>";

                            // Affichage des compétences pour chaque matière
                            $competences_matiere = array_filter($competences, function ($competence) use ($matiere) {
                                return $competence['code_mat'] == $matiere['code_mat'];
                            });
                            echo "<td style='margin-left:0; text-align: left;'>";
                            $competenceCount = count($competences_matiere);
                            $counter = 1;
                            foreach ($competences_matiere as $competence) {
                                echo "<span style='font-size: 17px;'>{$competence['description_cp']}</span>";
                                if ($counter < $competenceCount) {
                                    echo "<hr style='border-top: 1px dashed #bbb; margin: 2px 0;' />";
                                }
                                $counter++;
                            }
                            echo "</td>";

                            // Récupération des notes pour Eva1 et Eva2
                            $note1 = '/';
                            $note2 = '/';

                            foreach ($notes as $note) {
                                if ($note['id_evaluation'] == $id_evaluation1 && $note['code_mat'] == $matiere['code_mat']) {
                                    $note1 = $note['note'];
                                }
                                if ($note['id_evaluation'] == $id_evaluation2 && $note['code_mat'] == $matiere['code_mat']) {
                                    $note2 = $note['note'];
                                }
                            }

                            if ($note1 !== '/' || $note2 !== '/') {
                                // Moyenne de chaque évaluation
                                $moyenne_1 = ($note1 !== '/') ? $note1 : 0;
                                $moyenne_2 = ($note2 !== '/') ? $note2 : 0;

                                // Moyenne de chaque évaluation
                                $moyenne = ($moyenne_1 + $moyenne_2) / 2;
                                $moyenne = ($moyenne_1 + $moyenne_2 > 0) ? round($moyenne, 2) : '/';

                                // Calcul de la moyenne pondérée pour chaque matière
                                $moyenne_coef = ($moyenne !== '/') ? $matiere['coeficient'] * $moyenne : '/';

                                // Calcul des produits Eva1*Coef et Eva2*Coef
                                $eva1_coef = ($note1 !== '/') ? $note1 * $matiere['coeficient'] : '/';
                                    if ($note1 !== '/') {
                                        $sommeCoefficientsEva1 += $matiere['coeficient'];
                                    }

                                $eva2_coef = ($note2 !== '/') ? $note2 * $matiere['coeficient'] : '/';
                                    if ($note2 !== '/') {
                                        $sommeCoefficientsEva2 += $matiere['coeficient'];
                                    }
                                
                                // Cote et appréciation
                                $cote = ($moyenne !== '/') ? cote($moyenne) : '/';
                                $appreciation = ($moyenne !== '/') ? appreciation($moyenne) : 'Aucune note';

                                // Calcul des Min/Max pour la matière
                                $min_max_notes = getMinMaxNotes($matiere['code_mat'], $id_annee, $id_tri, $id_class);
                                echo "<td>" . ($note1 === '/' ? '/' : number_format($note1, 2)) . "</td>";
                                echo "<td>" . ($note2 === '/' ? '/' : number_format($note2, 2)) . "</td>";
                                echo "<td>{$matiere['coeficient']}</td>";
                                echo "<td>" . ($moyenne === '/' ? '/' : number_format($moyenne, 2)) . "</td>";
                                echo "<td>" . ($moyenne_coef === '/' ? '/' : number_format($moyenne_coef, 2)) . "</td>";

                                // Nouvelles colonnes : Eva1 * Coef et Eva2 * Coef
                                echo "<td>" . ($eva1_coef === '/' ? '/' : number_format($eva1_coef, 2)) . "</td>";
                                echo "<td>" . ($eva2_coef === '/' ? '/' : number_format($eva2_coef, 2)) . "</td>";

                                echo "<td>{$cote}</td>";
                                echo "<td>[{$min_max_notes['min']} - {$min_max_notes['max']}]</td>";

                                // Ajout des moyennes pondérées des élèves dans le tableau pour calculer les rangs
                                $moyennesEleves[] = [
                                    'id_eleve' => $id_eleve,
                                    'matiere' => $matiere['code_mat'],
                                    'moyenne_coef' => $moyenne_coef
                                ];

                                // Calcul des sommes des notes et des coefficients
                                if ($note1 !== '/') {
                                    $sommeNotesEva1 += $note1;
                                }
                                if ($note2 !== '/') {
                                    $sommeNotesEva2 += $note2;
                                }

                                if ($moyenne !== '/') {
                                    $totalMoyenneCoef += $moyenne_coef;
                                    $sommeCoefficients += $matiere['coeficient'];
                                    $sommeMoyenneXCoef += $moyenne_coef;  // Ajouter à la somme des "Moyenne X Coef"
                                }

                                // Ajout des produits Eva1 * Coef et Eva2 * Coef à la somme respective
                                if ($eva1_coef !== '/') {
                                    $sommeEva1Coef += $eva1_coef;
                                }
                                if ($eva2_coef !== '/') {
                                    $sommeEva2Coef += $eva2_coef;
                                }

                                // Affichage du rang par matière
                                $rangs = array_column($moyennesEleves, 'moyenne_coef');
                                rsort($rangs); // Trier les moyennes pondérées de manière décroissante

                                $rang = array_search($moyenne_coef, $rangs) + 1;
                                echo "<td>{$rangsParMatiere[$matiere['nom_matiere']][$id_eleve]}</td>"; // Affichage du rang

                                // Appréciation
                                echo "<td style='font-size: 17px;'>{$appreciation}</td>";
                                echo "</tr>";
                            } else {
                                // Matière sans note
                                echo "<td>/</td><td>/</td><td>{$matiere['coeficient']}</td><td>/</td><td>/</td><td>/</td><td>/</td><td>/</td><td>[Min_Max]</td><td>/</td><td>Aucune note</td></tr>";
                            }
                        }
                        if ($currentGroup !== null) { echo "<tr class='tt' style='background-color: rgb(177, 177, 177);'><td colspan='13'><br /></td></tr>"; }

                        // Moyenne générale de l'élève pour les évaluations
                        $moyenne_eva1 = ($sommeCoefficients > 0) ? round($sommeNotesEva1 / $sommeCoefficients, 2) : '/';
                        $moyenne_eva2 = ($sommeCoefficients > 0) ? round($sommeNotesEva2 / $sommeCoefficients, 2) : '/';
                        $Scoef1et2 = $sommeCoefficientsEva1 + $sommeCoefficientsEva2;
                        echo "<tr>";
                        echo "<td colspan='4' style='text-align: right; font-weight: bold;'>TOTAL : </td>";
                        echo "<td>{$Scoef1et2} </td>";
                            $sommeNote =($sommeNotesEva1 + $sommeNotesEva2)*2;
                        echo "<td style='font-weight: bold;'> {$sommeNote}</td>";



                        if ($Scoef1et2 != 0) {
                            $MoyennePonderee=0;
                            $MoyennePonderee= round(($sommeEva2Coef + $sommeEva1Coef)/$Scoef1et2, 2);
                        } else {

                            $MoyennePonderee = 0; // ou toute autre valeur par défaut appropriée
                        }
                        
                        echo "<td colspan='2' style='font-weight: bold; text-align: left;'>Rang : $rrang e</td>";

                        echo "<td colspan='5' style='font-weight: bold; text-align: left;'>MOYENNE : $MoyennePonderee</td>";
                        
                        echo "</tr>";
                    } else {
                        echo "<tr><td colspan='13' style='text-align: center;'>Aucune information disponible pour afficher le bulletin</td></tr>";
                    }
                    if (!isset($sommeEva1Coef)) {
                        $sommeEva1Coef = 0; // Ou une autre valeur par défaut
                    }
                    
                    if (!isset($MoyennePonderee)) {
                        $MoyennePonderee = 0; // Par défaut
                    }
                    
                    if (!isset($Scoef1et2)) {
                        $Scoef1et2 = 0; // Par défaut
                    }
                    if (!isset($sommeEva2Coef)) {
                        $sommeEva2Coef = 0; // Par défaut
                    }
                    
                    ?>
                </table>
        </div><br><br><br><br>
        <div class="d-flex align-items-center" style="margin-top: -45px;">
            <!-- Tableau -->
                <table border="1" class="table table-sm" style='text-align:center; width: 2500px; font-size:17px;'>
                    <thead>
                        <tr>
                            <th colspan="5">Discipline</th>
                            <th colspan="4">Travail de l'élève</th>
                            <th colspan="4">Profil de la classe</th>
                        </tr>
                    </thead>
                    <tbody>

                        <!-- Première ligne du tableau -->

                        <tr>
                            <td colspan="2" style="text-align: center; vertical-align: middle;">Abs. non J. (h)</td>
                            <td style="text-align: center; vertical-align: middle;" style="color:white"></td>
                            <td style="text-align: center; vertical-align: middle;">Avertissement de conduite</td>
                            <td style="text-align: center; vertical-align: middle;" style="color:white"></td>
                            <td style="text-align: center; vertical-align: middle;">TOTAL GENERAL</td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo (($sommeEva1Coef + $sommeEva2Coef)/2); ?></td>
                            <td colspan="2" style="text-align: center; vertical-align: middle;">Appréciations</td>
                            <td colspan="2" style="text-align: center; vertical-align: middle;">Moyenne Générale</td>
                            <td colspan="2" style="text-align: center; vertical-align: middle;"><?= number_format($moyenneGenerale, 2) ?></td>
                        </tr>

                        <!-- Deuxième ligne du tableau -->
                        <tr>
                            <td rowspan="2" colspan="2" style="text-align: center; vertical-align: middle;">Abs. just. (h)</td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;"></td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;">Blâme conduite</td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;"></td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;">COEF</td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;"><?php echo ($Scoef1et2)/2; ?></td>
                            <td style="text-align: center; vertical-align: middle;">CTBA</td>
                            <td style="text-align: center; vertical-align: middle;">
                                <?= ($MoyennePonderee >= 18) ? "✅" : ""; ?>
                            </td>
                            <td colspan="3" rowspan="2" style="text-align: center; vertical-align: middle;">[Mix - Max]</td>
                            <td rowspan="2" style="text-align: center; vertical-align: middle;">[<?= number_format($premiereMoyenne, 2) ?> - <?= number_format($derniereMoyenne, 2) ?>]</td>
                        </tr>
                        
                        <tr>
                            <td>CBA</td>
                            <td>
                                <?= ($MoyennePonderee >= 16 && $MoyennePonderee < 18) ? "✅" : ""; ?>
                            </td>
                        </tr>

                        <!-- Troisième ligne du tableau -->
                        <tr>
                            <td rowspan="2" colspan="2">Retards (nombre de fois)</td>
                            <td rowspan="2" style="color:white">-//--//-</td>
                            <td rowspan="2">Exclusions (jours)</td>
                            <td rowspan="2" style="color:white">-//--//-</td>
                            <td rowspan="2">MOYENNE TRIM</td>
                            <td rowspan="2"><?= $MoyennePonderee; ?></td>
                            <td>CA</td>
                            <td>
                                <?= ($MoyennePonderee >= 14 && $MoyennePonderee < 16) ? "✅" : ""; ?>
                            </td>
                            <td colspan="3" rowspan="2">Nombre de moyennes</td>
                            <td rowspan="2"><?= $nombreReussites ?></td>
                        </tr>
                        <tr>
                            <td>CMA</td>
                            <td>
                                <?= ($MoyennePonderee >= 10 && $MoyennePonderee < 14) ? "✅" : ""; ?>
                            </td>
                        </tr>

                        <!-- Quatrième ligne du tableau -->
                        <tr>
                            <td colspan="2">Consignes (heures)</td>
                            <td style="color:white">-//--//-</td>
                            <td>Exclusion définitive </td>
                            <td style="color:white">-//--//-</td>
                            <td>COTE</td>
                            <td><?php echo cote($MoyennePonderee); ?></td>
                            <td>CNA</td>
                            <td>
                                <?= ($MoyennePonderee < 10 && $MoyennePonderee < 14) ? "✅" : ""; ?>
                            </td>
                            <td colspan="2">Taux de réussite</td>
                            <td colspan="2"><?= number_format($tauxReussite, 2) ?>%</td>
                        </tr>

                        <!-- Appréciation du travail de l’élève -->
                        <tr>
                            <td colspan="5">Appréciation du travail de l’élève (points forts et points à améliorer)<br><br><br><br><br><br></td>
                            <td colspan="2">Visa du parent / Tuteur</td>
                            <td colspan="2">Nom et visa du professeur principal</td>
                            <td colspan="4">Le Chef d’établissement</td>
                        </tr>

                    </tbody>
                </table>
            </div>
        

                    <?php
                    // Fonction pour calculer la cote
                    function cote($note) {
                        if ($note >= 18) return "A+";
                        if ($note >= 16) return "A";
                        if ($note >= 15) return "B+";
                        if ($note >= 14) return "B";
                        if ($note >= 12) return "C+";
                        if ($note >= 10) return "C";
                        return "D";
                    }

                    // Fonction pour déterminer l'appréciation
                    function appreciation($note) {
                        if ($note >= 18) return "Compétences très bien acquises (CTBA)";
                        if ($note >= 14) return "Compétences bien acquises (CBA)";
                        if ($note >= 12) return "Compétences acquises (CA)";
                        if ($note >= 10) return "Compétences moyennement acquises (CMA)";
                        return "Compétences non acquises (CNA)";
                    }

                    // Fonction pour récupérer les Min/Max des notes d'une matière dans la classe pour le trimestre et l'année
                    function getMinMaxNotes($code_mat, $id_annee, $id_tri, $id_class) {
                        global $connection;
                        $sql_min_max = "
                            SELECT MIN(n.note) AS min, MAX(n.note) AS max
                            FROM note n
                            JOIN matiere m ON n.code_mat = m.code_mat
                            WHERE n.id_class = :id_class
                            AND n.id_annee = :id_annee
                            AND n.id_tri = :id_tri
                            AND n.code_mat = :code_mat
                        ";
                        $stmt = $connection->prepare($sql_min_max);
                        $stmt->execute([
                            ':id_class' => $id_class,
                            ':id_annee' => $id_annee,
                            ':id_tri' => $id_tri,
                            ':code_mat' => $code_mat
                        ]);
                        return $stmt->fetch(PDO::FETCH_ASSOC);
                    }
                    ?>
    </div>
            
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
    function imprimer() {
        // Masquer les boutons et autres éléments inutiles pour l'impression
        document.getElementById('printButton').style.display = 'none'; // Masquer le bouton "Imprimer"
        document.querySelector('a').style.display = 'none'; // Masquer le bouton "Retour"
        
        // Utilisation d'une fenêtre d'impression
        var printWindow = window.open('', '', 'width=800,height=600');

        // Ajouter le contenu HTML à imprimer dans la nouvelle fenêtre
        printWindow.document.write('<html><head><title>Impression du Bulletin</title>');
        printWindow.document.write('<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">');
        
        // Ajouter le style spécifique, y compris pour la marge négative
        printWindow.document.write('<style>');
        printWindow.document.write('body { font-size: 15px; margin: 0; padding: 10mm;}');
        printWindow.document.write('.header { margin-top: -30px; }');  // Appliquer la marge négative ici
        printWindow.document.write('@media print { body { font-size: 15pt; } }');
        printWindow.document.write('</style>');
        printWindow.document.write('</head><body>');
        
        // Inclure seulement l'élément à imprimer (l'élément avec id="print")
        printWindow.document.write(document.getElementById('print').innerHTML);

        // Clore le document de la fenêtre d'impression et lancer l'impression
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        
        // Attendre que le contenu soit chargé pour imprimer
        printWindow.onload = function() {
            printWindow.print(); // Lancer l'impression
            // Réafficher les éléments cachés après l'impression
            document.getElementById('printButton').style.display = 'inline-block';
            document.querySelector('a').style.display = 'inline-block';
            printWindow.close(); // Fermer la fenêtre d'impression après l'impression
        };
    }
</script>

</body>
</html>

<!--
/*  echo "<tr>";
    echo "<td colspan='5' style='text-align: right; font-weight: bold;'>Coef 1 ET 2</td>";
    echo "<td>Coef 1= {$sommeCoefficientsEva1} coef 2= {$sommeCoefficientsEva2}</td>";
    echo "<td colspan='3'></td>";
    echo "</tr>";

    // Somme des Moyennes X Coef
    echo "<tr>";
    echo "<td colspan='5' style='text-align: right; font-weight: bold;'>Somme des Moyennes X Coef</td>";
    echo "<td>{$sommeMoyenneXCoef}</td>";
    echo "<td colspan='3'></td>";
    echo "</tr>";

    // Somme des produits Eva1 * Coef et Eva2 * Coef
    echo "<tr>";
    echo "<td colspan='5' style='text-align: right; font-weight: bold;'>Somme des Eva1 * Coef</td>";
    echo "<td>{$sommeEva1Coef}</td>";
    echo "<td colspan='3'></td>";
    echo "</tr>";

    echo "<tr>";
    echo "<td colspan='5' style='text-align: right; font-weight: bold;'>Somme des Eva2 * Coef</td>";
    echo "<td>{$sommeEva2Coef}</td>";
    echo "<td colspan='3'></td>";
    echo "</tr>";

    // ** Nouvelle ligne ajoutée pour la somme des coefficients **
    echo "<tr>";
    echo "<td colspan='5' style='text-align: right; font-weight: bold;'>Somme des Coefficients</td>";
    echo "<td>{$sommeCoefficients}</td>";
    echo "<td colspan='3'></td>";
    echo "</tr>";
*/ -->
<?php
// Activer les erreurs pour déboguer
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once('../../../../Traitement/connexion.php');

header('Content-Type: application/json');

try {
    // Décoder les données JSON envoyées
    $data = json_decode(file_get_contents('php://input'), true);

    // Vérifier si les données nécessaires sont présentes
    if (isset($data['id']) && is_numeric($data['id'])) {
        $id_annee = $data['id'];

        // Désactiver toutes les années
        $query = "UPDATE annee_scolaire SET etat_P = 0";
        $stmt = $conn->prepare($query);
        $stmt->execute();

        // Activer l'année sélectionnée
        $query = "UPDATE annee_scolaire SET etat_P = 1 WHERE id_annee = :id_annee";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_annee', $id_annee, PDO::PARAM_INT);
        $stmt->execute();

        // Renvoyer une réponse JSON réussie
        echo json_encode(['success' => true]);
    } else {
        // Renvoyer une erreur si les données sont invalides
        echo json_encode(['success' => false, 'message' => 'Données invalides']);
    }
} catch (Exception $e) {
    // Gestion des erreurs
    echo json_encode(['success' => false, 'message' => 'Erreur du serveur : ' . $e->getMessage()]);
}

<?php
// Démarrer la session pour manipuler les variables de session
session_start();

// Inclure les fichiers nécessaires
include_once "Models/Database.php";
include_once "Models/competence.php";
$id_evaluation = $_GET['id_evaluation'];
// Créer une nouvelle instance de la classe Competence
$competence = new Competence();
$message = ""; // Variable pour stocker les messages de succès ou d'erreur

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Récupérer et valider les données du formulaire
    $code_mat = $_POST['code_mat'] ?? '';
    $id_tri = filter_var($_POST['id_tri'], FILTER_VALIDATE_INT);
    $description_cp = $_POST['description_cp'] ?? '';
    $etat_cp = filter_var($_POST['etat_cp'], FILTER_VALIDATE_INT);
    $id_annee = filter_var($_POST['id_annee'], FILTER_VALIDATE_INT);
    $id_class = filter_var($_POST['id_class'], FILTER_VALIDATE_INT);

    // Vérifier si les données sont valides
    if (!$id_tri || !$etat_cp || !$id_annee || !$id_class) {
        $_SESSION['message'] = ["type" => "danger", "text" => "Les données soumises sont invalides. Veuillez vérifier les informations."];
        header('Location: Model/competences.php');
        exit();
    }

    // Enregistrer la compétence dans la base de données
    if ($competence->create($code_mat, $id_tri, $description_cp, $etat_cp, $id_class, $id_annee)) {
        // Message de succès
        $_SESSION['message'] = ["type" => "success", "text" => "Compétence enregistrée avec succès!"];
    } else {
        // Message d'erreur
        $_SESSION['message'] = ["type" => "danger", "text" => "Erreur lors de l'enregistrement de la compétence."];
    }

    // Redirection vers la page appropriée après l'enregistrement
    header('Location: creercomp.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri));  // Vous pouvez changer cette page selon vos besoins
    exit(); // Arrêter l'exécution après la redirection
}
?>



<?php
      session_start();
      $id_class = $_GET['id_class'];
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  $id_eleve = $_GET['id_elev'];
   
  $id_evaluation = $_GET['id_evaluation'];
  $id_annee = $_SESSION['id_annee'];
   $id_tri = $_GET['id_tri'];

  //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  require_once 'Models/Database.php';
  require_once 'Models/evaluation.php';
  $db = new Database();
  $connection = $db->getConnection();
  if (isset($_GET['action']) && $_GET['action'] == 'delete') {
    // Vérifier si 'noteID' existe dans l'URL et correspond à une valeur valide
    if (isset($_GET['noteID']) && is_numeric($_GET['noteID'])) {
        $noteID = $_GET['noteID'];

        // Supprimer la note en utilisant une requête préparée
        $req3 = $connection->prepare("DELETE FROM note WHERE id_note = ?");
        $req3->execute([$noteID]);

        // Rediriger après la suppression
        header('Location: noter.php?id_class=' . urlencode($id_class) . '&id_evaluation=' . urlencode($id_evaluation) . '&id_tri=' . urlencode($id_tri) . '&id_elev=' .urlencode($id_eleve));
        exit;
    } else {
        echo "ID de note invalide ou non spécifié.";
    }
}

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Modifier un Devoir</title>
    <style>
        body {
            background-image: url("../../../../Assets/back1.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>

<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-2xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Modifier Votre Devoir
                </div>
                <?php  $id = $_GET['id']; 
                
                require_once "../../../Traitement/connexion.php";

                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if (isset($_POST['titre'])  && isset($_POST['classe'])  && isset($_POST['matiere'])) {
                        $titre = $_POST['titre'];
                        $contenu = $_POST['contenu'];
                        $classe = $_POST['classe'];
                        $matiere = $_POST['matiere'];
                        $date = date("Y/m/d");
                        $piecejointeNom = '';
                        $piecejointeNewName = '';
                        $uploadDir = '../../../Traitement/enseignant/devoir/upload/'; // Répertoire de destination
                
                        if (isset($_FILES['piecejointe']) && $_FILES['piecejointe']['error'] === UPLOAD_ERR_OK) {
                            $piecejointe = $_FILES['piecejointe'];
                            $piecejointeNom = $piecejointe['name'];
                            $piecejointeTmpName = $piecejointe['tmp_name'];
                            $piecejointeSize = $piecejointe['size'];
                            $piecejointeError = $piecejointe['error'];
                            $piecejointeType = $piecejointe['type'];
                
                            // Vérifier que le répertoire de téléchargement existe sinon le créer
                            if (!is_dir($uploadDir)) {
                                mkdir($uploadDir, 0755, true);
                            }
                
                            // Valider et déplacer la pièce jointe
                            if ($piecejointeError === 0) {
                                // Extraire l'extension du fichier
                                $piecejointeExt = strtolower(pathinfo($piecejointeNom, PATHINFO_EXTENSION));
                                $allowedExts = ['pdf', 'doc', 'docx', 'jpg', 'png'];
                
                                if (in_array($piecejointeExt, $allowedExts)) {
                                    // Générer un nouveau nom unique pour le fichier
                                    $piecejointeNewName = uniqid('', true) . '.' . $piecejointeExt;
                                    $piecejointeDest = $uploadDir . $piecejointeNewName;
                
                                    // Déplacer le fichier téléchargé vers le répertoire cible
                                    if (!move_uploaded_file($piecejointeTmpName, $piecejointeDest)) {
                                        echo "<p class='text-red-500'>Erreur lors du déplacement de la pièce jointe.</p>";
                                        $piecejointeNewName = ''; // Assurez-vous que $piecejointeNewName est vide en cas d'échec
                                    }
                                } else {
                                    echo "<p class='text-red-500'>Type de fichier non autorisé. Les extensions autorisées sont : pdf, doc, docx, jpg, png.</p>";
                                }
                            } else {
                                echo "<p class='text-red-500'>Erreur lors du téléchargement de la pièce jointe. Code d'erreur : $piecejointeError.</p>";
                            }
                        }



                $request = $conn->prepare("UPDATE devoir SET titre = :titre, contenu = :contenu,
                nom_mat = :matiere, nom_class = :classe, piece_jointe = :piecejointe, date = :date WHERE code_dev = $id");
        
                $request->bindParam(':titre', $titre);
                $request->bindParam(':contenu', $contenu);
                $request->bindParam(':matiere', $matiere);
                $request->bindParam(':classe', $classe);
                $request->bindParam(':piecejointe', $piecejointeNewName);
                $request->bindParam(':date', $date);
               

                try {
                    $request->execute();
                    header("Location: devoir.php");
                    exit();
                } catch (PDOException $e) {
                    echo "Erreur : " . $e->getMessage();
                }

                }


            }

                $slmt=$conn->prepare("SELECT * FROM devoir WHERE code_dev = $id");
                $slmt->execute();
                $devoir = $slmt->fetchAll(PDO::FETCH_ASSOC);

                
                ?>
                <div class="card-content">
                    <form method="post" enctype="multipart/form-data" class="space-y-4">
                        <?php foreach($devoir as $dev):?>
                        <div>
                            <label for="titre" class="block text-sm font-medium text-gray-700">Titre</label>
                            <input type="text" id="titre" name="titre" required value=<?= htmlspecialchars($dev['titre']) ?>
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="matiere" class="block text-sm font-medium text-gray-700">Matiere</label>
                            <input type="text" id="matiere" name="matiere" required value=<?= htmlspecialchars($dev['nom_mat']) ?>
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu</label>
                            <textarea id="contenu" name="contenu" rows="4" value=<?= htmlspecialchars($dev['contenu']) ?>
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900"></textarea>
                        </div>
                        <div>
                            <label for="piecejointe" class="block text-sm font-medium text-gray-700">Pièce Jointe</label>
                            <input type="file" id="piecejointe" name="piecejointe" accept=".pdf,.doc,.docx,.jpg,.png" value=<?= htmlspecialchars($dev['piece_jointe']) ?>
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900" >
                        </div>
                        <div>
                        <label for="classe" class="block text-sm font-medium text-gray-700">Classe</label>
                            <select name="classe"  class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900" id="classe" title="Sélectionnez la classe où  seras envoyer le devoir" required>
                                <option value="" selected disabled>Selectionner la classe</option>
                                <?php
                                
                                require '../../../Traitement/connexion.php';
                               
                                $query = "SELECT id_class, nom_class FROM classe";
                                $stmt = $conn->prepare($query);
                                $stmt->execute();
                                $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                foreach ($classes as $classe) {
                                    $selectedClass = ($classe['nom_class'] == $dev['nom_class']) ? 'selected' : '';
                                    echo "<option value=\"{$classe['nom_class']}\" $selectedClass>{$classe['nom_class']}</option>";
                                }
                                ?>
                                ?>
                            </select>
                            <?php endforeach;?>
                        </div>
                        
                        <div>
                            <button type="submit"
                                class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center">
                                Modifier le Devoir
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <a href="../devoir.php" class="text-blue-500 hover:text-blue-700">Retour</a>
                </div>
            </div>
        </div>
    </section>

</body>

</html>

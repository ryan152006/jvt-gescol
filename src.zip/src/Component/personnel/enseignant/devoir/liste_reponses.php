<?php
// Connexion à la base de données
require_once '../../../../Traitement/connexion.php'; // Assurez-vous que ce chemin est correct
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];
// Récupérer le matricule de l'enseignant depuis la session
$matricule = $secr['matricule'];

// Requête SQL pour récupérer les réponses des élèves
$sql = "SELECT 
            eleve.nom_elev, 
            eleve.prenom_elev, 
            classe.nom_class, 
            devoir.titre, 
            devoir.nom_mat, 
            reponse_devoir.reponse_contenu, 
            reponse_devoir.reponse_piecejointe, 
            devoir.date
        FROM reponse_devoir
        INNER JOIN eleve ON reponse_devoir.id_elev = eleve.id
        INNER JOIN classe ON eleve.id_class = classe.id_class
        INNER JOIN devoir ON reponse_devoir.id_devoir = devoir.code_dev
        WHERE devoir.id_ens = :matricule
        ORDER BY devoir.date DESC";

$stmt = $conn->prepare($sql);
$stmt->bindParam(":matricule", $matricule);
$stmt->execute();
$reponses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Réponses des élèves</title>
    <style>
        /* Pour un style de pièce jointe élégant */
        .attachment-link:hover {
            background-color: #2563eb;
            color: white;
        }
    </style>
</head>
<body class="bg-gradient-to-r from-blue-50 to-indigo-50 min-h-screen p-6">
<div class="card-footer ">
                    <a href="../devoir.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des devoirs</a>
                </div>
    <h1 class="text-3xl font-semibold text-center text-indigo-800 mb-8">Réponses des élèves</h1>

    <?php if (count($reponses) > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach ($reponses as $reponse): ?>
                <div class="bg-white shadow-lg rounded-lg overflow-hidden">
                    <div class="p-6">
                        <h2 class="text-xl font-semibold text-indigo-600 mb-2"><?php echo htmlspecialchars($reponse['titre']); ?> - <?php echo htmlspecialchars($reponse['nom_mat']); ?></h2>
                        <p class="text-gray-700 mb-1">
                            <strong>Nom :</strong> <?php echo htmlspecialchars($reponse['nom_elev']); ?> <?php echo htmlspecialchars($reponse['prenom_elev']); ?>
                        </p>
                        <p class="text-gray-700 mb-1">
                            <strong>Classe :</strong> <?php echo htmlspecialchars($reponse['nom_class']); ?>
                        </p>
                        <p class="text-gray-700 mb-2">
                            <strong>Date d'envoi :</strong> <?php echo htmlspecialchars($reponse['date']); ?>
                        </p>
                        <p class="text-gray-700 mb-4 line-clamp-3">
                            <strong>Contenu de la réponse :</strong> <?php echo nl2br(htmlspecialchars($reponse['reponse_contenu'])); ?>
                        </p>
                        <?php if (!empty($reponse['reponse_piecejointe'])): ?>
                            <p class="mb-4">
                                <a href="../../../../Traitement/enseignant/reponse/upload/<?php echo htmlspecialchars($reponse['reponse_piecejointe']); ?>" target="_blank" class="inline-block text-white bg-indigo-600 hover:bg-indigo-500 px-4 py-2 rounded transition attachment-link">
                                    Télécharger la pièce jointe
                                </a>
                            </p>
                        <?php else: ?>
                            <p class="text-gray-500 mb-4">Pas de pièce jointe.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-center text-gray-500">Aucune réponse trouvée pour le moment.</p>
    <?php endif; ?>
  

</body>
</html>

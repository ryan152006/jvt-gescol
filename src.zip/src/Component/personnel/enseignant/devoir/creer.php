<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Donner un Devoir</title>
    <style>
        body {
            ;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>

<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-2xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Donner un Devoir
                </div>
                <?php  $id_em = $_GET['id_emp']; ?>
                <div class="card-content">
                    <form action="../donner.php?id_emp=<?php echo $id_em; ?>" method="post" enctype="multipart/form-data" class="space-y-4">
                        <div>
                            <label for="titre" class="block text-sm font-medium text-gray-700">Titre</label>
                            <input type="text" id="titre" name="titre" required
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="matiere" class="block text-sm font-medium text-gray-700">Matiere</label>
                            <input type="text" id="matiere" name="matiere" required
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="date" class="block text-sm font-medium text-gray-700">Date de retour du devoir</label>
                            <input type="date" id="date" name="date" 
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu</label>
                            <textarea id="contenu" name="contenu" rows="4" 
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900"></textarea>
                        </div>
                        <div>
                            <label for="piecejointe" class="block text-sm font-medium text-gray-700">Pièce Jointe</label>
                            <input type="file" id="piecejointe" name="piecejointe" accept=".pdf,.doc,.docx,.jpg,.png"
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900" >
                        </div>
                        <div>
                        <label for="classe" class="block text-sm font-medium text-gray-700">Classe</label>
                            <select name="classe" class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900" id="classe" title="Sélectionnez la classe où  seras envoyer le devoir" required>
                                <option value="" selected disabled>Selectionner la classe</option>
                                <?php
                                
                                require '../../../../Traitement/connexion.php';
                               
                                $query = "SELECT id_class, nom_class FROM classe";
                                $stmt = $conn->prepare($query);
                                $stmt->execute();
                                $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                // Générer les options du menu déroulant
                                foreach ($classes as $classe) {
                                    echo "<option value=\"{$classe['nom_class']}\">{$classe['nom_class']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        
                        <div>
                            <button type="submit"
                                class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center">
                                Envoyer le Devoir
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <a href="../devoir.php" class="text-blue-500 hover:text-blue-700">Retour</a>
                </div>
            </div>
        </div>
    </section>

</body>

</html>

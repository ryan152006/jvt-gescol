<?php
// Inclusion du fichier de connexion
require '../../../traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_id = $_GET['id_class'] ?? 1;
    $jours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi"];

    foreach ($_POST['heure_debut'] as $index => $heure_debut) {
        $heure_fin = $_POST['heure_fin'][$index];
        foreach ($jours as $jour) {
            $programme = $_POST['programme'][$jour][$index] ?? '';
            $enseignant_id = $_POST['enseignant'][$jour][$index] ?? null;
            if (!empty($programme) && !empty($enseignant_id)) {
                $nbre_heure = strtotime($heure_fin) - strtotime($heure_debut);
                $nbre_heure = round($nbre_heure / 3600, 2); // Convertir en heures

                $stmt = $conn->prepare("INSERT INTO emploi_Temps (id_class, id_employe, nbre_heure, heure_debut, heure_fin, jour, programme) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$class_id, $enseignant_id, $nbre_heure, $heure_debut, $heure_fin, ucfirst($jour), $programme]);
            }
        }
    }
    header("Location: ../emploi_temps.php?id_class=$class_id");
    exit();
}
?>

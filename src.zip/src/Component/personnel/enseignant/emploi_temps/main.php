<?php
// Inclusion du fichier de connexion
require '../../../Traitement/connexion.php';

// Récupération des enseignants
$enseignants = $conn->query("SELECT * FROM employe WHERE poste = 'enseignant'")->fetchAll(PDO::FETCH_ASSOC);

// Récupération du nom de la classe et du prof titulaire


// Récupération de l'emploi du temps existant pour cette classe
$emploi_temps = $conn->prepare("SELECT * FROM emploi_Temps WHERE id_employe = :id_emp");
$emploi_temps->bindParam(':id_emp', $secr['matricule']);
$emploi_temps->execute();
$emploi_temps_data = $emploi_temps->fetchAll(PDO::FETCH_ASSOC);

$jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];

 // Par défaut, classe 1

// Organisation des données par heure et par jour
$emploi_temps_par_jour = [];
foreach ($emploi_temps_data as $data) {
    $jour = strtolower($data['jour']);
    $heure_debut = $data['heure_debut'];
    $heure_fin = $data['heure_fin'];

    if (!isset($emploi_temps_par_jour[$heure_debut])) {
        $emploi_temps_par_jour[$heure_debut] = [
            'heure_fin' => $heure_fin,
            'jours' => []
        ];
    }
    
    $emploi_temps_par_jour[$heure_debut]['jours'][$jour] = $data;
}
?>

    <div class="container mx-auto">
        <h1 class="text-2xl font-bold text-blue-500 text-center mb-6">Emploi du temps du Professeur <?= htmlspecialchars($secr['nom']) ?> <?= htmlspecialchars($secr['prenom']) ?></h1>
        <div class="overflow-x-auto">
            <form method="POST" action="">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead class="bg-gray-200 text-gray-700">
                        <tr>
                            <th class="py-2 px-4 border-b border-gray-300 text-left">Heure / Jour</th>
                            <?php foreach ($jours as $jour): ?>
                                <th class="py-2 px-4 border-b border-gray-300 text-center"><?= $jour ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php foreach ($emploi_temps_par_jour as $heure_debut => $data): ?>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-300 text-left">
                                    <span  class="w-full px-2 py-1 mb-2"><?php echo $heure_debut ?> </span>
                                    <span  class="w-full px-2 py-1 mb-2"><?php echo $data['heure_fin'] ?> </span>
    
                                </td>
                                <?php foreach ($jours as $jour): ?>
                                    <td class="py-2 px-4 border-b border-gray-300 text-center">
                                        <?php if (isset($data['jours'][strtolower($jour)])): ?>
                                            <?php $emploi = $data['jours'][strtolower($jour)]; 
                                            $class = $conn->prepare("SELECT * FROM classe WHERE id_class = :id_class");
                                            $class->bindParam(':id_class', $emploi['id_class']);
                                            $class->execute();
                                            $class_info = $class->fetch(PDO::FETCH_ASSOC);
                                            
                                            
                                            ?>
                                             <span class="w-full px-2 py-1 mb-2"><?php echo $emploi['programme']; ?> </span>
                                           <br>
                                            <span class="w-full px-2 py-1 mb-2"><?php echo $class_info['nom_class']; ?> </span>
                                            <?php else: ?>
                                                <span class="w-full px-2 py-1 mb-2">R.A.S </span>
                                           <br>
                                           
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                        <!-- Ligne vide pour saisie -->
                     
                    </tbody>
                </table>
               
            </form>
        </div>
    </div>

    <script>
        document.getElementById('add-row').addEventListener('click', function () {
            const table = document.querySelector('tbody');
            const newRow = table.rows[table.rows.length - 1].cloneNode(true);
            newRow.querySelectorAll('input').forEach(input => input.value = '');
            newRow.querySelectorAll('select').forEach(select => select.selectedIndex = 0);
            table.appendChild(newRow);
        });
    </script>

<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    header('Location: ../connexion_autre_poste.php');
    exit();
}

$secr = $_SESSION['employe'];

require "../../../../Traitement/connexion.php";

// Récupérer la classe depuis les paramètres GET
$classe = $_GET['nom_class'];

// Requête pour récupérer les notes de la classe
$query = $conn->prepare("SELECT * FROM carnet_note c JOIN eleve e ON c.id_elev = e.id WHERE nom_class = :classe ORDER BY motif, nom_eleve");
$query->bindParam(':classe', $classe, PDO::PARAM_STR);
$query->execute();
$remplissages = $query->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fiche de Notes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="container mx-auto bg-white p-6 rounded shadow-lg">
        <div class="flex justify-between space-x-8">
            <h1 class="text-2xl text-blue-800 font-medium mb-4">Fiche de Notes</h1>
            <div class="flex justify-center py-4 space-x-12">
                <a href="../carnet_note.php" class="text-black mx-4 bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600">
                    Retour
                </a>
            </div>
        </div>
        <div class="flex justify-between space-x-8">
            <div class="mb-2">
                <p class="text-lg font-normal">Classe : <?php echo htmlspecialchars($classe); ?></p>
            </div>
        </div>

        <?php
        // Regrouper les enregistrements par motif
        $motifs = [];
        foreach ($remplissages as $remplissage) {
            $motifs[$remplissage['motif']][] = $remplissage;
        }

        // Parcourir chaque groupe de motifs et afficher les carnets de notes correspondants
        foreach ($motifs as $motif => $notes) {
            if (!empty($notes)) {
                $date = htmlspecialchars($notes[0]['date']);
                $annee_scolaire = htmlspecialchars($notes[0]['annee_scolaire']);
        ?>

        <div class="mb-6">
            <div class="flex justify-between">
                <div>
                    <h2 class="text-xl font-semibold">Motif : <?php echo htmlspecialchars($motif); ?></h2>
                    <p class="text-lg font-normal">Date : <?php echo $date; ?></p>
                    <p class="text-lg font-normal">Année Scolaire : <?php echo $annee_scolaire; ?></p>
                </div>
                <div class="flex justify-between space-x-4">
              
                    <a href="supprimer_note.php?id=<?php echo htmlspecialchars($notes[0]['code_carn']); ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ces notes ?');" class="text-red-500 hover:underline">Supprimer</a>
                </div>
            </div>

            <form action="modifier_note.php" method="post">
                <input type="hidden" name="classe" value="<?php echo htmlspecialchars($classe); ?>">
                <input type="hidden" name="motif" value="<?php echo htmlspecialchars($motif); ?>">

                <table class="min-w-full bg-white border border-gray-200">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 text-center border-b font-medium">Nom de l'élève</th>
                            <th class="py-2 px-4 text-center border-b font-medium">Note</th>
                            <th class="py-2 px-4 text-center border-b font-medium">Coef</th>
                            <th class="py-2 px-4 text-center border-b font-medium">Appréciation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($notes as $note) {
                            $nom_complet = htmlspecialchars($note['nom_eleve']);
                            $note_val = htmlspecialchars($note['note']);
                            $coef = htmlspecialchars($note['coef']);
                            $appreciation = htmlspecialchars($note['appreciation']);
                            $id = htmlspecialchars($note['code_carn']);
                            $id_elev = htmlspecialchars($note['id_elev']);
                        ?>

                        <tr>
                            <td class="py-2 text-center px-4 border-b"><?php echo $nom_complet; ?></td>
                            <td class="py-2 text-center px-4 border-b">
                                <input type="number" id="note_<?php echo $id_elev; ?>" name="note[<?php echo $id_elev; ?>]" value="<?php echo $note_val; ?>" class="form-input text-center p-1 block w-full border" min="0" max="20" oninput="updateAppreciation(<?php echo $id_elev; ?>)" required>
                            </td>
                            <td class="py-2 text-center px-4 border-b">
                                <input type="number" name="coef[<?php echo $id_elev; ?>]" value="<?php echo $coef; ?>" class="form-input text-center p-1 block w-full border" min="1" max="6" required>
                            </td>
                            <td class="py-2 text-center px-4 border-b">
                                <input type="text" id="appreciation_<?php echo $id_elev; ?>" name="appreciation[<?php echo $id_elev; ?>]" value="<?php echo $appreciation; ?>" class="form-input text-center p-1 block w-full border" readonly>
                            </td>
                        </tr>

                        <?php } ?>
                    </tbody>
                </table>

                <div class="flex justify-end mt-4">
                    <button type="submit" id="submit-button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded hidden">Enregistrer les modifications</button>
                </div>
            </form>
        </div>

        <?php
            } // Fin de la vérification pour les notes non vides
        } // Fin du foreach des motifs
        ?>

    </div>

    <script>document.addEventListener('DOMContentLoaded', function() {
    const submitButton = document.getElementById('submit-button');
    
    // Parcourir tous les champs de note et coef
    document.querySelectorAll('input[type="number"]').forEach(function(input) {
        input.addEventListener('input', function() {
            // Afficher le bouton quand une modification est faite
            submitButton.classList.remove('hidden');
        });
    });
});

function updateAppreciation(id) {
    const noteElement = document.getElementById('note_' + id);
    const appreciationElement = document.getElementById('appreciation_' + id);
    const note = parseFloat(noteElement.value);

    if (isNaN(note)) {
        appreciationElement.value = '';
        return;
    }

    if (note < 10) {
        appreciationElement.value = "Non Acquis";
    } else if (note >= 10 && note <= 14) {
        appreciationElement.value = "En cours D'acquisition";
    } else if (note > 14 && note <= 20) {
        appreciationElement.value = "Acquis";
    } else {
        appreciationElement.value = '';
    }
}

    </script>
</body>
</html>

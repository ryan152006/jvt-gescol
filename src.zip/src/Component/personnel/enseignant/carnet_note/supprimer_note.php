<?php
session_start();

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['employe'])) {
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Récupérer l'identifiant du carnet de note depuis l'URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Se connecter à la base de données
    require "../../../../Traitement/connexion.php";

    // Préparer la requête SQL pour supprimer le carnet de note
    $query = $conn->prepare("DELETE FROM carnet_note WHERE code_carn = :id");
    $query->bindParam(':id', $id, PDO::PARAM_INT);

    // Exécuter la suppression
    if ($query->execute()) {
        // Redirection après succès
        header('Location: ../carnet_note.php');
        exit();
    } else {
        // Afficher une erreur en cas d'échec
        echo "Erreur lors de la suppression du carnet de note.";
    }
} else {
    echo "Aucun identifiant de carnet de note fourni.";
}
?>

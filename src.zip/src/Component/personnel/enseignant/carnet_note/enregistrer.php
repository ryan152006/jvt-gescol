<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];

require "../../../../Traitement/connexion.php";

// Récupérer les élèves de la classe
$classe_id = $_GET['id_class']; // Remplace par l'ID de la classe ou autre critère
$query = $conn->prepare("SELECT * FROM eleve e LEFT JOIN carnet_note c ON e.id = c.id_elev WHERE id_class = :classe_id");
$query->bindParam(':classe_id', $classe_id, PDO::PARAM_INT);
$query->execute();
$eleve = $query->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motif = $_POST['motif'];
    $date = date('Y/m/d'); 
    $annee_scolaire = '2024/2025'; 
    $coef = $_POST['coef'];


        $id_eleve = $eleve['id'];
        $note = $_POST['note'][$id_eleve];
        $appreciation = $_POST['appreciation'][$id_eleve];
        
        // Préparation et exécution de la requête d'insertion
        $stmt = $conn->prepare("INSERT INTO carnet_note (id_elev, id_enseig, nom_class, nom_enseig, nom_eleve, note, coef, motif, nom_matiere, appreciation, date, annee_scolaire) 
        VALUES (:id_elev, :id_enseig, :classe, :nom_enseig, :nom_eleve, :note, :coef, :motif, :nom_matiere, :appreciation, :date, :annee_scolaire)");
        
        $stmt->bindParam(':id_elev', $id_eleve);
        $stmt->bindParam(':id_enseig', $secr['matricule']);
        $stmt->bindParam(':classe', $eleve['classe']);
        $stmt->bindParam(':nom_enseig', $secr['nom']);
        $stmt->bindParam(':nom_eleve', $eleve['nom_elev']);
        $stmt->bindParam(':note', $note);
        $stmt->bindParam(':coef', $coef);
        $stmt->bindParam(':motif', $motif);
        $stmt->bindParam(':nom_matiere', $_POST['matiere']);
        $stmt->bindParam(':appreciation', $appreciation);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':annee_scolaire', $annee_scolaire);
        
        $stmt->execute();
        
        
    
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saisie des Notes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="container mx-auto bg-white p-6 rounded shadow-lg">
        <?php 
            $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id_class");
            $request->bindparam("id_class", $classe_id);
            $request->execute();
            $classe = $request->fetch(PDO::FETCH_ASSOC);        
        ?>
        <h1 class="text-xl text-blue-800 font-semibold mb-4 text-center md:text-left">Saisie des Notes de la <?php echo htmlspecialchars($classe['nom_class']); ?></h1>

        <!-- Date du jour et année scolaire -->
        <form action="" method="post">
            <div class="flex flex-col md:flex-row justify-between mb-4 space-y-4 md:space-y-0">
                <div>
                    <p class="text-lg font-medium">Date : <input type="text" value="<?php echo date('Y/m/d'); ?>" class="border-none bg-transparent" readonly></p>
                    <p class="text-lg font-medium">Année Scolaire : <input type="text" value="2024/2025" class="border-none bg-transparent" readonly></p>
                </div>
                <div class="md:w-1/3">
                    <label class="block text-lg font-medium text-gray-900">Matière</label>
                    <input type="text" name="matiere" class="form-input mt-1 p-2 block w-full border" required>
                </div>
                <div class="md:w-1/6">
                    <label class="block text-lg font-medium text-gray-900">Coef</label>
                    <input type="number" step="0.01" name="coef" class="form-input mt-1 p-2 block w-full border" min="1" max="6" required>
                </div>
            </div>

            <div class="mb-4">
                <label for="motif" class="block text-lg font-medium mb-2">Motif du Remplissage :</label>
                <input type="text" id="motif" name="motif" class="form-input mt-1 block w-full border p-3" placeholder="Ex: Contrôle Continu" required>
            </div>

            <!-- Liste des élèves -->
            <table class="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b font-medium text-center">Nom & Prénom</th>
                        <th class="py-2 px-4 border-b font-medium text-center">Note</th>
                        <th class="py-2 px-4 border-b font-medium text-center">Appréciation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
require "../../../../Traitement/connexion.php";
// Récupérer les élèves de la classe
$classe_id = $_GET['id_class']; // Remplace par l'ID de la classe ou autre critère
$query = $conn->prepare("SELECT * FROM eleve e LEFT JOIN carnet_note c ON e.id = c.id_elev WHERE id_class = :classe_id GROUP BY nom_elev");
$query->bindParam(':classe_id', $classe_id, PDO::PARAM_INT);
$query->execute();
$eleves = $query->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($eleves as $eleve) {
                        $id_eleve = htmlspecialchars($eleve['id']);
                        $nom_complet = htmlspecialchars($eleve['nom_elev'] . ' ' . $eleve['prenom_elev']);
                        echo '<tr>';
                        echo '<td class="py-2 text-center px-4 border-b">' . $nom_complet . '</td>';
                        echo '<td class="py-2 text-center px-4 border-b"><input type="number" step="0.01" name="note[' . $id_eleve . ']" id="note_' . $id_eleve . '" class="form-input mt-1 p-2 block w-full border" min="0" max="20" oninput="updateAppreciation(' . $id_eleve . ')" required></td>';
                        echo '<td class="py-2 text-center px-4 border-b"><input type="text" name="appreciation[' . $id_eleve . ']" id="appreciation_' . $id_eleve . '" class="form-input mt-1 p-2 block w-full border" readonly></td>';
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>

            <div class="flex flex-col md:flex-row justify-center py-4 space-y-4 md:space-y-0 md:space-x-12">
                <button type="submit" id="submitButton" class="bg-blue-500 text-white font-bold py-3 px-6 rounded hover:bg-blue-600 w-full md:w-auto">
                    Enregistrer
                </button>
                <a href="../carnet_note.php" class="text-black bg-transparent border-2 border-gray-200 hover:bg-gray-600 focus:outline-none font-medium rounded py-3 px-6 text-center w-full md:w-auto">
                    Retour
                </a>
                <a href="consulter_note.php?nom_class=<?php echo $classe['nom_class'];?>" class="text-white bg-gray-800 border-gray-400 hover:bg-gray-600 focus:outline-none font-medium rounded py-3 px-6 text-center w-full md:w-auto">
                    Consulter les notes
                </a>
            </div>
        </form>
<script>
function updateAppreciation(eleveId) {
    const note = parseFloat(document.getElementById('note_' + eleveId).value);
    const appreciationInput = document.getElementById('appreciation_' + eleveId);

    if (note < 10) {
        appreciationInput.value = "Non Acquis";
    } else if (note >= 10 && note <= 14) {
        appreciationInput.value = "En cours D'acquisition";
    } else if (note > 14 && note <= 20) {
        appreciationInput.value = "Acquis";
    } else {
        appreciationInput.value = "";
    }
}


function validateForm() {
    const notes = document.querySelectorAll('input[name^="note"]');
    for (let i = 0; i < notes.length; i++) {
        let noteValue = parseFloat(notes[i].value);
        if (noteValue > 20) {
            alert("La note ne peut pas dépasser 20.");
            return false;  // Empêche la soumission du formulaire
        }
    }
    return true;  // Permet la soumission du formulaire si toutes les notes sont valides
}

</script>

       
    </div>
</body>
</html>
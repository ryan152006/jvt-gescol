<?php
session_start();

if (!isset($_SESSION['employe'])) {
    header('Location: ../connexion_autre_poste.php');
    exit();
}

require "../../../../Traitement/connexion.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $classe = $_POST['classe'];
    $motif = $_POST['motif'];
    $notes = $_POST['note'];
    $coefs = $_POST['coef'];

    foreach ($notes as $id_elev => $note) {
        $coef = isset($coefs[$id_elev]) ? $coefs[$id_elev] : null;

        // Calcul de l'appréciation
        if ($note < 10) {
            $appreciation = "Non Acquis";
        } elseif ($note >= 10 && $note <= 14) {
            $appreciation = "En cours D'acquisition";
        } elseif ($note > 14) {
            $appreciation = "Acquis";
        }

        // Mettre à jour la note, le coef et l'appréciation dans la base de données
        $query = $conn->prepare("UPDATE carnet_note SET note = :note, coef = :coef, appreciation = :appreciation WHERE id_elev = :id_elev AND nom_class = :classe AND motif = :motif");
        $query->bindParam(':note', $note);
        $query->bindParam(':coef', $coef);
        $query->bindParam(':appreciation', $appreciation);
        $query->bindParam(':id_elev', $id_elev);
        $query->bindParam(':classe', $classe);
        $query->bindParam(':motif', $motif);
        $query->execute();
    }

    // Redirection après modification
    header('Location: consulter_note.php?nom_class=' . urlencode($classe));
    exit();
}
?>

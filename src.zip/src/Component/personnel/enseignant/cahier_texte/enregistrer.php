<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cahier de Texte</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-transparent">
    <div class="flex justify-center items-center min-h-screen p-4">
        <div class="bg-white p-6 rounded shadow-md w-full max-w-5xl">
            <h1 class="text-2xl font-medium text-blue-900 mb-4 text-center">Cahier de Texte</h1>

            <!-- Formulaire pour les données du cahier de texte -->
            <form action="../../../../Traitement/enseignant/cahier_texte/enregistrer.php" method="POST" enctype="multipart/form-data">
                <!-- Informations générales -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-4">
                    <div>
                        <label class="block text-lg font-medium text-gray-900">Grade de L'enseignant</label>
                        <input type="text" required name="grade" class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Date du jour</label>
                        <input type="text" name="date" value="<?php echo date('Y/m/d'); ?>" readonly class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Nom du Professeur</label>
                        <input type="text" name="nom_professeur" value="<?php echo $secr['nom']." ". $secr['prenom']; ?>" readonly class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Matière</label>
                        <input type="text" name="matiere" required class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Classe</label>
                        <input type="text" name="classe" value="<?php
                            require "../../../../Traitement/connexion.php";
                            $id_class = $_GET['id_class'];
                        if ($id_class) {
                            $stmt = $conn->prepare("SELECT nom_class FROM classe WHERE id_class = :id_class");
                            $stmt->bindParam(':id_class', $id_class, PDO::PARAM_INT);
                            $stmt->execute();
                            $classe = $stmt->fetch(PDO::FETCH_ASSOC);
                            echo $classe['nom_class'] ?? 'Classe non trouvée';
                        } else {
                            echo 'ID de classe non spécifié';
                        }
                        ?>" readonly class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label for="heure_debut" class="block text-lg font-medium text-gray-900">Heure de Début</label>
                        <input type="time" id="heure_debut" name="heure_debut" class="p-2 block w-full bg-transparent border border-gray-300 rounded text-gray-900" required>
                    </div>

                    <div>
                        <label for="heure_fin" class="block text-lg font-medium text-gray-900">Heure de Fin</label>
                        <input type="time" id="heure_fin" name="heure_fin" class="p-2 block w-full bg-transparent border border-gray-300 rounded text-gray-900" required>
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Année Scolaire</label>
                        <input type="text" name="annee_academique" value="2024-2025" readonly class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>

                    <div>
                        <label class="block text-lg font-medium text-gray-900">Pièce Jointe</label>
                        <input type="file" id="piecejointe" name="piecejointe" accept=".pdf,.doc,.docx,.jpg,.png" class="p-2 w-full bg-transparent border border-gray-300 rounded text-gray-900">
                    </div>
                </div>

                <!-- Avancement du cours -->
                <div class="mb-4">
                    <label for="avancement" class="block text-lg font-medium text-gray-900">Avancement du cours</label>
                    <textarea id="avancement" name="avancement" rows="5" class="p-2 block w-full bg-transparent border border-gray-300 rounded text-gray-900" placeholder="Détaillez l'avancement du cours..." required></textarea>
                </div>

                <!-- Boutons -->
                <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                    <button type="submit" class="bg-blue-500 text-white font-bold py-3 px-6 rounded hover:bg-blue-600">
                        Enregistrer
                    </button>
                    <a href="../cahier_texte.php" class="text-black bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded px-8 py-3">
                        Retour
                    </a>
                    <a href="consulter_avancement.php?id=<?php echo $id_class; ?>" class="text-white bg-gray-700 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded px-8 py-3">
                        Consulter l'avancement
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

<?php
// Connexion à la base de données
require '../../../Traitement/connexion.php';

try {
    $stmt = $conn->prepare("SELECT id_class FROM emploi_temps WHERE id_employe = :matricule");
    $stmt->bindParam(':matricule', $secr['matricule']);
    $stmt->execute();
    $classes = $stmt->fetch(PDO::FETCH_ASSOC);

    // Vérifier si un résultat a été trouvé
    if ($classes && isset($classes['id_class'])) {
    
        
        $stmt = $conn->prepare("SELECT id_class, nom_class FROM classe WHERE id_class = :id_class");
        $stmt->bindParam(':id_class', $classes['id_class']);
        $stmt->execute();
        $classe = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Gérer le cas où aucune classe n'est trouvée
        $classe = [];
 
    }
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>
<div class="container mx-auto p-6">
    <h1 class="text-2xl text-blue-500 font-bold mb-6 text-center">Choisissez une salle de classe</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php if (!empty($classe)): ?>
            <?php foreach ($classe as $class): ?>
                <a href="cahier_texte/enregistrer.php?id_class=<?php echo urlencode($class['id_class']); ?>" class="bg-blue-500 text-white p-4 rounded shadow-lg text-center hover:bg-blue-600">
                    <?php echo htmlspecialchars($class['nom_class']); ?>
                </a>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-red-500">Aucune classe disponible.</p>
        <?php endif; ?>
    </div>
</div>

<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];

// Connexion à la base de données
require "../../../../Traitement/connexion.php";

// Initialisation de la variable de recherche
$dateRecherche = isset($_GET['date']) ? $_GET['date'] : '';
$id = $_GET['id'];

// Correction de la requête pour sélectionner la classe
$request = $conn->prepare("SELECT nom_class FROM classe WHERE id_class = :id");
$request->bindParam(":id", $id, PDO::PARAM_INT);
$request->execute();
$classe = $request->fetch(PDO::FETCH_ASSOC); // On récupère la première classe
if (!$classe) {
    // Affichez un message d'erreur ou redirigez
    echo "Aucune classe trouvée pour cet ID.";
    exit();
}
// Préparation de la requête avec un filtre sur la date si fourni
$query = "SELECT * FROM cahier_texte WHERE nom_enseig = :nom_professeur AND nom_class = :classe";
if ($dateRecherche) {
    $query .= " AND date = :date";
}

$stmt = $conn->prepare($query);

// Bind des paramètres
$stmt->bindValue(':nom_professeur', $secr['nom'] . " " . $secr['prenom']);
$stmt->bindValue(':classe', $classe['nom_class']); // On lie la première classe trouvée

if ($dateRecherche) {
    $stmt->bindValue(':date', $dateRecherche);
}

$stmt->execute();
$cahiers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulter l'Avancement</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex justify-center items-center min-h-screen">
        <div class="bg-white p-6 rounded shadow-md w-full max-w-5xl">
            <h1 class="text-2xl font-medium uppercase text-center text-blue-800 mb-4">Consulter l'Avancement</h1>

            <!-- Barre de recherche -->
            <form method="get" class="mb-4 flex justify-center">
                <input type="date" name="date" value="<?php echo htmlspecialchars($dateRecherche); ?>" class="border border-gray-300 rounded-l px-4 py-2 w-1/3 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="bg-blue-500 text-white rounded-r px-4 py-2 hover:bg-blue-600 focus:outline-none">Rechercher</button>
            </form>
            <div class=" mt-1">
                <a href="enregistrer.php?id_class=<?php echo $id;?>" class="text-blue-600 mx-4 border bg-transparent  border-gray-400  font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-400">
                    Retour
                </a>
            </div>
            <!-- Tableau des cahiers de texte sous forme de fiches -->
            <div class="space-y-4">
                <?php foreach ($cahiers as $cahier) : ?>
                    <div class="bg-white p-4 rounded shadow-md">
                    <div class="flex justify-between">
                        <h2 class="text-xl font-semibold text-blue-800 mb-4"><?php echo htmlspecialchars($cahier['nom_enseig']); ?></h2>
                        <div><?php echo htmlspecialchars($cahier['grade_enseig']); ?></div>    
                    </div> 
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                          
                            <div><strong>Date :</strong> <?php echo htmlspecialchars($cahier['date']); ?></div>
                            <div><strong>Matière :</strong> <?php echo htmlspecialchars($cahier['nom_matiere']); ?></div>
                            <div><strong>Classe :</strong> <?php echo htmlspecialchars($cahier['nom_class']); ?></div>
                            <div><strong>Heure de Début :</strong> <?php echo htmlspecialchars($cahier['heure_debut']); ?></div>
                            <div><strong>Heure de Fin :</strong> <?php echo htmlspecialchars($cahier['heure_fin']); ?></div>
                            <div><strong>Année Académique :</strong> <?php echo htmlspecialchars($cahier['annee_scolaire']); ?></div>
                        </div>
                        <?php
                                   $piecejointeText = !empty($cahier['piecejointe'])
                                   ? '<p class="mt-2"><a href="../../../../Traitement/enseignant/devoir/upload/' . htmlspecialchars($cahier['piecejointe']) . '" target="_blank" class="text-blue-600 hover:underline">Télécharger la pièce jointe</a></p>'
                                   : '<p class="mt-2 text-gray-500">Pas de pièce jointe.</p>'
                        ?>
                        <div><strong>Piece Jointe :</strong> <?php echo $piecejointeText; ?> </div>
                       
                        <div><strong>Avancement :</strong> <p class="whitespace-pre-line"><?php echo htmlspecialchars($cahier['avancement']); ?></p></div>

                        <div class="flex justify-end">
                        <a href="../../../../Traitement/enseignant/cahier_texte/delete.php?id=<?php echo urlencode($cahier['code_cahier']); ?>"    onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce devoir ?');" class="text-red-600 font-medium">
                                    <button>Supprimer</button>
                                </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>

<?php
require_once '../../../Traitement/connexion.php'; // Assurez-vous que ce chemin est correct
$id_ens = $_GET['id_emp'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifiez si les champs requis sont présents
    if (isset($_POST['titre'])  && isset($_POST['classe'])  && isset($_POST['matiere'])) {
        $titre = $_POST['titre'];
        $contenu = $_POST['contenu'];
        $classe = $_POST['classe'];
        $matiere = $_POST['matiere'];
        $date_retour = $_POST['date'];
        $date = date("Y/m/d");
        $piecejointeNom = '';
        $piecejointeNewName = '';
        $uploadDir = '../../../Traitement/enseignant/devoir/upload/'; // Répertoire de destination

        if (isset($_FILES['piecejointe']) && $_FILES['piecejointe']['error'] === UPLOAD_ERR_OK) {
            $piecejointe = $_FILES['piecejointe'];
            $piecejointeNom = $piecejointe['name'];
            $piecejointeTmpName = $piecejointe['tmp_name'];
            $piecejointeSize = $piecejointe['size'];
            $piecejointeError = $piecejointe['error'];
            $piecejointeType = $piecejointe['type'];

            // Vérifier que le répertoire de téléchargement existe sinon le créer
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Valider et déplacer la pièce jointe
            if ($piecejointeError === 0) {
                // Extraire l'extension du fichier
                $piecejointeExt = strtolower(pathinfo($piecejointeNom, PATHINFO_EXTENSION));
                $allowedExts = ['pdf', 'doc', 'docx', 'jpg', 'png'];

                if (in_array($piecejointeExt, $allowedExts)) {
                    // Générer un nouveau nom unique pour le fichier
                    $piecejointeNewName = uniqid('', true) . '.' . $piecejointeExt;
                    $piecejointeDest = $uploadDir . $piecejointeNewName;

                    // Déplacer le fichier téléchargé vers le répertoire cible
                    if (!move_uploaded_file($piecejointeTmpName, $piecejointeDest)) {
                        echo "<p class='text-red-500'>Erreur lors du déplacement de la pièce jointe.</p>";
                        $piecejointeNewName = ''; // Assurez-vous que $piecejointeNewName est vide en cas d'échec
                    }
                } else {
                    echo "<p class='text-red-500'>Type de fichier non autorisé. Les extensions autorisées sont : pdf, doc, docx, jpg, png.</p>";
                }
            } else {
                echo "<p class='text-red-500'>Erreur lors du téléchargement de la pièce jointe. Code d'erreur : $piecejointeError.</p>";
            }
        }

        // Préparer et exécuter la requête SQL
        $sql = "INSERT INTO devoir (id_ens, titre, nom_mat, nom_class, contenu, piece_jointe, date, date_retour) VALUES (:id_ens, :titre, :nom_mat, :nom_class, :contenu, :piecejointe, :date, :date_retour)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_ens', $id_ens);
        $stmt->bindParam(':titre', $titre);
        $stmt->bindParam(':nom_mat', $matiere);
        $stmt->bindParam(':nom_class', $classe);
        $stmt->bindParam(':contenu', $contenu);
        $stmt->bindParam(':piecejointe', $piecejointeNewName);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':date_retour', $date_retour);

        if ($stmt->execute()) {
            header("location: devoir.php");
        } else {
            echo "<p class='text-red-500'>Erreur lors de  l'envoie du devoir.</p>";
        }
    } else {
        echo "<p class='text-red-500'>Veuillez remplir tous les champs.</p>";
    }
}
?>

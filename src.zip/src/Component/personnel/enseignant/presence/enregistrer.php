<?php
require '../../../../Traitement/connexion.php';
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    header('Location: ../../connexion_autre_poste.php');
    exit();
}

$secr = $_SESSION['employe'];
$annee_scolaire = "2024/2025";
$professeur_nom = $secr['nom'] ?? "Non défini";
$date_aujourdhui = date("Y-m-d");
$classe_id = isset($_GET['id_class']) ? $_GET['id_class'] : null;

if ($classe_id) {
    $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id_class");
    $request->bindParam(":id_class", $classe_id);
    $request->execute();
    $classe = $request->fetch(PDO::FETCH_ASSOC);

    if (!$classe) {
        die("Erreur : Classe introuvable.");
    }

    $eleves_stmt = $conn->prepare("SELECT * FROM eleve WHERE id_class = :id_class ORDER BY nom_elev");
    $eleves_stmt->bindParam(":id_class", $classe_id);
    $eleves_stmt->execute();
    $eleves = $eleves_stmt->fetchAll(PDO::FETCH_ASSOC);

    $verif_stmt = $conn->prepare("SELECT COUNT(*) FROM presence WHERE date_presence = :date_presence AND id_classe = :id_classe AND id_professeur = :matricule");
    $verif_stmt->bindParam(':date_presence', $date_aujourdhui);
    $verif_stmt->bindParam(':id_classe', $classe_id);
    $verif_stmt->bindParam(':matricule', $secr['matricule']);
    $verif_stmt->execute();
    $date_exist = $verif_stmt->fetchColumn();
} else {
    die("Erreur : ID de classe non défini.");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Présence des Élèves</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-50 to-blue-100 min-h-screen flex items-center justify-center p-4 sm:p-8">

<?php if ($date_exist > 0): ?>
    <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
        <div class="bg-white rounded shadow-md p-6 w-full max-w-md">
            <h2 class="text-xl font-semibold text-center text-red-600 mb-4">L'appel pour aujourd'hui a déjà été fait</h2>
            <p class="text-gray-700 text-center mb-6">Vous ne pouvez pas refaire l'appel pour cette classe aujourd'hui.</p>
            <div class="text-center">
                <a href="../presence.php" class="inline-block px-4 py-2 bg-red-500 text-white font-semibold rounded hover:bg-red-600 transition-colors">Retour à la page principale</a>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="w-full max-w-4xl mx-auto p-4 sm:p-8 bg-white shadow-lg rounded">
        <!-- Informations du professeur, date, année scolaire -->
        <div class="bg-gray-100 p-4 rounded mb-6 shadow-inner">
            <div class="mb-2">
                <label class="text-gray-700 font-medium">Professeur :</label>
                <input type="text" name="nom_prof" value="<?php echo htmlspecialchars($professeur_nom); ?>" class="bg-transparent text-gray-800 font-medium" readonly>
            </div>
            <div class="mb-2">
                <label class="text-gray-700 font-medium">Année scolaire :</label>
                <input type="text" name="annee" value="<?php echo $annee_scolaire; ?>" class="bg-transparent text-gray-800 font-medium" readonly>
            </div>
            <div class="mb-2">
                <label class="text-gray-700 font-medium">Date :</label>
                <input type="text" name="date" value="<?php echo $date_aujourdhui; ?>" class="bg-transparent text-gray-800 font-medium" readonly>
            </div>
        </div>

        <!-- Tableau des élèves -->
        <form action="../../../../Traitement/enseignant/presence/enregistrer_presence.php?id_class=<?php echo $classe_id;?>" method="post">
            <div class="overflow-x-auto">
                <table class="min-w-full border-collapse border border-gray-200 text-left rounded overflow-hidden shadow-sm">
                    <thead>
                        <tr class="bg-blue-500 text-white">
                            <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">ID Élève</th>
                            <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Nom</th>
                            <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Absent</th>
                            <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Heures d'absence</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-100">
                        <!-- Boucle des élèves -->
                         <?php
                        $ide = 1;
                        ?>
                        <?php foreach ($eleves as $eleve): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                <input type="hidden" name="id_elev[]" value="<?php echo htmlspecialchars($eleve['id']) ?>">
                                <?php echo htmlspecialchars($ide); ?>
                            </td>
                            <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center"><?php echo htmlspecialchars($eleve['nom_elev'] . ' ' . $eleve['prenom_elev']); ?></td>
                            <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                <input type="checkbox" name="absence[]" value="<?php echo htmlspecialchars($eleve['id']); ?>" class="form-checkbox h-5 w-5 text-red-500" onchange="toggleHeureAbsence(this, '<?php echo $eleve['id']; ?>')">
                            </td>
                            <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                <select name="heures_absence[<?php echo $eleve['id']; ?>]" id="heures_absence_<?php echo $eleve['id']; ?>" disabled>
                                    <option value="1">1 heure</option>
                                    <option value="2">2 heures</option>
                                    <option value="3">3 heures</option>
                                    <option value="4">4 heures</option>
                                </select>
                             </td>
                        </tr>
                        <?php
                        $ide = $ide + 1; 
                        ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Résumé de la présence -->
            <div class="mt-6">
                <label for="resume_pres" class="block text-gray-700 font-medium mb-2">Résumé de la présence (optionnel) :</label>
                <textarea id="resume_pres" name="resume_pres" rows="4" class="w-full p-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
            </div>

            <!-- Boutons d'action -->
            <div class="mt-8 flex justify-center space-x-4">
                <button type="submit" class="px-6 py-2 bg-blue-500 text-white font-semibold rounded hover:bg-blue-600 transition-all">
                    Enregistrer
                </button>
                <div class="text-center">
                <a href="../presence.php" class="inline-block px-4 py-2 bg-red-500 text-white font-semibold rounded hover:bg-red-600 transition-colors">Retour à la page principale</a>
            </div>
            </div>
        </form>
    </div>
<?php endif; ?>

<script>
// Fonction pour activer/désactiver le champ des heures d'absence
function toggleHeureAbsence(checkbox, eleveId) {
    var selectHeures = document.getElementById('heures_absence_' + eleveId);
    selectHeures.disabled = !checkbox.checked;
}
</script>

</body>
</html>

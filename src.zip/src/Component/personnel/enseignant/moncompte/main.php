<div class="w-full max-w-2xl pb-2 mx-4 md:mx-8 my-6 border border-blue-500 rounded shadow hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700 overflow-hidden">
    <div class="w-full justify-between items-center">
        <div class="flex flex-col items-center justify-center">
           <h4 class="text-center py-4 text-2xl font-bold text-blue-500">College Bilingue JEAN XXIII D'EFOK</h4>
           <h2 class="text-xl text-center font-medium text-white">Compte Personnel</h2>
        </div>
    </div>

    <div class="mx-4 md:mx-8">
        <!-- Nom et Prenom -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="nom">Nom</label>
              <p id="nom" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['nom']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="prenom">Prenom</label>
              <p id="prenom" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['prenom']); ?></p>
          </div>
        </div>

        <!-- Email et Telephone -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="email">Email</label>
              <p id="email" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['email']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="telephone">Telephone</label>
              <p id="telephone" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['telephone']); ?></p>
          </div>
        </div>

        <!-- Matricule et Poste -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="matricule">Matricule</label>
              <p id="matricule" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['matricule']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="poste">Poste</label>
              <p id="poste" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['poste']); ?></p>
          </div>
        </div>

        <!-- Sexe -->
        <div class="mb-4 md:mb-2">
            <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="sexe">Sexe</label>
            <p id="sexe" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['sexe']); ?></p>
        </div>
        
        <small class="text-sm py-2 text-left text-blue-500">Nous assurons une confidentialite des informations de ce compte.</small>
    </div>
</div>

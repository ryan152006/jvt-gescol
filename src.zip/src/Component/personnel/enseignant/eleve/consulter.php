<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <title>Fiche d'Identification de l'Élève</title>
    <style>
        body{
            background-image: url("../../../../Assets/back1.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-content {
            padding: 1rem;
        }
        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>
<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-4xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Fiche d'Identification de l'Élève
                </div>
                <div class="card-content">
                    <?php
                        require_once '../../../../Traitement/connexion.php';
                        
                        $id = $_GET['id'];
                        $request = $conn->prepare("SELECT * FROM eleve WHERE code_elev = :id");
                        $request->bindParam(':id', $id, PDO::PARAM_INT);
                        $request->execute();
                        $row = $request->fetch(PDO::FETCH_ASSOC);
                        
                        if ($row) {
                            // Formater la date de naissance pour le champ date
                            $formattedDate = date('d-m-Y', strtotime($row['date_naiss']));
                            $sexe = $row['sexe_elev'] == 'masculin' ? 'Masculin' : 'Féminin';
                            $categorie = $row['categorie'] == 'nouveau' ? 'Nouveau' : 'Ancien';
                    ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p class="font-semibold text-gray-700">Nom :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['nom_elev']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Prénom :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['prenom_elev']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Date de Naissance :</p>
                            <p class="text-gray-900"><?= $formattedDate ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Sexe :</p>
                            <p class="text-gray-900"><?= $sexe ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Lieu de Naissance :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['lieu_naiss']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Téléphone :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['telephone']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Personne à Prévenir :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['telurgence']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Classe :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['classe']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Catégorie :</p>
                            <p class="text-gray-900"><?= $categorie ?></p>
                        </div>
                    </div>
                    <?php
                        } else {
                            echo "<p>Aucun élève trouvé avec cet ID.</p>";
                        }
                    ?>
                </div>
                <div class="card-footer">
                    <a href="../eleve.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des élèves</a>
                </div>
            </div>
        </div>
    </section>

</body>
</html>

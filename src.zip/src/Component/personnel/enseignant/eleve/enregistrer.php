<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Enregistrement</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Enregistrer Un Nouvel Élève
                </h1>

                <form id="registration-form" action="../../../../Traitement/secretaire/enregistrer.php" method="post" class="space-y-2 sm:space-y-4">
                    <!-- Informations Personnelles -->
                    <fieldset id="personal-info" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Personnelles</legend>
                        <!-- Nom -->
                        <div class="flex flex-col">
                            <label for="nom" class="block text-sm font-normal text-gray-900 dark:text-white">Nom</label>
                            <input type="text" name="nom" id="nom" placeholder="Ex: Dupont" title="Entrez le nom de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Prénom -->
                        <div class="flex flex-col">
                            <label for="prenom" class="block text-sm font-normal text-gray-900 dark:text-white">Prénom</label>
                            <input type="text" name="prenom" id="prenom" placeholder="Ex: Marie" title="Entrez le prénom de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Date de Naissance -->
                        <div class="flex flex-col">
                            <label for="date" class="block text-sm font-normal text-gray-900 dark:text-white">Date de Naissance</label>
                            <input type="date" name="date" id="date" placeholder="JJ/MM/AAAA" title="Sélectionnez la date de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Lieu de Naissance -->
                        <div class="flex flex-col">
                            <label for="lieu" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Naissance</label>
                            <input type="text" name="lieu" id="lieu" placeholder="Ex: Paris" title="Entrez le lieu de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Sexe -->
                        <div class="flex flex-col">
                            <label for="sexe" class="block text-sm font-normal text-gray-900 dark:text-white">Sexe</label>
                            <select name="sexe" id="sexe" title="Sélectionnez le sexe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled class="text-gray-500">Sélectionnez</option>
                                <option value="masculin">Masculin</option>
                                <option value="feminin">Féminin</option>
                            </select>
                        </div>
                    </fieldset>

                    <!-- Informations Secondaires -->
                    <fieldset id="secondary-info" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Secondaires</legend>
                        <!-- Téléphone -->
                        <div class="flex flex-col">
                            <label for="telephone" class="block text-sm font-normal text-gray-900 dark:text-white">Téléphone</label>
                            <input type="tel" name="telephone" id="telephone" placeholder="Ex: 6 23 45 67 89" title="Entrez le numéro de téléphone de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="autretephone" class="block text-sm font-normal text-gray-900 dark:text-white">Personne à Prévenir (Parent)</label>
                            <input type="tel" name="autretephone" id="autretephone" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone de la personne à prévenir en cas d'urgence" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Classe -->
                        <div class="flex flex-col">
                            <label for="classe" class="block text-sm font-normal text-gray-900 dark:text-white">Classe</label>
                            <select name="classe" id="classe" title="Sélectionnez la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled>Selectionner la classe</option>
                                <?php
                                
                                require '../../../../Traitement/connexion.php';
                                $query = "SELECT id_class, nom_class FROM classe";
                                $stmt = $conn->prepare($query);
                                $stmt->execute();
                                $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                // Générer les options du menu déroulant
                                foreach ($classes as $classe) {
                                    echo "<option value=\"{$classe['nom_class']}\">{$classe['nom_class']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <!-- Catégorie -->
                        <div class="flex flex-col">
                            <label for="categorie" class="block text-sm font-normal text-gray-900 dark:text-white">Catégorie de l'élève</label>
                            <select name="categorie" id="categorie" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="nouveau" selected disabled class="text-gray-500">Ancien ou Nouveau</option>
                                <option value="ancien">Ancien</option>
                                <option value="nouveau">Nouveau</option>
                            </select>
                        </div>
                    </fieldset>

                    <!-- Boutons -->
                    <div class="flex justify-between items-center mt-4">
                        <button type="button" id="next-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-normal rounded text-xl px-8 py-2 text-center dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-700 disabled">
                            Suivant
                        </button>
                        <button type="button" id="previous-button" class="hidden text-white bg-transparent hover:bg-gray-600  border-2 border-gray-400 hover:bg-gray-600  focus:outline-none  font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-blue-700">
                            Précédent
                        </button>
                        <button type="submit" id="submit-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center   dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../eleve.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2">Veuillez remplir tous les champs pour enregistrer un nouvel élève!</small>
                </form>
            </div>
        </div>
    </section>

    <script>
        const personalInfoFieldset = document.getElementById('personal-info');
        const secondaryInfoFieldset = document.getElementById('secondary-info');
        const nextButton = document.getElementById('next-button');
        const previousButton = document.getElementById('previous-button');
        const submitButton = document.getElementById('submit-button');

        function validatePersonalInfo() {
            // Sélectionner tous les champs requis dans le fieldset d'informations personnelles
            const requiredFields = personalInfoFieldset.querySelectorAll('input[required], select[required]');
            // Vérifier si tous les champs sont remplis
            return Array.from(requiredFields).every(field => field.value.trim() !== '');
        }

        function toggleNextButton() {
            if (validatePersonalInfo()) {
                nextButton.classList.remove('disabled');
                nextButton.disabled = false;
            } else {
                nextButton.classList.add('disabled');
                nextButton.disabled = true;
            }
        }

        // Ajouter des écouteurs d'événements pour surveiller les changements dans les champs
        personalInfoFieldset.addEventListener('input', toggleNextButton);

        nextButton.addEventListener('click', () => {
            if (validatePersonalInfo()) {
                personalInfoFieldset.classList.add('hidden');
                secondaryInfoFieldset.classList.remove('hidden');
                nextButton.classList.add('hidden');
                previousButton.classList.remove('hidden');
                submitButton.classList.remove('hidden');
            }
        });

        previousButton.addEventListener('click', () => {
            personalInfoFieldset.classList.remove('hidden');
            secondaryInfoFieldset.classList.add('hidden');
            nextButton.classList.remove('hidden');
            previousButton.classList.add('hidden');
            submitButton.classList.add('hidden');
        });

        // Initialiser le bouton "Suivant" lors du chargement de la page
        toggleNextButton();
    </script>
</body>
</html>

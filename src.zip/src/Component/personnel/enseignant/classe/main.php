<!-- Start block -->

<?php
// index.php
include '../../../Traitement/connexion.php'; // Inclure le fichier de connexion

// Requête pour obtenir les classes
$query = "SELECT * FROM classe";
$stmt = $conn->prepare($query);
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!-- Start block -->

<div class="mx-auto w-auto overflow-x-hidden justify-center items-center  py-4  scrollable-modal">
        <!-- Start coding here -->
        <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
           
           
            <div class=" py-6 overflow-x-hidden justify-center items-center space-y-4">
                <span class="border border-blue-500 rounded p-2 text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 px-4 space-x-2">Liste des Salles de Classe du College <br> <span class="text-blue-500"> JEAN XXIII D'EFOK </span> </span>
                <div class="w-auto">
                    <a href="classe/enregistrer.php"  class="">
                        <button class="text-white bg-blue-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
                            + Ajouter une nouvelle classe
                        </button>
                        </a>
                       
                </div>
                <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                    <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-3 py-3">Libelle</th>
                            <th scope="col" class="px-3 py-3">Effectif</th>
                            <th scope="col" class="px-3 py-3">Prof titulaire</th>
                            <th scope="col" class="px-3 py-3">Description</th>
                            <th scope="col" class="px-3 py-3">Pension</th>
                            <th scope="col" class="px-3 py-3">Inscription</th>
                            <th scope="col" class="px-3 py-3">1<sup>ere</sup>Tranche</th>
                            <th scope="col" class="px-3 py-3">2<sup>eme</sup>Tranche</th>
                            <th scope="col" class="px-3 py-3">3<sup>eme</sup>Tranche</th>
                            
                            <th scope="col" class="px-3 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="overflow-y-auto overflow-x-auto">
                        <?php foreach ($classes as $classe): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['nom_class']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['nbre_elev']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['nom_enseig']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['description']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['pension']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['inscription']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['tranche1']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['tranche2']); ?></td>
                            <td class="px-3 text-center max-w-[16rem] truncate py-3"><?php echo htmlspecialchars($classe['tranche3']); ?></td>
                            <td class="px-3 text-center py-3 flex items-center justify-end space-x-3">
                                <a href="classe/modifier.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-green-500 text-center font-medium">
                                    <button>Modifier</button>
                                </a>
                                <a href="classe/consulter.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-blue-500 text-center font-medium">
                                    <button>Consulter</button>
                                </a>
                                <a href="../../../Traitement/secretaire/classe/delete.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-red-400 text-center font-medium">
                                    <button>Supprimer</button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
        </div>
   

<!-- End block -->
<!-- Create modal -->




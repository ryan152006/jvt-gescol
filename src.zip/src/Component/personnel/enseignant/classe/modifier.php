<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["libelle"], $_POST["effectif"], $_POST["professeur"], $_POST["description"],
              $_POST["pension"], $_POST["inscription"], $_POST["tranche1"], $_POST["tranche2"], $_POST["tranche3"])) {
        
        // Récupération des données du formulaire
        $libelle = $_POST["libelle"];
        $effectif = $_POST["effectif"];
        $professeur = $_POST["professeur"];
        $description = $_POST["description"];
        $pension = $_POST["pension"];
        $inscription = $_POST["inscription"];
        $tranche1 = $_POST["tranche1"];
        $tranche2 = $_POST["tranche2"];
        $tranche3 = $_POST["tranche3"];
        $id = $_GET['id']; // Assurez-vous que l'ID est bien récupéré
      
        $pension = (float) $pension;
        $inscription = (float) $inscription;
        $tranche1 = (float) $tranche1;
        $tranche2 = (float) $tranche2;
        $tranche3 = (float) $tranche3;
        // Validation de la somme des montants
        $totalMontant = $inscription + $tranche1 + $tranche2 + $tranche3;
    
        if ($totalMontant !== $pension) {
            echo "<script> alert('verifier les montants doivent etre egaux a la pension') </script>";
        } else {
        // Préparation de la requête SQL pour la mise à jour
        $request = $conn->prepare("UPDATE classe SET 
            nom_class = :libelle, 
            nbre_elev = :effectif,
            nom_enseig = :professeur, 
            description = :description,
            pension = :pension,
            inscription = :inscription,
            tranche1 = :tranche1,
            tranche2 = :tranche2,
            tranche3 = :tranche3
            WHERE id_class = :id");

        // Liaison des paramètres
        $request->bindParam(':libelle', $libelle);
        $request->bindParam(':effectif', $effectif);
        $request->bindParam(':professeur', $professeur);
        $request->bindParam(':description', $description);
        $request->bindParam(':pension', $pension);
        $request->bindParam(':inscription', $inscription);
        $request->bindParam(':tranche1', $tranche1);
        $request->bindParam(':tranche2', $tranche2);
        $request->bindParam(':tranche3', $tranche3);
        $request->bindParam(':id', $id);
        
        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../classe.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
    }
}

$id = $_GET['id'] ?? null;
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Modification de la Classe</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Modifier les Informations de Classe
                </h1>
                <?php if ($row) : ?>
                <form id="registration-form" method="post" class="space-y-2 sm:space-y-4">
                    <!-- Informations sur la Classe -->
                    <fieldset id="fieldset-1" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations sur la Classe</legend>
                        <!-- Libellé -->
                        <div class="flex flex-col">
                            <label for="libelle" class="block text-sm font-normal text-gray-900 dark:text-white">Libellé</label>
                            <input type="text" name="libelle" id="libelle" placeholder="Ex: Mathématiques" value="<?= htmlspecialchars($row['nom_class']) ?>" title="Entrez le libellé de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Effectif -->
                        <div class="flex flex-col">
                            <label for="effectif" class="block text-sm font-normal text-gray-900 dark:text-white">Effectif</label>
                            <input type="number" name="effectif" id="effectif" placeholder="Ex: 30" value="<?= htmlspecialchars($row['nbre_elev']) ?>" title="Entrez l'effectif de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Professeur -->
                        <div class="flex flex-col">
                            <label for="professeur" class="block text-sm font-normal text-gray-900 dark:text-white">Professeur</label>
                            <input type="text" name="professeur" id="professeur" placeholder="Ex: M. Dupont" value="<?= htmlspecialchars($row['nom_enseig']) ?>" title="Entrez le nom du professeur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Description -->
                        <div class="flex flex-col">
                            <label for="description" class="block text-sm font-normal text-gray-900 dark:text-white">Description</label>
                            <textarea name="description" id="description" placeholder="Ex: Classe dédiée aux cours de mathématiques avancés" title="Entrez une description pour la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required><?= htmlspecialchars($row['description']) ?></textarea>
                        </div>
                    </fieldset>

                    <!-- Informations Financières -->
                    <fieldset id="fieldset-2" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Financières</legend>
                        <!-- Montant de la Pension -->
                        <div class="flex flex-col">
                            <label for="pension" class="block text-sm font-normal text-gray-900 dark:text-white">Montant de la Pension</label>
                            <input type="number" name="pension" id="pension" placeholder="Ex: 500" value="<?= htmlspecialchars($row['pension']) ?>" title="Entrez le montant de la pension" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Montant de l'Inscription -->
                        <div class="flex flex-col">
                            <label for="inscription" class="block text-sm font-normal text-gray-900 dark:text-white">Montant de l'Inscription</label>
                            <input type="number" name="inscription" id="inscription" placeholder="Ex: 100" value="<?= htmlspecialchars($row['inscription']) ?>" title="Entrez le montant de l'inscription" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Montants des Tranches -->
                        <div class="flex flex-col">
                            <label for="tranche1" class="block text-sm font-normal text-gray-900 dark:text-white">Tranche 1</label>
                            <input type="number" name="tranche1" id="tranche1" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche1']) ?>" title="Entrez le montant de la tranche 1" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="tranche2" class="block text-sm font-normal text-gray-900 dark:text-white">Tranche 2</label>
                            <input type="number" name="tranche2" id="tranche2" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche2']) ?>" title="Entrez le montant de la tranche 2" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="tranche3" class="block text-sm font-normal text-gray-900 dark:text-white">Tranche 3</label>
                            <input type="number" name="tranche3" id="tranche3" placeholder="Ex: 150" value="<?= htmlspecialchars($row['tranche3']) ?>" title="Entrez le montant de la tranche 3" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                    </fieldset>

                    <!-- Boutons -->
                    <div class="flex justify-between items-center mt-4">
                        <button type="button" id="prev-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700" onclick="showFieldset(1)">
                            Précédent
                        </button>
                        <button type="button" id="next-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700" onclick="showFieldset(2)">
                            Suivant
                        </button>
                        <button type="submit" id="submit-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../classe.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                </form>
                <?php else : ?>
                    <p>Aucune classe trouvée avec cet ID.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <script>
        function showFieldset(fieldsetNumber) {
            const fieldset1 = document.getElementById('fieldset-1');
            const fieldset2 = document.getElementById('fieldset-2');
            const prevButton = document.getElementById('prev-button');
            const nextButton = document.getElementById('next-button');
            const submitButton = document.getElementById('submit-button');

            if (fieldsetNumber === 1) {
                fieldset1.classList.remove('hidden');
                fieldset2.classList.add('hidden');
                prevButton.classList.add('hidden');
                nextButton.classList.remove('hidden');
                submitButton.classList.add('hidden');
            } else if (fieldsetNumber === 2) {
                fieldset1.classList.add('hidden');
                fieldset2.classList.remove('hidden');
                prevButton.classList.remove('hidden');
                nextButton.classList.add('hidden');
                submitButton.classList.remove('hidden');
            }
        }

        // Show the first fieldset initially
        showFieldset(1);
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Enregistrement d'une Classe</title>
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Enregistrer Une Nouvelle Classe
                </h1>

                <form id="registration-form" action="../../../../Traitement/secretaire/classe/enregistrer.php" method="post" class="space-y-2 sm:space-y-4">
                    <!-- Informations sur la Classe -->
                    <fieldset id="fieldset-1" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations sur la Classe</legend>
                        <!-- Libellé -->
                        <div class="flex flex-col">
                            <label for="libelle" class="block text-sm font-normal text-gray-900 dark:text-white">Libellé</label>
                            <input type="text" name="libelle" id="libelle" placeholder="Ex: Terminale S" title="Entrez le libellé de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Effectif -->
                        <div class="flex flex-col">
                            <label for="effectif" class="block text-sm font-normal text-gray-900 dark:text-white">Effectif</label>
                            <input type="number" disabled name="effectif" id="effectif" value="0" title="Entrez le nombre d'élèves dans la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <?php
// Inclusion du fichier de connexion PDO
include '../../../../Traitement/connexion.php';

try {
    // Préparer et exécuter la requête SQL
    $stmt = $conn->prepare("SELECT matricule, nom, prenom FROM employe");
    $stmt->execute();
    
    // Récupérer les résultats dans un tableau associatif
    $employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erreur lors de la récupération des employés : ' . $e->getMessage();
    $employes = [];
}

// Fermer la connexion
$conn = null;
?>
                        <!-- Professeur Titulaire -->
                        <div class="flex flex-col">
                            <label for="professeur" class="block text-sm font-normal text-gray-900 dark:text-white">Professeur Titulaire</label>
                            <select name="professeur" id="professeur" title="Sélectionnez le professeur titulaire" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                            <option value="" disabled selected>Sélectionnez un professeur Titulaire</option>
                            <?php foreach ($employes as $employe): ?>
                                <option value="<?php echo htmlspecialchars($employe['nom']); ?>">
                                    <?php echo htmlspecialchars($employe['prenom'] . ' ' . $employe['nom']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        </div>
                        <!-- Description -->
                        <div class="flex flex-col">
                            <label for="description" class="block text-sm font-normal text-gray-900 dark:text-white">Description</label>
                            <textarea name="description" id="description" placeholder="Entrez une description de la classe" title="Entrez une description de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" rows="3"></textarea>
                        </div>
                    </fieldset>

                    <!-- Informations Financières -->
                    <fieldset id="fieldset-2" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Financières</legend>
                        <!-- Montant de la Pension -->
                        <div class="flex flex-col">
                            <label for="pension" class="block text-sm font-normal text-gray-900 dark:text-white">Montant de la Pension</label>
                            <input type="number" name="pension" id="pension" placeholder="Ex: 300 000" title="Entrez le montant de la pension" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Montant de l'Inscription -->
                        <div class="flex flex-col">
                            <label for="inscription" class="block text-sm font-normal text-gray-900 dark:text-white">Montant de l'Inscription</label>
                            <input type="number" name="inscription" id="inscription" placeholder="Ex: 100 000" title="Entrez le montant de l'inscription" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- 1ère Tranche -->
                        <div class="flex flex-col">
                            <label for="tranche1" class="block text-sm font-normal text-gray-900 dark:text-white">1ère Tranche</label>
                            <input type="number" name="tranche1" id="tranche1" placeholder="Ex: 200" title="Entrez le montant de la 1ère tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- 2ème Tranche -->
                        <div class="flex flex-col">
                            <label for="tranche2" class="block text-sm font-normal text-gray-900 dark:text-white">2ème Tranche</label>
                            <input type="number" name="tranche2" id="tranche2" placeholder="Ex: 200 000" title="Entrez le montant de la 2ème tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- 3ème Tranche -->
                        <div class="flex flex-col">
                            <label for="tranche3" class="block text-sm font-normal text-gray-900 dark:text-white">3ème Tranche</label>
                            <input type="number" name="tranche3" id="tranche3" placeholder="Ex: 100 000" title="Entrez le montant de la 3ème tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                    </fieldset>

                    <!-- Navigation -->
                    <div class="flex justify-between items-center mt-4">
                        <button type="button" id="prev-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700" onclick="showFieldset(1)">
                            Précédent
                        </button>
                        <button type="button" id="next-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700" onclick="showFieldset(2)">
                            Suivant
                        </button>
                        <button type="submit" id="submit-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../classe.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2">Veuillez remplir tous les champs pour enregistrer une nouvelle classe!</small>
                </form>
            </div>
        </div>
    </section>

    <script>
        function showFieldset(fieldsetNumber) {
            const fieldset1 = document.getElementById('fieldset-1');
            const fieldset2 = document.getElementById('fieldset-2');
            const prevButton = document.getElementById('prev-button');
            const nextButton = document.getElementById('next-button');
            const submitButton = document.getElementById('submit-button');

            if (fieldsetNumber === 1) {
                fieldset1.classList.remove('hidden');
                fieldset2.classList.add('hidden');
                prevButton.classList.add('hidden');
                nextButton.classList.remove('hidden');
                submitButton.classList.add('hidden');
            } else if (fieldsetNumber === 2) {
                fieldset1.classList.add('hidden');
                fieldset2.classList.remove('hidden');
                prevButton.classList.remove('hidden');
                nextButton.classList.add('hidden');
                submitButton.classList.remove('hidden');
            }
        }

        // Show the first fieldset initially
        showFieldset(1);
    </script>
</body>
</html>

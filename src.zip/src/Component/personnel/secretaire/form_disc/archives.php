<?php
require "../../../../Traitement/connexion.php";

// Préparation de la requête SQL pour récupérer les articles archivés
$request = $conn->prepare("SELECT * FROM formulaire_disci WHERE archived = 1 ORDER BY id_form ASC");
$request->execute();
$archivedArticles = $request->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Articles Archivés</title>
    <style>
        body {
           
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>
<body class="bg-gray-100">
<section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-3xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Liste des Articles Archivés
                </div>
                <div class="card-content">
                    <div class="space-y-4">
                        <?php if ($archivedArticles) : ?>
                            <?php foreach ($archivedArticles as $article) : ?>
                                <div class="border-b border-gray-300 pb-4 mb-4">
                                    <div class="text-lg font-medium text-blue-500">
                                        <?php echo htmlspecialchars($article['titre']); ?>
                                    </div>
                                    <div class="mt-1 text-sm text-gray-900">
                                        <?php echo nl2br(htmlspecialchars($article['contenu'])); ?>
                                    </div>
                                    <div class="mt-4">
                                        <a href="restaurer.php?id=<?php echo urlencode($article['id_form']); ?>" class="text-green-500 text-center font-medium">
                                            Restaurer
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <p>Aucun article archivé trouvé.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="../form_disc.php" class="text-blue-500 hover:text-blue-700">Retour à l'accueil</a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>

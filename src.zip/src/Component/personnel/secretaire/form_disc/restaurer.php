<?php
require "../../../../Traitement/connexion.php";

// Vérifie que l'ID est passé via la requête GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Préparation de la requête SQL pour restaurer l'article
    $request = $conn->prepare("UPDATE formulaire_disci SET archived = 0 WHERE id_form = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);

    try {
        $request->execute();
        header("Location: archives.php"); // Redirige vers la liste des archives
        exit();
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
} else {
    echo "ID d'article non spécifié.";
}
?>

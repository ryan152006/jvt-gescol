
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>

<div id="main-content" class="container mx-auto flex flex-col justify-content items-center py-8 px-4 sm:px-8">
    <div class="border-2 border-blue-500 bg-transparent w-full text-center py-4">
        <p class="text-xl sm:text-2xl text-blue-500 font-semibold">Formulaire de Discipline du Collège JEAN XXIII d'EFOK</p>
    </div>

    <div class="py-3 w-full">
        <div class="flex flex-col sm:flex-row justify-between space-y-4 sm:space-y-0 py-4">
            <a href="form_disc/enregistrer.php" class="sm:px-4">
                <button class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded text-sm px-4 py-2 focus:outline-none">
                    + Ajouter Un Nouvel Article
                </button>
            </a>
            <a href="form_disc/consulterall.php" class="sm:px-4">
                <button class="text-white bg-transparent border-2 border-gray-600 hover:bg-gray-700 font-medium rounded text-sm px-4 py-2">
                    Consulter la Liste des Articles
                </button>
            </a>
            <a href="form_disc/archives.php">
                <button class="text-white bg-transparent border-2 border-gray-600 hover:bg-gray-700 font-medium rounded text-sm px-4 py-2">
                    Consulter la Liste des Archives
                </button>
            </a>
        </div>

        <!-- Table responsive -->
        <div class="w-full overflow-x-auto">
            <table class="w-full text-sm text-center text-gray-500">
                <thead class="text-xs text-gray-700 bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">Article N<sup>o</sup></th>
                        <th scope="col" class="px-6 py-3">Titre</th>
                        <th scope="col" class="px-6 py-3">Description Courte</th>
                        <th scope="col" class="px-6 py-3">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
require "../../../Traitement/connexion.php";

// Préparation de la requête SQL pour obtenir les articles non archivés
$slmt = $conn->prepare("SELECT * FROM formulaire_disci WHERE archived = 0");
$slmt->execute();
$disc = $slmt->fetchAll(PDO::FETCH_ASSOC);
?>
                    <!-- Boucle PHP pour les articles -->
                    <?php if ($disc) : ?>
                    <?php foreach($disc as $row): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-6 py-2 font-medium text-gray-900 dark:text-white"><?php echo htmlspecialchars($row['id_form']); ?></td>
                            <td class="px-6 py-2 max-w-[16rem] truncate"><?php echo htmlspecialchars($row['titre']); ?></td>
                            <td class="px-6 py-2 max-w-[16rem] truncate"><?php echo htmlspecialchars($row['contenu']); ?></td>
                            <td class="px-6 py-2 flex justify-center space-x-2">
                                <a href="form_disc/modifier.php?id=<?php echo urlencode($row['id_form']); ?>" class="text-green-500 font-medium">Modifier</a>
                                <a href="form_disc/consulter.php?id=<?php echo urlencode($row['id_form']); ?>" class="text-blue-500 font-medium">Consulter</a>
                                <a href="form_disc/archiver.php?id=<?php echo urlencode($row['id_form']); ?>" class="text-blue-300 font-medium">Archiver</a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    <?php else : ?>
                    <tr>
                        <td colspan="4" class="py-2 text-white">Aucun règlement n'a été ajouté</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php


// Récupération des fichiers depuis la base de données
$stmt = $conn->prepare("SELECT * FROM piece_jointe");
$stmt->execute();
$pieces_jointes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
        <!-- Affichage des fichiers -->
        <div class="py-4 w-full">
            <h2 class="text-blue-500 font-semibold mb-2">Pièces Jointes</h2>
            <div class="flex flex-col items-center">
                <?php foreach ($pieces_jointes as $piece) : ?>
                <div class="rounded p-4 mb-2 w-full max-w-md text-center">
                    <div class="mb-2 text-white text-3xl">
                        <i class="fas fa-file"></i> <!-- Remplacez par le bon icon -->
                    </div>
                    <p class="mb-2 text-white"><?php echo htmlspecialchars($piece['file_name']); ?></p>
                    <a href="<?php echo htmlspecialchars($piece['file_path']); ?>" download class="text-blue-500 hover:underline">Télécharger</a>
                    <a href="form_disc/supp.php?id=<?php echo $piece['id'];?>" class="text-red-500 px-4 hover:underline">Supprimer</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal section -->
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('form_disc/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>

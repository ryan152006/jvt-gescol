<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["titre"], $_POST["contenu"])) {
        
        // Récupération des données du formulaire
        $titre = $_POST["titre"];
        $contenu = $_POST["contenu"];
        
        $id = $_GET['id']; // Assurez-vous que l'ID est bien récupéré

        // Préparation de la requête SQL
        $request = $conn->prepare("UPDATE formulaire_disci SET titre = :titre, contenu = :contenu WHERE id_form = :id");

        // Liaison des paramètres
        $request->bindParam(':titre', $titre);
        $request->bindParam(':contenu', $contenu);
        $request->bindParam(':id', $id);

        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../form_disc.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}

$id = $_GET['id'] ?? null;
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM formulaire_disci WHERE id_form = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>

    <title>Modification</title>
    <style>
        body {
          
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>
<body class="bg-gray-100">
<section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-3xl">
            <div class="card">
                
                
                <?php if ($row) : 
                  
                ?>
                 <div class="card-header text-blue-500">
                 Modifier L'article N<sup>o</sup> <?php echo htmlspecialchars($row['id_form']);  ?>
                </div>
                <div class="card-content">
                <form  method="post"  class="space-y-4">
                        <div>
                            <label for="titre" class="block text-sm font-medium text-gray-700">Titre</label>
                            <input type="text" id="titre" name="titre" required value="<?= htmlspecialchars($row['titre']) ?>"
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu</label>
                            <textarea id="contenu" name="contenu" rows="4" required value=""
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900"><?php echo htmlspecialchars($row['contenu']) ?></textarea>
                        </div>
                       
                        <div>
                            <button type="submit"
                                class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center">
                                Modifier l'Article
                            </button>
                        </div>
                    </form>

                <?php else : ?>
                    <p>Aucun article trouvé avec cet ID.</p>
                <?php endif; ?>
                </div>
                <div class="card-footer">
                    <a href="../form_disc.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des articles</a>
                </div>
                </div>
        </div>
    </section>

  
</body>
</html>

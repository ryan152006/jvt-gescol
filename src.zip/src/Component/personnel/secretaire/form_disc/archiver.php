<?php
require "../../../../Traitement/connexion.php";

// Vérifie que l'ID est passé via la requête GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Préparation de la requête SQL pour archiver l'article
    $request = $conn->prepare("UPDATE formulaire_disci SET archived = 1 WHERE id_form = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);

    try {
        $request->execute();
        header("Location: ../form_disc.php"); // Redirige vers la page principale
        exit();
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
} else {
    echo "ID d'article non spécifié.";
}
?>

<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["titre"], $_POST["contenu"])) {
        
        // Récupération des données du formulaire
        $titre = $_POST["titre"];
        $contenu = $_POST["contenu"];
        
        $id = $_GET['id']; // Assurez-vous que l'ID est bien récupéré

        // Préparation de la requête SQL
        $request = $conn->prepare("UPDATE formulaire_disci SET titre = :titre, contenu = :contenu WHERE id_form = :id");

        // Liaison des paramètres
        $request->bindParam(':titre', $titre);
        $request->bindParam(':contenu', $contenu);
        $request->bindParam(':id', $id);

        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../form_disc.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}

$id = $_GET['id'] ?? null;
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM formulaire_disci WHERE id_form = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>

    <title>Consultation</title>
    <style>
        body {
           
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>
<body class="bg-gray-100">
<section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-3xl">
            <div class="card">
                
                
                <?php if ($row) : 
                  
                ?>
                 <div class="card-header text-blue-500">
                 Consulter L'article N<sup>o</sup> <?php echo htmlspecialchars($row['id_form']);  ?>
                </div>
                <div class="card-content">
                <div    class="space-y-4">
                        <div>
                            <span  class="block text-xl font-medium text-blue-500">Titre</span>
                            <div  class="mt-1 block w-full text-xl font-medium sm:text-sm bg-white text-gray-900"> <?php echo htmlspecialchars($row['titre']); ?></div>
                               
                        </div>
                        <div>
                            <span class="block text-xl font-medium text-blue-500">Contenu</span>
                            <div 
                                class="mt-1 block w-full text-lg sm:text-sm bg-white text-gray-900"><?php echo htmlspecialchars($row['contenu']) ?></div>
                        </div>
                       
                       
                </div>

                <?php else : ?>
                    <p>Aucun article trouvé avec cet ID.</p>
                <?php endif; ?>
                </div>
                <div class="card-footer">
                    <a href="../form_disc.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des articles</a>
                </div>
                </div>
        </div>
    </section>

  
</body>
</html>

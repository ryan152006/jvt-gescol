<?php
require '../../../../Traitement/connexion.php';

$id = $_GET['id'];  
$request = $conn->prepare("DELETE FROM piece_jointe WHERE id='$id'");
$request->execute(); 
header("location:../form_disc.php");
?>
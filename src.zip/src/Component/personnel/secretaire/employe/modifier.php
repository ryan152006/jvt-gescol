<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["nom"], $_POST["prenom"], $_POST["telephone"], $_POST["email"], $_POST["sexe"], 
    $_POST["poste"], $_POST["matricule"])) {
        
        // Récupération des données du formulaire
        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $tel = $_POST["telephone"];
        $email = $_POST["email"];
        $poste = $_POST["poste"];
        $sexe = $_POST["sexe"];
        $matricule = $_POST["matricule"];
        
        // Si l'utilisateur a sélectionné "autre", on récupère la valeur personnalisée
        if ($poste === "autre" && !empty($_POST['poste_autre'])) {
            $poste = $_POST['poste_autre'];
        }

        // Préparation de la requête SQL
        $request = $conn->prepare("UPDATE employe SET nom = :nom, prenom = :prenom,
        telephone = :telephone, email = :email, sexe = :sexe, poste = :poste
        WHERE matricule = :matricule");

        // Liaison des paramètres
        $request->bindParam(":nom", $nom);
        $request->bindParam(":prenom", $prenom);
        $request->bindParam(":telephone", $tel);
        $request->bindParam(":email", $email);
        $request->bindParam(":sexe", $sexe);
        $request->bindParam(":poste", $poste);
        $request->bindParam(":matricule", $matricule);

        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../ employe.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}

$id = $_GET['matricule'] ?? null;
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM employe WHERE matricule = :matricule");
    $request->bindParam(':matricule', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Enregistrement</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Modifier Les Informations de votre employé
                </h1>
                <?php if ($row) : 
              
                    $selectedSexe = $row['sexe'];
                ?>
                <form id="registration-form" method="post" class="space-y-2 sm:space-y-4">
                    <!-- Informations Personnelles -->
                    <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="nom" class="block text-sm font-medium text-gray-900 dark:text-white ">Entrer le nom</label>
                    <input type="text" name="nom" id="nom" value="<?= htmlspecialchars($row['nom']) ?>" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div class="flex-1">
                    <label for="prenom" class="block text-sm font-medium text-gray-900 dark:text-white ">Entrer le prénom</label>
                    <input type="text" id="prenom" name="prenom" value="<?= htmlspecialchars($row['prenom']) ?>" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
            </div>
            <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="tel" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le téléphone</label>
                    <input type="tel" name="telephone" id="tel" value="<?= htmlspecialchars($row['telephone']) ?>" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div class="flex-1">
                    <label for="email" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer l'email</label>
                    <input type="email" name="email" id="email" value="<?= htmlspecialchars($row['email']) ?>" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
            </div>
            <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="matricule" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le matricule</label>
                    <input type="text" name="matricule" id="matricule" value="<?= htmlspecialchars($row['matricule']) ?>" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                    <div class="flex-1">
                            <label for="poste" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le poste</label>
                            <select name="poste" id="poste" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" onchange="handlePosteChange()" required>
                                <option value="" disabled>Selectionner votre poste</option>
                                <option value="secretaire" <?= ($row['poste'] === 'secretaire') ? 'selected' : '' ?>>Secrétaire</option>
                                <option value="caissiere" <?= ($row['poste'] === 'caissiere') ? 'selected' : '' ?>>Caissière</option>
                                <option value="surveillantgeneral" <?= ($row['poste'] === 'surveillantgeneral') ? 'selected' : '' ?>>Surveillant Général</option>
                                <option value="enseignant" <?= ($row['poste'] === 'enseignant') ? 'selected' : '' ?>>Enseignant</option>
                                <option value="prefet_des_etudes" <?= ($row['poste'] === 'prefet_des_etudes') ? 'selected' : '' ?>>Prefet des etudes</option>
                                <option value="autre" <?= ($row['poste'] === 'autre') ? 'selected' : '' ?>>Autre</option>
                            </select>
                            <input type="text" name="poste_autre" id="poste_autre" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 mt-2 <?= ($row['poste'] === 'autre') ? '' : 'hidden' ?>" placeholder="Précisez le poste" value="<?= $poste_autre_value ?>">
                        </div>
                    </div>
                    <div class="flex flex-col gap-4 sm:flex-row">
                        <div class="flex-1">
                            <label for="sexe" class="block text-sm font-medium text-gray-900 dark:text-white">Sélectionner le sexe</label>
                            <select name="sexe" id="sexe" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="masculin" <?= ($row['sexe'] === 'masculin') ? 'selected' : '' ?>>Masculin</option>
                                <option value="feminin" <?= ($row['sexe'] === 'feminin') ? 'selected' : '' ?>>Féminin</option>
                            </select>
                        </div>
                    </div>
          
                    <!-- Informations Secondaires -->
                   
                    <!-- Boutons -->
                      <div class="flex justify-between items-center mt-6">
                        <button type="submit" class="px-6 py-2 bg-blue-500 text-white rounded shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">Mettre à jour</button>
                        <a href="../ employe.php" class="px-6 py-2 bg-gray-300 text-gray-800 rounded shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500">Retour</a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2"> modification des champs entrainera un changement des données de l'employe</small>
                </form>
                <?php else : ?>
                    <p>Aucun employé trouvé avec ce matricule.
                    <a href="../ employe.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>


</body>
</html>

<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search)) {
    $query = "SELECT * FROM employe WHERE nom LIKE :search OR prenom LIKE :search ORDER BY nom asc";
    $stmt = $conn->prepare($query);
    $stmt->execute(['search' => '%' . $search . '%']);
    $employe = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $employe = [];
}

?>

<div class="mx-auto w-auto overflow-x-hidden justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-hidden justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 space-x-2">Résultats de la Recherche</span>
            <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-1 py-4">Matricule</th>
                        <th scope="col" class="px-1 py-3">Nom</th>
                        <th scope="col" class="px-1 py-3">Prenom</th>
                        <th scope="col" class="px-1 py-3">Email</th>
    
                        <th scope="col" class="px-1 py-3">Téléphone</th>
                        <th scope="col" class="px-1 py-3">Sexe</th>
                        <th scope="col" class="px-1 py-3">Poste</th>
                        <th scope="col" class="px-1 py-3">
                            <span class="">Actions</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="overflow-y-auto overflow-x-auto">
                <?php if (empty($employe)): ?>
                        <tr><td colspan="8" class="px-8 py-2 text-center">Aucun résultat trouvé</td></tr>
                    <?php else: ?>
                    <?php foreach ($employe as $row): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-1 text-center text-gray-300 max-w-[16rem] truncate py-2 ">
                                <?php echo htmlspecialchars($row['matricule']); ?>
                            </td>
                            <td class="px-1 text-center text-gray-300 max-w-[16rem] truncate py-2">
                                <?php echo htmlspecialchars($row['nom']); ?>
                            </td>
                            <td class="px-1 text-center text-gray-300 max-w-[16rem] truncate py-2">
                                <?php echo htmlspecialchars($row['prenom']); ?>
                            </td>
                            <td class="px-1 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['email']); ?>
                            </td>
                            <td class="px-1 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['telephone']); ?>
                            </td>
                            <td class="px-1 text-left text-gray-300 py-2 max-w-[18rem] truncate">
                                <?php echo htmlspecialchars($row['sexe']); ?>
                            </td>
                            
                            <td class="px-1 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['poste']); ?>
                            </td>
                            <td class="px-1 text-center py-2 flex items-center justify-end space-x-3">
                                <a href="modifier.php?id=<?php echo urlencode($row['matricule']); ?>" class="text-green-500 text-center font-medium">
                                    <button>Modifier</button>
                                </a>
                                <a href="consulter.php?id=<?php echo urlencode($row['matricule']); ?>" class="text-blue-500 text-center font-medium">
                                    <button>Consulter</button>
                                </a>
                                <a href="../../../../Traitement/secretaire/employe/delete.php?id=<?php echo urlencode($row['matricule']); ?>" class="text-red-400 text-center font-medium">
                                    <button>Supprimer</button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
                
        </div>
    </div>
</div>

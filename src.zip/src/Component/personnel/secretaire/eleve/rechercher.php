<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT e.code_elev, e.id, e.nom_elev, e.nationalite, e.prenom_elev, e.sexe_elev, e.telephone, c.nom_class AS classe
          FROM eleve e
          JOIN classe c ON e.id_class = c.id_class
          WHERE e.nom_elev LIKE :search OR e.prenom_elev LIKE :search ORDER BY nom_elev asc";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$eleves = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="mx-auto w-auto overflow-x-hidden justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-hidden justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 space-x-2">Résultats de la Recherche</span>
            <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-2 py-4">Matricule</th>
                        <th scope="col" class="px-2 py-3">Nom</th>
                        <th scope="col" class="px-2 py-3">Prenom</th>
                        <th scope="col" class="px-2 py-3">Classe</th>
                        <th scope="col" class="px-2 py-3">Sexe</th>
                        <th scope="col" class="px-2 py-3">Téléphone</th>
                        <th scope="col" class="px-2 py-3">Nationalité</th>
                        <th scope="col" class="px-2 py-3">
                            <span class="">Actions</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="overflow-y-auto overflow-x-auto">
                    <?php if (empty($eleves)): ?>
                        <tr><td colspan="8" class="px-2 py-2 text-center">Aucun résultat trouvé</td></tr>
                    <?php else: ?>
                        <?php foreach ($eleves as $eleve): $eleve['code_elev']='jeanefok23';?>
                            <tr class="border-b dark:border-gray-700">
                                <th scope="row" class="px-2 text-center py-2 font-normal text-gray-900 whitespace-nowrap dark:text-white">
                                <?php echo htmlspecialchars($eleve['code_elev']); ?><?php echo htmlspecialchars($eleve['id']); ?>
                                </th>
                                <td class="px-2 text-center max-w-[16rem] truncate py-2">
                                    <?php echo htmlspecialchars($eleve['nom_elev']); ?>
                                </td>
                                <td class="px-2 text-center max-w-[16rem] truncate py-2">
                                    <?php echo htmlspecialchars($eleve['prenom_elev']); ?>
                                </td>
                                <td class="px-82text-center max-w-[16rem] truncate py-2">
                                    <?php echo htmlspecialchars($eleve['classe']); ?>
                                </td>
                                <td class="px-2 text-left py-2 max-w-[18rem] truncate">
                                    <?php echo htmlspecialchars($eleve['sexe_elev']); ?>
                                </td>
                                <td class="px-2 text-center py-2">
                                    <?php echo htmlspecialchars($eleve['telephone']); ?>
                                </td>
                                <td class="px-2 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($eleve['nationalite']); ?>
                            </td>
                                <td class="px-2 text-center py-2 flex items-center justify-end space-x-3">
                                    <a href="eleve/modifier.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-green-500 text-center font-medium">
                                        <button>Modifier</button>
                                    </a>
                                    <a href="eleve/consulter.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-blue-500 text-center font-medium">
                                        <button>Consulter</button>
                                    </a>
                                    <a href="../../../../Traitement/secretaire/delete.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-red-400 text-center font-medium">
                                        <button>Supprimer</button>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

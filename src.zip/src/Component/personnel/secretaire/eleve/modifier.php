<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["nom"], $_POST["prenom"], $_POST["telephone"], $_POST["date"], $_POST["sexe"], 
     $_POST["classe"], $_POST["categorie"])) {
        
        // Récupération des données du formulaire
        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $tel = $_POST["telephone"];
        $date = $_POST["date"];
        $lieu = $_POST["lieu"];
        $sexe = $_POST["sexe"];
       
        $classeNom = $_POST["classe"]; // Nom de la classe, pas l'ID
        $categorie = $_POST["categorie"];
        $nationalite = $_POST["nationalite"];
        $religion = $_POST["religion"];
        $ethnie = $_POST["ethnie"] ;
        $baptise = $_POST["baptise"];
        $communie = $_POST["communie"];
        $confirme = $_POST["confirme"];
        $nom_mere = $_POST["mere"];
        $tel_mere = $_POST["telmere"];
        $nom_pere = $_POST["pere"];
        $tel_pere = $_POST["telpere"];
        $nom_tuteur = $_POST["tuteur"];
        $tel_tuteur = $_POST["teltuteur"];
        $lieu_residence = $_POST["lieu_res"];
        $lieu_residence_parents = $_POST["lieu_res_par"];
        $dernier_etab = $_POST["dernier_etab"] ?? null;
        $antecedent_sante = $_POST["antecedent"] ?? null;
        $id = $_GET['id']; // Assurez-vous que l'ID est bien récupéré

        try {
            // Vérifiez que le nom de la classe existe et obtenez l'id_class
            $stmt = $conn->prepare("SELECT id_class FROM classe WHERE nom_class = :classeNom");
            $stmt->bindParam(':classeNom', $classeNom);
            $stmt->execute();
            $classeId = $stmt->fetchColumn();

            if (!$classeId) {
                throw new Exception("Classe non existante.");
            }

            // Préparation de la requête SQL pour la mise à jour
            $query = "UPDATE eleve SET 
                
                nom_elev = :nom, 
                prenom_elev = :prenom,
                telephone = :telephone, 
                date_naiss = :date, 
                lieu_naiss = :lieu, 
               
                id_class = :id_class, 
                classe = :classe,
                sexe_elev = :sexe, 
                categorie = :categorie,
                nationalite = :nationalite,
                religion = :religion,
                ethnie = :ethnie,
                baptise = :baptise,
                communie = :communie,
                confirme = :confirme,
                nom_mere = :nom_mere,
                tel_mere = :tel_mere,
                nom_pere = :nom_pere,
                tel_pere = :tel_pere,
                nom_tuteur = :nom_tuteur,
                tel_tuteur = :tel_tuteur,
                lieu_residence = :lieu_residence,
                lieu_residence_parent = :lieu_residence_parents,
                dernier_etab_freq = :dernier_etab,
                antecedent_sante = :antecedent_sante
                WHERE id = :id";

            $stmt = $conn->prepare($query);

            // Liaison des paramètres
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prenom', $prenom);
            $stmt->bindParam(':telephone', $tel);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':lieu', $lieu);
           
            $stmt->bindParam(':id_class', $classeId);
            $stmt->bindParam(':classe', $classeNom);
            $stmt->bindParam(':sexe', $sexe);
            $stmt->bindParam(':categorie', $categorie);
            $stmt->bindParam(':nationalite', $nationalite);
            $stmt->bindParam(':religion', $religion);
            $stmt->bindParam(':ethnie', $ethnie);
            $stmt->bindParam(':baptise', $baptise);
            $stmt->bindParam(':communie', $communie);
            $stmt->bindParam(':confirme', $confirme);
            $stmt->bindParam(':nom_mere', $nom_mere);
            $stmt->bindParam(':tel_mere', $tel_mere);
            $stmt->bindParam(':nom_pere', $nom_pere);
            $stmt->bindParam(':tel_pere', $tel_pere);
            $stmt->bindParam(':nom_tuteur', $nom_tuteur);
            $stmt->bindParam(':tel_tuteur', $tel_tuteur);
            $stmt->bindParam(':lieu_residence', $lieu_residence);
            $stmt->bindParam(':lieu_residence_parents', $lieu_residence_parents);
            $stmt->bindParam(':dernier_etab', $dernier_etab);
            $stmt->bindParam(':antecedent_sante', $antecedent_sante);
            $stmt->bindParam(':id', $id);

            // Exécution de la requête
            $stmt->execute();

            // Redirection après succès
            header("Location: ../eleve.php");
            exit();
        } catch (Exception $e) {
            // Affichage du message d'erreur
            echo "Erreur : " . $e->getMessage();
        }
    } else {    
        // Gestion du cas où la requête n'est pas envoyée en POST
        echo "Méthode de requête invalide.";
    }
}

$id = $_GET['id'];
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM eleve WHERE id = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Modification</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center  dark:text-blue-400">
                    Modifier Les Informations de Élève
                </h1>
                <?php if ($row) : 
                    // Formater la date de naissance pour le champ date
                    $formattedDate = date('Y-m-d', strtotime($row['date_naiss']));
                    // Déterminer la sélection du sexe
                    $selectedSexe = $row['sexe_elev'];
                ?>
                <form id="registration-form" method="post" >
                    <!-- Informations Personnelles -->
                    <fieldset id="personal-info" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Personnelles</legend>
                        <!-- Nom -->
                        <div class="flex flex-col">
                            <label for="nom" class="block text-sm font-normal text-gray-900 dark:text-white">Nom</label>
                            <input type="text" name="nom" id="nom" placeholder="Ex: Dupont" title="Entrez le nom de l'élève" value="<?= htmlspecialchars($row['nom_elev']) ?>" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Prénom -->
                        <div class="flex flex-col">
                            <label for="prenom" class="block text-sm font-normal text-gray-900 dark:text-white">Prénom</label>
                            <input type="text" name="prenom" id="prenom" placeholder="Ex: Marie" value="<?= htmlspecialchars($row['prenom_elev']) ?>" title="Entrez le prénom de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Date de Naissance -->
                        <div class="flex flex-col">
                            <label for="date" class="block text-sm font-normal text-gray-900 dark:text-white">Date de Naissance</label>
                            <input type="date" name="date" id="date" value="<?= $formattedDate ?>" title="Sélectionnez la date de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Lieu de Naissance -->
                        <div class="flex flex-col">
                            <label for="lieu" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Naissance</label>
                            <input type="text" name="lieu" id="lieu" placeholder="Ex: Paris" value="<?= htmlspecialchars($row['lieu_naiss']) ?>" title="Entrez le lieu de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Sexe -->
                        <div class="flex flex-col">
                            <label for="sexe" class="block text-sm font-normal text-gray-900 dark:text-white">Sexe</label>
                            <select name="sexe" id="sexe" title="Sélectionnez le sexe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" disabled>Selectionner le sexe</option>
                                <option value="masculin" <?= ($selectedSexe == 'masculin') ? 'selected' : '' ?>>Masculin</option>
                                <option value="feminin" <?= ($selectedSexe == 'feminin') ? 'selected' : '' ?>>Féminin</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="nationalite" class="block text-sm font-normal text-gray-900 dark:text-white">Nationalité</label>
                            <input type="text" value="<?= htmlspecialchars($row['nationalite']) ?>" name="nationalite" id="nationalite" placeholder="EX:Cameroun" title="Entrer la nationalité de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="telephone" class="block text-sm font-normal text-gray-900 dark:text-white">Téléphone</label>
                            <input type="tel" name="telephone" id="telephone" value="<?= htmlspecialchars($row['telephone']) ?>" placeholder="Ex: 6 23 45 67 89" title="Entrez le numéro de téléphone de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="religion" class="block text-sm font-normal text-gray-900 dark:text-white">Religion</label>
                            <select name="religion" id="religion" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled class="text-gray-500">Selectionner la religion de l'eleve</option>
                                <option value="catholique" <?= ($row['religion'] == 'catholique') ? 'selected' : '' ?>>Catholique</option>
                                <option value="protestant" <?= ($row['religion'] == 'protestant') ? 'selected' : '' ?>>Protestant</option>
                                <option value="musulman" <?= ($row['religion'] == 'musulman') ? 'selected' : '' ?>>Musulman</option>
                                <option value="orthodoxe" <?= ($row['religion'] == 'orthodoxe') ? 'selected' : '' ?>>Orthodoxe</option>
                                <option value="avantiste" <?= ($row['religion'] == 'avantiste') ? 'selected' : '' ?>>Advantiste</option>
                                <option value="temoin_Jehovah" <?= ($row['religion'] == 'temoin_Jehovah') ? 'selected' : '' ?>>Temoin de Jehovah</option>
                                <option value="pentecotiste" <?= ($row['religion'] == 'pentecotiste') ? 'selected' : '' ?>>Pentecotiste</option>
                                <option value="autre" <?= ($row['religion'] == 'autre') ? 'selected' : '' ?>>Autre</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="ethnie" class="block text-sm font-normal text-gray-900 dark:text-white">Ethnie</label>
                            <input type="text" value="<?= htmlspecialchars($row['ethnie']) ?>" name="ethnie" id="ethnie" placeholder="Ex: saisissez la ethnie" title="Entrez la ethnie de l'eleve" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="baptise" class="block text-sm font-normal text-gray-900 dark:text-white">Baptisé</label>
                       
                            <select name="baptise" id="baptise" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="1" <?= ($row['baptise'] == '1') ? 'selected' : '' ?>>Oui</option>
                                <option value="0" <?= ($row['baptise'] == '0') ? 'selected' : '' ?>>Non</option>
                            </select>
                            </div>    
                        <div class="flex flex-col">
                            <label for="communie" class="block text-sm font-normal text-gray-900 dark:text-white">Communié</label>
                            <select name="communie" id="communie" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            <option value="1" <?= ($row['communie'] == '1') ? 'selected' : '' ?>>Oui</option>
                            <option value="0" <?= ($row['communie'] == '0') ? 'selected' : '' ?>>Non</option>
                            </select>
                            </div>
                        <div class="flex flex-col">
                            <label for="confirme" class="block text-sm font-normal text-gray-900 dark:text-white">Confirmé</label>
                            <select name="confirme" id="confirme" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            <option value="1" <?= ($row['confirme'] == '1') ? 'selected' : '' ?>>Oui</option>
                            <option value="0" <?= ($row['confirme'] == '0') ? 'selected' : '' ?>>Non</option>
                            </select>
                            </div>
                    </fieldset>

                    <!-- Informations Secondaires -->
                    <fieldset id="secondary-info" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Secondaires</legend>
                        <!-- Téléphone -->
                        <!-- Classe -->
                        <div class="flex flex-col">
                            <label for="classe" class="block text-sm font-normal text-gray-900 dark:text-white">Classe</label>
                            <select name="classe" id="classe" title="Sélectionnez la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" disabled>Selectionner la classe</option>
                                <?php
                                
                                $query = "SELECT id_class, nom_class FROM classe";
                                $stmt = $conn->prepare($query);
                                $stmt->execute();
                                $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                // Générer les options du menu déroulant
                                foreach ($classes as $classe) {
                                    $selectedClass = ($classe['nom_class'] == $row['classe']) ? 'selected' : '';
                                    echo "<option value=\"{$classe['nom_class']}\" $selectedClass>{$classe['nom_class']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <!-- Catégorie -->
                        <div class="flex flex-col">
                            <label for="categorie" class="block text-sm font-normal text-gray-900 dark:text-white">Catégorie de l'élève</label>
                            <select name="categorie" id="categorie" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="nouveau" <?= ($row['categorie'] == 'nouveau') ? 'selected' : '' ?>>Nouveau</option>
                                <option value="ancien" <?= ($row['categorie'] == 'ancien') ? 'selected' : '' ?>>Ancien</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="mere" class="block text-sm font-normal text-gray-900 dark:text-white">Nom de la Mère</label>
                            <input type="text" value="<?= htmlspecialchars($row['nom_mere']) ?>" name="mere" id="mere" placeholder="Ex: Eveline" title="Entrez le nom de la Mère" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="telmere" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone de la Mère</label>
                            <input type="tel" value="<?= htmlspecialchars($row['tel_mere']) ?>" name="telmere" id="telmere" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone de la Mère" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="pere" class="block text-sm font-normal text-gray-900 dark:text-white">Nom du Père</label>
                            <input type="text" name="pere" value="<?= htmlspecialchars($row['nom_pere']) ?>" id="pere" placeholder="Ex: Pierre" title="Entrez le nom du Père" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="telpere" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone du Père</label>
                            <input type="tel" name="telpere" value="<?= htmlspecialchars($row['tel_pere']) ?>" id="telpere" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone du Père" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="tuteur" class="block text-sm font-normal text-gray-900 dark:text-white">Nom du Tuteur</label>
                            <input type="text" name="tuteur" id="tuteur" value="<?= htmlspecialchars($row['nom_tuteur']) ?>" placeholder="Ex: Martin" title="Entrez le nom du tuteur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="teltuteur" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone du Tuteur</label>
                            <input type="tel" value="<?= htmlspecialchars($row['tel_tuteur']) ?>" name="teltuteur" id="teltuteur" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone du tuteur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>  
                        <!-- Classe -->
                       
                        <div class="flex flex-col">
                            <label for="lieu_res" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Residence de l'éleve</label>
                            <input type="text" name="lieu_res" id="lieu_res" value="<?= htmlspecialchars($row['lieu_residence']) ?>" placeholder="Ex: Efok" title="Entrez le lieu de residence de l'eleve" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="lieu_res_par" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Residence des parents</label>
                            <input type="text" value="<?= htmlspecialchars($row['lieu_residence_parent']) ?>" name="lieu_res_par" id="lieu_res_par" placeholder="Ex: Efok" title="Entrez le lieu de residence des parents" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="dernier_etab" class="block text-sm font-normal text-gray-900 dark:text-white">Dernier Etablissement Frequenté</label>
                            <input type="text" name="dernier_etab" value="<?= htmlspecialchars($row['dernier_etab_freq']) ?>" id="dernier_etab" placeholder="Ex: College ..." title="Entrez le Dernier Etablissement Frequenté" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                        <label for="antecedent" class="block text-sm font-normal text-gray-900 dark:text-white">Antécédant de santé</label>
                        <textarea name="antecedent" value="<?= htmlspecialchars($row['antecedent_sante']) ?>" id="antecedent" row="4" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                        </div>
                    </fieldset>
                    <!-- Boutons -->
                    <div class="flex justify-between items-center mt-1">
                        <button type="button" id="next-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-normal rounded text-xl px-8 py-1 text-center dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-700 disabled">
                            Suivant
                        </button>
                        <button type="button" id="previous-button" class="hidden text-white bg-transparent hover:bg-gray-600  border-2 border-gray-400 hover:bg-gray-600  focus:outline-none  font-normal rounded text-xl px-8 py-1 text-center dark:focus:ring-blue-700">
                            Précédent
                        </button>
                        <button type="submit" id="submit-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-1 text-center   dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../eleve.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-1 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2">Veuillez remplir tous les champs pour enregistrer un nouvel élève!</small>
                </form>
                <?php else : ?>
                    <p>Aucun élève trouvé avec cet ID.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <script>
        const personalInfoFieldset = document.getElementById('personal-info');
        const secondaryInfoFieldset = document.getElementById('secondary-info');
        const nextButton = document.getElementById('next-button');
        const previousButton = document.getElementById('previous-button');
        const submitButton = document.getElementById('submit-button');

        function validatePersonalInfo() {
            // Sélectionner tous les champs requis dans le fieldset d'informations personnelles
            const requiredFields = personalInfoFieldset.querySelectorAll('input[required], select[required]');
            // Vérifier si tous les champs sont remplis
            return Array.from(requiredFields).every(field => field.value.trim() !== '');
        }

        function toggleNextButton() {
            if (validatePersonalInfo()) {
                nextButton.classList.remove('disabled');
                nextButton.disabled = false;
            } else {
                nextButton.classList.add('disabled');
                nextButton.disabled = true;
            }
        }

        // Ajouter des écouteurs d'événements pour surveiller les changements dans les champs
        personalInfoFieldset.addEventListener('input', toggleNextButton);

        nextButton.addEventListener('click', () => {
            if (validatePersonalInfo()) {
                personalInfoFieldset.classList.add('hidden');
                secondaryInfoFieldset.classList.remove('hidden');
                nextButton.classList.add('hidden');
                previousButton.classList.remove('hidden');
                submitButton.classList.remove('hidden');
            }
        });

        previousButton.addEventListener('click', () => {
            personalInfoFieldset.classList.remove('hidden');
            secondaryInfoFieldset.classList.add('hidden');
            nextButton.classList.remove('hidden');
            previousButton.classList.add('hidden');
            submitButton.classList.add('hidden');
        });

        // Initialiser le bouton "Suivant" lors du chargement de la page
        toggleNextButton();
        document.addEventListener("DOMContentLoaded", function() {
        const baptiseSelect = document.getElementById("baptise");
        const communieSelect = document.getElementById("communie");
        const confirmeSelect = document.getElementById("confirme");

        function toggleCommunieAndConfirme() {
            if (baptiseSelect.value == "0") {
                communieSelect.disabled = true;
                confirmeSelect.disabled = true;
                communieSelect.classList.add("disabled");
                confirmeSelect.classList.add("disabled");
            } else {
                communieSelect.disabled = false;
                communieSelect.classList.remove("disabled");
                toggleConfirme();  // Update confirmed state based on communie
            }
        }

        function toggleConfirme() {
            if (communieSelect.value == "0") {
                confirmeSelect.disabled = true;
                confirmeSelect.classList.add("disabled");
            } else {
                confirmeSelect.disabled = false;
                confirmeSelect.classList.remove("disabled");
            }
        }

        // Initial check when the page loads
        toggleCommunieAndConfirme();

        // Add event listeners
        baptiseSelect.addEventListener("change", toggleCommunieAndConfirme);
        communieSelect.addEventListener("change", toggleConfirme);
    });
    </script>

</body>
</html>

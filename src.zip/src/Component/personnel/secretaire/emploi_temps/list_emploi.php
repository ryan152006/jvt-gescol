<?php
// Inclusion du fichier de connexion
require_once '../../../../Traitement/connexion.php';

// Récupération des enseignants avec leurs emplois duTtemps
$enseignants = $conn->query("
    SELECT e.nom, e.prenom, e.matricule, em.* 
    FROM employe e 
    JOIN emploi_temps em ON e.matricule = em.id_employe 
    WHERE e.poste = 'enseignant' ORDER BY em.heure_debut
")->fetchAll(PDO::FETCH_ASSOC);

// Organisation des données par enseignant, jour, et heure
$emplois_par_professeur = [];
foreach ($enseignants as $data) {
    $id_enseignant = $data['id_employe'];
    $jour = strtolower($data['jour']);
    $heure_debut = $data['heure_debut'];
    $heure_fin = $data['heure_fin'];

    if (!isset($emplois_par_professeur[$id_enseignant])) {
        $emplois_par_professeur[$id_enseignant] = [
            'nom' => $data['nom'],
            'prenom' => $data['prenom'],
            'emplois' => []
        ];
    }
    if (!isset($emplois_par_professeur[$id_enseignant]['emplois'][$heure_debut])) {
        $emplois_par_professeur[$id_enseignant]['emplois'][$heure_debut] = [
            'heure_fin' => $heure_fin,
            'jours' => []
        ];
    }
    
    $emplois_par_professeur[$id_enseignant]['emplois'][$heure_debut]['jours'][$jour] = $data;
}
$jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emploi du Temps des professeurs</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-4 sm:p-6">
    <!-- Bouton de retour -->
    <div class="mb-6">
        <a href="../emploi_temps.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
            <svg class="w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            Retour
        </a>
    </div>

    <h1 class="text-3xl font-bold text-center text-blue-600 mb-8">Emploi du Temps des Professeurs</h1>
    <div class="container mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($emplois_par_professeur as $enseignant): ?>
            <div class="bg-white shadow-lg rounded-lg p-6 mb-6 transition-transform hover:scale-105">
                <h2 class="text-xl font-semibold text-blue-500 mb-4 text-center">
                    <?= htmlspecialchars($enseignant['nom']) ?> <?= htmlspecialchars($enseignant['prenom']) ?>
                </h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white border border-gray-300">
                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="py-2 px-4 border-b border-gray-300 text-left">Heure / Jour</th>
                                <?php foreach ($jours as $jour): ?>
                                    <th class="py-2 px-4 border-b border-gray-300 text-center"><?= $jour ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody class="text-gray-700">
                            <?php foreach ($enseignant['emplois'] as $heure_debut => $data): ?>
                                <tr>
                                    <td class="py-2 px-4 border-b border-gray-300 text-left">
                                        <span class="block"><?= htmlspecialchars($heure_debut) ?></span>
                                        <span class="block"><?= htmlspecialchars($data['heure_fin']) ?></span>
                                    </td>
                                    <?php foreach ($jours as $jour): ?>
                                        <td class="py-2 px-4 border-b border-gray-300 text-center">
                                            <?php if (isset($data['jours'][strtolower($jour)])): ?>
                                                <?php $emploi = $data['jours'][strtolower($jour)]; 
                                                $class = $conn->prepare("SELECT * FROM classe WHERE id_class = :id_class");
                                                $class->bindParam(':id_class', $emploi['id_class']);
                                                $class->execute();
                                                $class_info = $class->fetch(PDO::FETCH_ASSOC);
                                                ?>
                                                <span class="block font-semibold text-gray-800"><?= htmlspecialchars($emploi['programme']) ?></span>
                                                <span class="block text-sm text-gray-600"><?= htmlspecialchars($class_info['nom_class']) ?></span>
                                            <?php else: ?>
                                                <span class="block text-gray-400">R.A.S</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>

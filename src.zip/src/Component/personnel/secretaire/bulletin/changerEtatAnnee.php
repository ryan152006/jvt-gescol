<?php
// Inclure la connexion à la base de données
require_once('../../../../Traitement/connexion.php');

// Vérifier si les données ont été envoyées via la méthode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lire les données JSON envoyées
    $input = json_decode(file_get_contents('php://input'), true);

    // Vérifier que les données nécessaires sont présentes
    if (isset($input['id']) && isset($input['etat'])) {
        $id_annee = $input['id'];
        $etat = $input['etat'];

        try {
            // Début de la transaction
            $conn->beginTransaction();

            // Désactiver toutes les autres années
            $query = "UPDATE annee_scolaire SET etat_P = 0";
            $stmt = $conn->prepare($query);
            $stmt->execute();

            // Activer l'année sélectionnée
            $query = "UPDATE annee_scolaire SET etat_P = :etat WHERE id_annee = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':etat', $etat, PDO::PARAM_INT);
            $stmt->bindParam(':id', $id_annee, PDO::PARAM_INT);
            $stmt->execute();

            // Valider la transaction
            $conn->commit();

            // Retourner une réponse JSON avec l'état activé
            echo json_encode(['success' => true, 'etat' => $etat]);
        } catch (PDOException $e) {
            // En cas d'erreur, annuler la transaction
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Erreur lors de la mise à jour : ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Données invalides.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
}

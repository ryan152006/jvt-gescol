<?php
// Démarrer la session avant d'accéder à $_SESSION
session_start();

require_once('../../../../Traitement/connexion.php');

// Récupérer les années scolaires depuis la base de données
$query = "SELECT * FROM annee_scolaire ORDER BY id_annee DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$annees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Gestion des messages
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['nom_annee'])) {
        try {
            // Ajouter une nouvelle année scolaire
            $query = "INSERT INTO annee_scolaire (nom_annee, etat_P) VALUES (:nom_annee, 0)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nom_annee', $_POST['nom_annee'], PDO::PARAM_STR);
            $stmt->execute();
            $message = 'Nouvelle année scolaire ajoutée avec succès.';
            header("Location: annee_scolaire.php");
            exit();
        } catch (PDOException $e) {
            $message = 'Erreur lors de l\'ajout : ' . $e->getMessage();
        }
    } else {
        $message = 'Veuillez entrer le nom de l\'année scolaire.';
    }
}

$query = "SELECT * FROM annee_scolaire WHERE etat_P = 1";
$stmt = $conn->prepare($query);
$stmt->execute();
$annee = $stmt->fetch(PDO::FETCH_ASSOC);

if ($annee) {
    $_SESSION['id_annee'] = $annee['id_annee'];
    $_SESSION['nom_annee'] = $annee['nom_annee'];
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Années Scolaires</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
    <div class="flex justify-start mb-4">
            <a href="../bulletin.php">
            <button class="bg-blue-600 text-white rounded-full py-2 px-4 hover:bg-blue-700 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-5 h-5 mr-2">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Retour (Année : <?= isset($_SESSION['nom_annee']) ? $_SESSION['nom_annee'] : 'Non définie' ?>)

             </button>
            </a>
        </div>
        <h1 class="text-2xl font-bold text-gray-700 mb-6">Gestion des Années Scolaires</h1>

        <!-- Message -->
        <?php if ($message): ?>
            <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">
                <?= htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Formulaire d'enregistrement -->
        <div class="bg-white p-6 rounded shadow-md mb-6">
            <h2 class="text-lg font-semibold mb-4">Ajouter une Année Scolaire</h2>
            <form method="POST" action="annee_scolaire.php">
                <div class="mb-4">
                    <label for="nom_annee" class="block text-sm font-medium text-gray-700">Nom de l'année scolaire</label>
                    <input type="text" id="nom_annee" name="nom_annee" 
                           class="mt-1 p-2 border rounded w-full" placeholder="Ex : 2024/2025" required>
                </div>
                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                    Enregistrer
                </button>
            </form>
        </div>

        <!-- Liste des années scolaires -->
        <div class="bg-white p-6 rounded shadow-md">
            <h2 class="text-lg font-semibold mb-4">Années Scolaires Enregistrées</h2>
            <ul class="divide-y divide-gray-200">
                <?php foreach ($annees as $annee): ?>
                    <li class="flex items-center justify-between py-4">
                        <span><?= htmlspecialchars($annee['nom_annee']); ?></span>
                      
                        
                        <button 
                            class="px-4 py-2 text-white rounded 
                            <?= $annee['etat_P'] ? 'bg-green-500' : 'bg-gray-500 hover:bg-green-500' ?>" 
                            onclick="changerEtatAnnee(<?= $annee['id_annee']; ?>)">
                            <?= $annee['etat_P'] ? 'Activé' : 'Activer'; ?>
                        </button>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <script>
        // Fonction pour activer une année scolaire
        function changerEtatAnnee(id_annee) {
            fetch('changerEtatAnnee.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id_annee, etat: 1 })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Année scolaire activée avec succès.');
                    window.location.reload();
                } else {
                    alert('Erreur : ' + data.message);
                }
            })
            .catch(error => console.error('Erreur:', error));
        }
    </script>
</body>
</html>

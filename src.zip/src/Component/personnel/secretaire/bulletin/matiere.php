<?php
// Démarrer la session pour manipuler les variables de session
require "../../../../Traitement/connexion.php";
require_once 'Models/evaluation.php';
require_once 'Models/trimestre.php';
$trimestre = new Trimestre();
$evaluation = new Evaluation();


session_start(); // Démarrez la session

// Vérifiez si 'id_annee' existe dans la session avant de l'utiliser
if (isset($_SESSION['id_annee'])) {
    $id_annee = $_SESSION['id_annee'];
} else {
    // Gérer le cas où 'id_annee' n'est pas défini
    echo "L'année scolaire n'est pas définie dans la session.";
}

$id_class = $_GET['id_class'];

// Lire les trimestres et évaluations depuis la base de données
$trimestres = $trimestre->read();
$evaluations = $evaluation->read();

// Traitement du formulaire d'ajout d'évaluation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type_evaluation = $_POST['type_evaluation'];
    $dateDebut_eval = $_POST['dateDebut_eval'];
    $dateFin_eval = $_POST['dateFin_eval'];
    $description = $_POST['description'];
    $etat_evaluation = $_POST['etat_evaluation'];
    $id_tri = $_POST['id_tri'];
    $id_annee = $_SESSION['id_annee']; // Récupérer l'ID de l'année scolaire depuis la session
    $id_class = $_GET['id_class'];
    // Ajouter l'évaluation
    if ($evaluation->create($type_evaluation, $dateDebut_eval, $dateFin_eval, $description, $etat_evaluation, $id_tri, $id_annee)) {
        // Redirection pour rafraîchir la page
        header("Location: " . $_SERVER['PHP_SELF'] . "?id_class=" . urlencode($id_class));
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Enregistrer Note</title>
    <style>
        body {
            background-color: #f4f7fa;
            font-family: 'Arial', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-100">

    <div class="container mx-auto mt-8 px-4">
        <!-- Bouton Retour -->
        <div class="flex justify-start mb-4">
            <a href="../bulletin.php">
                <button class="bg-blue-600 text-white rounded-full py-2 px-4 hover:bg-blue-700 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-5 h-5 mr-2">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Retour
                </button>
            </a>
        </div>

        <div class="bg-blue-500 text-white p-4 rounded-lg text-center mb-8">
            <h2 class="text-xl font-bold">Liste des Trimestres et Évaluations</h2>
        </div>

        <!-- Affichage des trimestres -->
        <div class="grid grid-cols-1 gap-6">
            <?php if (empty($trimestres)) : ?>
                <div class="text-center text-red-500 text-lg font-medium">
                    Aucun trimestre disponible.
                </div>
            <?php else : ?>
                <?php foreach ($trimestres as $trimestre) : ?>
                    <div class="bg-white border border-gray-300 rounded-lg shadow-md p-6">
                        <h5 class="text-lg font-bold text-gray-800">Trimestre : <?= htmlspecialchars($trimestre->type_tri) ?></h5>
                        <p class="text-gray-600"><strong>Dates : </strong> <?= htmlspecialchars($trimestre->dateDebut_trim) ?> - <?= htmlspecialchars($trimestre->dateFin_trim) ?></p>
                        <p class="text-gray-600"><strong>Description : </strong> <?= htmlspecialchars($trimestre->description) ?></p>
                        
                        <!-- Affichage des évaluations liées au trimestre -->
                        <?php
                            $evaluationsForTrimestre = array_filter($evaluations, function($eval) use ($trimestre) {
                                return $eval->id_tri == $trimestre->id_tri;
                            });

                            if (empty($evaluationsForTrimestre)) {
                                echo '<p class="text-gray-600">Aucune évaluation disponible pour ce trimestre.</p>';
                            } else {
                                foreach ($evaluationsForTrimestre as $evaluation) :
                        ?>
                            <div class="bg-gray-100 rounded-md p-4 mt-4 border border-gray-300">
                                <h5 class="text-lg font-bold text-blue-500">Évaluation : <?= htmlspecialchars($evaluation->type_evaluation) ?></h5>
                                <p class="text-gray-600"><strong>Période : </strong> <?= htmlspecialchars($evaluation->dateDebut_eval) ?> - <?= htmlspecialchars($evaluation->dateFin_eval) ?></p>
                                <p class="text-gray-600 mb-2"><strong>Description : </strong> <?= htmlspecialchars($evaluation->description) ?></p>
                                <a href="eleve.php?id_evaluation=<?= urlencode($evaluation->id_evaluation) ?>&id_tri=<?= urlencode($trimestre->id_tri) ?>&id_class=<?= urldecode($id_class)?>" 
                                    class="mt-4 bg-blue-500 text-white rounded-lg py-2 px-4 hover:bg-blue-600 mt-2">
                                    Choisir >> 
                                </a>
                            </div>
                        <?php endforeach; } ?>

                        <!-- Formulaire de création d'évaluation -->
                        <div class="mt-2">
                            <h3 class="text-xl font-bold text-gray-800">Créer une évaluation pour ce trimestre</h3>
                            <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" class="mt-4 bg-white p-6 rounded-lg shadow-md border">
                                <input type="hidden" name="id_tri" value="<?= htmlspecialchars($trimestre->id_tri) ?>">
                                <div class="mb-4">
                                    <label for="type_evaluation" class="block text-sm font-medium text-gray-700">Type d'évaluation</label>
                                    <input type="text" id="type_evaluation" name="type_evaluation" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="Type d'évaluation">
                                </div>
                                <div class="mb-4">
                                    <label for="dateDebut_eval" class="block text-sm font-medium text-gray-700">Date de début</label>
                                    <input type="date" id="dateDebut_eval" name="dateDebut_eval" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
                                </div>
                                <div class="mb-4">
                                    <label for="dateFin_eval" class="block text-sm font-medium text-gray-700">Date de fin</label>
                                    <input type="date" id="dateFin_eval" name="dateFin_eval" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
                                </div>
                                <div class="mb-4">
                                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea id="description" name="description" rows="4" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="Description de l'évaluation"></textarea>
                                </div>
                                <div class="mb-4">
                                    <label for="etat_evaluation" class="block text-sm font-medium text-gray-700">État de l'évaluation</label>
                                    <select id="etat_evaluation" name="etat_evaluation" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
                                        <option value="1">Activée</option>
                                        <option value="0">Désactivée</option>
                                    </select>
                                </div>
                                <div class="flex justify-end">
                                    <button type="submit" class="bg-blue-600 text-white py-2 px-6 rounded-lg hover:bg-blue-700">Créer l'évaluation</button>
                                </div>
                            </form>
                        </div>

                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>

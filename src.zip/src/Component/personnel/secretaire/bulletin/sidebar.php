<button data-drawer-target="separator-sidebar" data-drawer-toggle="separator-sidebar" aria-controls="separator-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
   <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>
<aside id="separator-sidebar" class=" relative top-0 left-0 z-40 w-full  h-screen overflow-hidden  transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-2 dark:bg-gray-900">
      <ul class="space-y-1 font-medium">
         <li >   
            <a href="dashboard.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               <svg class="w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 21">
                  <path d="M16.975 11H10V4.025a1 1 0 0 0-1.066-.998 8.5 8.5 0 1 0 9.039 9.039.999.999 0 0 0-1-1.066h.002Z"/>
                  <path d="M12.5 0c-.157 0-.311.01-.565.027A1 1 0 0 0 11 1.02V10h8.975a1 1 0 0 0 1-.935c.013-.188.028-.374.028-.565A8.51 8.51 0 0 0 12.5 0Z"/>
               </svg>
               <span class="ms-3 ">Dashboard</span>
            </a>
         </li>
         <li class="bg-gray-600  rounded-lg">
            <a href="bulletin.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 20">
                  <path d="M16 14V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v15a3 3 0 0 0 3 3h12a1 1 0 0 0 0-2h-1v-2a2 2 0 0 0 2-2ZM4 2h2v12H4V2Zm8 16H3a1 1 0 0 1 0-2h9v2Z"/>
               </svg>
               <span class="ms-3">Bulletin de Notes</span>
            </a>
         </li>
         <li >
            <a href="eleve.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               
            <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 18">
                  <path d="M14 2a3.963 3.963 0 0 0-1.4.267 6.439 6.439 0 0 1-1.331 6.638A4 4 0 1 0 14 2Zm1 9h-1.264A6.957 6.957 0 0 1 15 15v2a2.97 2.97 0 0 1-.184 1H19a1 1 0 0 0 1-1v-1a5.006 5.006 0 0 0-5-5ZM6.5 9a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9ZM8 10H5a5.006 5.006 0 0 0-5 5v2a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-2a5.006 5.006 0 0 0-5-5Z"/>
               </svg> 
               <span class="flex-1 ms-3 whitespace-nowrap">Eleves</span>
               <span class="inline-flex items-center justify-center px-2 ms-3 text-sm font-medium text-gray-800 bg-gray-100 rounded-full dark:bg-gray-700 dark:text-gray-300">Pro</span>
            </a>
         </li>
         <li >
            <a href="emploi_temps.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               
            <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--twemoji" preserveAspectRatio="xMidYMid meet"><circle fill="#99AAB5" cx="18" cy="18" r="18"></circle><circle fill="#E1E8ED" cx="18" cy="18" r="14"></circle><path fill="#66757F" d="M19 18a1 1 0 1 1-2 0V7a1 1 0 0 1 2 0v11z"></path><path fill="#66757F" d="M26.66 23a.998.998 0 0 1-1.365.367l-7.795-4.5a.999.999 0 1 1 1-1.732l7.795 4.5A.998.998 0 0 1 26.66 23z"></path></svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Emploi de temps</span>
              
            </a>
         </li>
         <li>
            <a href=" employe.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               
            <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 18">
                  <path d="M14 2a3.963 3.963 0 0 0-1.4.267 6.439 6.439 0 0 1-1.331 6.638A4 4 0 1 0 14 2Zm1 9h-1.264A6.957 6.957 0 0 1 15 15v2a2.97 2.97 0 0 1-.184 1H19a1 1 0 0 0 1-1v-1a5.006 5.006 0 0 0-5-5ZM6.5 9a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9ZM8 10H5a5.006 5.006 0 0 0-5 5v2a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-2a5.006 5.006 0 0 0-5-5Z"/>
               </svg> 
               <span class="flex-1 ms-3 whitespace-nowrap">Employés</span>
              
            </a>
         </li>
         <li class="">
           
         </li>
         <li >
            <a href="communique.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                  <path d="m17.418 3.623-.018-.008a6.713 6.713 0 0 0-2.4-.569V2h1a1 1 0 1 0 0-2h-2a1 1 0 0 0-1 1v2H9.89A6.977 6.977 0 0 1 12 8v5h-2V8A5 5 0 1 0 0 8v6a1 1 0 0 0 1 1h8v4a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-4h6a1 1 0 0 0 1-1V8a5 5 0 0 0-2.582-4.377ZM6 12H4a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2Z"/>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Communiqué</span>
               <span class="inline-flex items-center justify-center w-3 h-3 p-3 ms-3 text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300"> <?php
    require_once '../../../Traitement/connexion.php';

    // Préparer et exécuter la requête
    $sltm = $conn->prepare("SELECT COUNT(id) AS total FROM communique");
    $sltm->execute();

    // Récupérer le résultat
    $count = $sltm->fetch(PDO::FETCH_ASSOC);

    // Afficher le nombre total d'ID
    echo $count['total'];
?></span>
            </a>
         </li>
         <li >
            <a href="moncompte.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
           
          <svg class="flex-shrink-0 w-5 h-5 text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 128 128" id="Слой_1" version="1.1" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

          <style type="text/css">
            .st0{fill:#FFE0B2;}
            .st1{fill:#424242;}
            .st2{fill:#90CAF9;}
            .st3{fill:#FFFFFF;}
          </style>

          <g>

          <g>

          <circle class="st0" cx="64" cy="33" r="31"/>

          <path class="st1" d="M64,66c-18.2,0-33-14.8-33-33S45.8,0,64,0s33,14.8,33,33S82.2,66,64,66z M64,4C48,4,35,17,35,33s13,29,29,29    s29-13,29-29S80,4,64,4z"/>

          </g>

          <path class="st2" d="M126,126c0-34.2-27.8-62-62-62S2,91.8,2,126H126z"/>

          <path class="st1" d="M126,128H2c-1.1,0-2-0.9-2-2c0-25.9,15.5-48.3,37.7-58.3c8-3.6,17-5.7,26.3-5.7c6.6,0,13,1,19,2.9   c26,8.1,45,32.4,45,61.1C128,127.1,127.1,128,126,128z M4,124h60h60c-0.6-19.4-10.5-36.4-25.3-46.9c-6.1-4.4-13.1-7.6-20.6-9.4   C73.5,66.6,68.8,66,64,66c-5.9,0-11.6,0.9-17,2.4c-5,1.5-9.7,3.6-14,6.2C16.2,84.8,4.7,103.1,4,124z"/>

          </g>

          <path class="st3" d="M56,127"/>

          </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Mon compte</span>
            </a>
         </li>
        
         <li>
            <a href="presence.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 18">
                  <path d="M18 0H6a2 2 0 0 0-2 2h14v12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2Z"/>
                  <path d="M14 4H2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2ZM2 16v-6h12v6H2Z"/>
               </svg>
               <span class="ms-3">Presences</span>
            </a>
         </li>
         
         <li >
            <a href="classe.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
            <svg class="flex-shrink-0 w-5 h-5 text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 512 512" xml:space="preserve">
<path style="fill:#25B6D2;" d="M425.504,512H86.496c-18.048,0-32.832-14.768-32.832-32.832V32.832C53.664,14.768,68.448,0,86.496,0
	h339.008c18.048,0,32.832,14.768,32.832,32.832v446.352C458.336,497.232,443.552,512,425.504,512z"/>
<g>
	<path style="fill:#FFFFFF;" d="M305.536,345.488h-38.4l-15.264-39.712h-69.904l-14.416,39.712H130.08l68.112-174.848h37.328
		L305.536,345.488z M240.512,276.304l-24.08-64.864L192.8,276.304H240.512z"/>
	<path style="fill:#FFFFFF;" d="M320.752,259.424V223.44h-36.256v-24.832h36.256V162.64h24.176v35.968h36.336v24.832h-36.336v35.984
		H320.752z"/>
</g>
</svg>
               <span class="ms-3">Classes</span>
            </a>
         </li>
         <li>
            <a href="stat.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 20">
                  <path d="M16 14V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v15a3 3 0 0 0 3 3h12a1 1 0 0 0 0-2h-1v-2a2 2 0 0 0 2-2ZM4 2h2v12H4V2Zm8 16H3a1 1 0 0 1 0-2h9v2Z"/>
               </svg>
               <span class="ms-3">Statisques</span>
            </a>
         </li><li >
            <a href="form_disc.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
            <svg version="1.1" class="flex-shrink-0 w-5 h-5 text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 512 512" xml:space="preserve">
<rect x="68" y="4" style="fill:#FFFFFF;" width="376" height="504"/>
<path style="fill:#8AD5DD;" d="M440,8v496H72V8H440 M448,0H64v512h384V0L448,0z"/>
<g>
	<polygon style="fill:#999999;" points="292.048,431.344 256,468.632 219.952,431.344 231.208,420.208 256,445.848 280.792,420.208 
			"/>
	<rect x="106.744" y="109.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="141.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="173.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="205.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="237.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="269.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="301.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="333.336" style="fill:#999999;" width="298.48" height="10.664"/>
</g>
<rect x="106.744" y="40" style="fill:#DB2B42;" width="298.48" height="32"/>
<rect x="106.736" y="365.336" style="fill:#999999;" width="298.48" height="10.664"/>
</svg>

               <span class="ms-3">Formulaire de Discipline</span>
            </a>
         </li>
         <li>
            <a href="propos.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
                <svg class="flex-shrink-0 w-7 h-7 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"  viewBox="0 0 48 48" version="1" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 48 48">
                  <path fill="#2196F3" d="M37,40H11l-6,6V12c0-3.3,2.7-6,6-6h26c3.3,0,6,2.7,6,6v22C43,37.3,40.3,40,37,40z"/>
                  <g fill="#ffffff">
                     <rect x="22" y="20" width="4" height="11"/>
                     <circle cx="24" cy="15" r="2"/>
                  </g>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">A propos</span>
            </a>
         </li>
         <li>
            <a href="deconnexion.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
                    
                              <svg width="800px" class="flex-shrink-0 w-5 h-5 text-gray-300 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" height="800px" viewBox="0 0 24 24" id="meteor-icon-kit__regular-sign-out" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M20.5858 12.9999H5C4.44772 12.9999 4 12.5522 4 11.9999C4 11.4476 4.44772 10.9999 5 10.9999H20.5858L18.2929 8.70701C17.9024 8.31648 17.9024 7.68332 18.2929 7.29279C18.6834 6.90227 19.3166 6.90227 19.7071 7.29279L23.7071 11.2928C24.0976 11.6833 24.0976 12.3165 23.7071 12.707L19.7071 16.707C19.3166 17.0975 18.6834 17.0975 18.2929 16.707C17.9024 16.3165 17.9024 15.6833 18.2929 15.2928L20.5858 12.9999ZM14 6.9999C14 7.55218 13.5523 7.9999 13 7.9999C12.4477 7.9999 12 7.55218 12 6.9999V4.69415C12 4.20531 11.6466 3.78812 11.1644 3.70776L3.1644 2.37443C2.61963 2.28363 2.1044 2.65165 2.01361 3.19642C2.00455 3.25075 2 3.30574 2 3.36082V20.639C2 21.1913 2.44772 21.639 3 21.639C3.05508 21.639 3.11007 21.6344 3.1644 21.6254L11.1644 20.292C11.6466 20.2117 12 19.7945 12 19.3056V16.9999C12 16.4476 12.4477 15.9999 13 15.9999C13.5523 15.9999 14 16.4476 14 16.9999V19.3056C14 20.7722 12.9398 22.0237 11.4932 22.2648L3.4932 23.5982C3.3302 23.6253 3.16524 23.639 3 23.639C1.34315 23.639 0 22.2958 0 20.639V3.36082C0 3.19558 0.0136525 3.03062 0.0408182 2.86762C0.313203 1.23331 1.85889 0.129253 3.4932 0.401638L11.4932 1.73497C12.9398 1.97607 14 3.22764 14 4.69415V6.9999Z" fill="#758CA3"/></svg>
               <span class="flex-1 ms-3 whitespace-nowrap text-red-800">Deconnexion</span>
            </a>
         </li>
      </ul>
      
   </div>
</aside>

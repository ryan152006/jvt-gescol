<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas authentifié
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <script src="https://cdn.tailwindcss.com"></script>
    
    <title>Communique</title>
</head>
<style>
    /* Fixer la barre de navigation en haut */
    nav {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 10; /* Assure que la navbar est au-dessus du reste du contenu */
    }

    .side {
       max-height: 95vh;
       overflow-y: auto;
       scrollbar-width: thin; /* Réduit la largeur de la scrollbar sur Firefox */
   }

   .side::-webkit-scrollbar {
       width: 5px; /* Réduit la largeur de la scrollbar sur Chrome/Safari */
   }

   .side::-webkit-scrollbar-thumb {
       background-color: rgba(0, 0, 0, 0.2); /* Couleur de la scrollbar */
       border-radius: 4px;
   }

   /* Ajout de styles pour le contenu principal */
   .main-content {
       max-height: 95vh; /* Fixer la hauteur pour éviter le défilement de la page entière */
       /* Permettre le défilement du contenu principal */
       scrollbar-width: thin;
   }

   .main-content::-webkit-scrollbar {
       width: 5px;
   }

   .main-content::-webkit-scrollbar-thumb {
       background-color: rgba(0, 0, 0, 0.2);
       border-radius: 4px;
   }

   /* Ajuster le décalage du contenu à cause de la navbar fixe */
   .content {
       padding-top: 4rem; /* Ajuste selon la hauteur de votre navbar */
   }
</style>
<body class="bg-white dark:bg-gray-800 overflow-hidden left-0 top-0 justify-center items-center">
    
    <nav><?php  require "communique/navbar.php"  ?> </nav>

    <section class=" flex flex-row h-screen content">
        <div class=" side overflow-auto w-1/5"> <?php require "communique/sidebar.php"  ?> </div>
        <div class=" main-content w-4/5"> <?php  require "communique/main.php" ?> </div> 
    </section>
    <script src="../../../JS/sidebar.js"></script>
    <script src="../../../JS/navbar.js"></script>
</body>
</html>
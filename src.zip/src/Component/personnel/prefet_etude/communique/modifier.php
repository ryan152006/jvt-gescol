<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["titre"])) {
        
        // Récupération des données du formulaire
     
        $titre = $_POST["titre"];
        $contenu = $_POST["contenu"];
        if (isset($_FILES['piecejointe']) && $_FILES['piecejointe']['error'] === UPLOAD_ERR_OK) {
            $piecejointe = $_FILES['piecejointe'];
            $piecejointeNom = $piecejointe['name'];
            $piecejointeTmpName = $piecejointe['tmp_name'];
            $piecejointeSize = $piecejointe['size'];
            $piecejointeError = $piecejointe['error'];
            $piecejointeType = $piecejointe['type'];

            // Vérifier que le répertoire de téléchargement existe sinon le créer
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Valider et déplacer la pièce jointe
            if ($piecejointeError === 0) {
                // Extraire l'extension du fichier
                $piecejointeExt = strtolower(pathinfo($piecejointeNom, PATHINFO_EXTENSION));
                $allowedExts = ['pdf', 'doc', 'docx', 'jpg', 'png'];

                if (in_array($piecejointeExt, $allowedExts)) {
                    // Générer un nouveau nom unique pour le fichier
                    $piecejointeNewName = uniqid('', true) . '.' . $piecejointeExt;
                    $piecejointeDest = $uploadDir . $piecejointeNewName;

                    // Déplacer le fichier téléchargé vers le répertoire cible
                    if (!move_uploaded_file($piecejointeTmpName, $piecejointeDest)) {
                        echo "<p class='text-red-500'>Erreur lors du déplacement de la pièce jointe.</p>";
                        $piecejointeNewName = ''; // Assurez-vous que $piecejointeNewName est vide en cas d'échec
                    }
                } else {
                    echo "<p class='text-red-500'>Type de fichier non autorisé. Les extensions autorisées sont : pdf, doc, docx, jpg, png.</p>";
                }
            } else {
                echo "<p class='text-red-500'>Erreur lors du téléchargement de la pièce jointe. Code d'erreur : $piecejointeError.</p>";
            }
        }

      
        
        $id = $_GET["id"];
        // Assurez-vous que l'ID est bien récupéré

        // Préparation de la requête SQL
        $request = $conn->prepare("UPDATE communique SET titre = :titre, contenu = :contenu, piecejointe = :piecejointe
        WHERE id = :id");
  $request->bindParam(':titre', $titre);
  $request->bindParam(':contenu', $contenu);
  $request->bindParam(':piecejointe', $piecejointeNewName);
  $request->bindParam(':id', $id);
        // Liaison des paramètres
        

        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../communique.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}


$id = $_GET["id"];
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM communique WHERE id = :id");
    $request->bindParam(':id', $id);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Modifier un Communiqué</title>
    <style>
        body {
           
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }

        .card-content {
            padding: 1rem;
        }

        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>

<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-2xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Modifier un Communiqué
                </div>
                <div class="card-content">
                    <form  method="post" enctype="multipart/form-data" class="space-y-4">
                        <div>
                            <label for="titre" class="block text-sm font-medium text-gray-700">Titre</label>
                            <input type="text" id="titre" name="titre" required value = "<?= $row['titre']?>"
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu</label>
                            <textarea id="contenu" name="contenu" rows="4" 
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900"><?php echo $row['contenu']?></textarea>
                        </div>
                        <div>
                            <label for="piecejointe" class="block text-sm font-medium text-gray-700">Pièce Jointe</label>
                            <input type="file" id="piecejointe" name="piecejointe" accept=".pdf,.doc,.docx,.jpg,.png" value = "<?= $row['piecejointe']?>"
                                class="mt-1 block w-full rounded border-2 border-blue-400 focus:border-blue-700 sm:text-sm bg-white text-gray-900">
                        </div>
                        <div>
                            <button type="submit"
                                class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center">
                                Modifier le Communiqué
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-footer">
                    <a href="../communique.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des communiqués</a>
                </div>
            </div>
        </div>
    </section>

</body>

</html>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Communiqués</title>
    <style>
        body {
            background-image: url("../../../../Assets/back1.jpg");
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        /* Styles spécifiques pour l'impression */
        @media print {
            body {
                background-image: none; /* Supprimer le fond pour l'impression */
            }
            .print-hidden {
                display: none; /* Cacher les éléments non pertinents pour l'impression */
            }
            .print-visible {
                background-color: white; /* Fond blanc pour les communiqués */
                border: 1px solid black; /* Bordure noire autour du communiqué */
                padding: 10px; /* Espacement autour du communiqué */
            }
            /* Empêcher la pagination dans les impressions */
            @page {
                margin: 0.5in;
            }
        }
    </style>
    <style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 10x;
    border: 1px solid #888;
    width: 60%;
    max-width: 60%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
    <script>
        function printCommunique(communiqueId) {
            // Cacher tous les autres communiqués
            document.querySelectorAll('.communique').forEach(function(element) {
                if (!element.classList.contains('communique-' + communiqueId)) {
                    element.classList.add('print-hidden');
                } else {
                    element.classList.add('print-visible');
                }
            });

            // Lancer l'impression
            window.print();

            // Réinitialiser la visibilité des communiqués
            document.querySelectorAll('.communique').forEach(function(element) {
                element.classList.remove('print-hidden', 'print-visible');
            });
        }
    </script>
</head>
<body class="bg-gray-100">
    <section id="main-content" class="flex flex-col min-h-screen p-4">
    <div class="w-full mb-4 print-hidden">
            <a href="communique/creer.php">
                <button type="button" class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-4 py-2.5 text-center w-full sm:w-auto">
                    Ajouter un Communiqué
                </button>
            </a>
        </div>

        <div class="flex flex-col py-2 flex-grow">
            <?php
            require_once '../../../Traitement/connexion.php'; // Assurez-vous que ce chemin est correct

            // Requête SQL pour obtenir tous les communiqués, triés par ID décroissant
            $sql = "SELECT * FROM communique ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $communiques = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($communiques as $communique) {
                $alertClass = "border-blue-500 bg-transparent"; // Bordure bleue et fond transparent
                $cardWidth = "w-full max-w-8xl"; // Largeur des cartes augmentée
                
                $piecejointeText = !empty($communique['piecejointe'])
                    ? '<p class="mt-2"><a href="../../../Traitement/principal/communique/uploads/' . htmlspecialchars($communique['piecejointe']) . '" target="_blank" class="text-blue-600 hover:underline">Télécharger la pièce jointe</a></p>'
                    : '<p class="mt-2 text-gray-500">Pas de pièce jointe.</p>';
                
                echo '<div class="p-4 mb-4 communique communique-' . htmlspecialchars($communique['id']) . ' ' . $alertClass . ' border rounded ' . $cardWidth . ' text-blue-800">';
                echo '<div class="flex items-center">';
                echo '<svg class="flex-shrink-0 w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">';
                echo '<path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>';
                echo '</svg>';
                echo '<h3 class="text-lg font-medium text-white">Communiqué du ' .htmlspecialchars($communique['date']). '</h3>';
                echo '</div>';
                echo '<div class="mt-2 mb-4 text-sm text-blue-500">';
                echo '<h2 class="text-xl font-semibold">' . htmlspecialchars($communique['titre']) . '</h2>';
                echo '<p class="mt-2 text-white">' . nl2br(htmlspecialchars($communique['contenu'])) . '</p>';
                echo $piecejointeText;
                echo '</div>';
                echo '<div class="text-right flex space-x-2">';
                ?>
                <a href="../../../Traitement/prefetetude/communique/supprimer.php?id=<?php echo $communique['id']; ?>" 
                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce communiqué ?');">
                    <button type="button" class="text-red-500 bg-transparent border border-red-500 hover:bg-red-500 hover:text-white focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded text-xs px-3 py-1.5 text-center">
                        Supprimer le communiqué
                    </button>
                </a>
               
                <?php
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>

        <!-- Ajoutez un espace supplémentaire en bas -->
        <div class="mt-auto mb-4 py-6 print-hidden"></div>
    </section>
    
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('communique/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>
</body>
</html>

<!-- Start block -->

<?php
// index.php
include '../../../Traitement/connexion.php'; // Inclure le fichier de connexion

// Requête pour obtenir les classes
$query = "SELECT * FROM classe";
$stmt = $conn->prepare($query);
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!-- Start block -->

<style>

/* Styles pour la modal */
.modal {
    display: none; /* Masquer la modal par défaut */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Couleur de l'overlay */
}

.modal-content {
    
    margin: 10% auto; /* Décalage du haut pour mieux centrer */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Largeur de la modal */
    max-width: 80%; /* Limiter la largeur maximale */
    border-radius: 8px; /* Coins arrondis */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre portée */
    position: relative;
    
}

.modal-header {
    display: flex;
    justify-content: end;
    align-items: end;
    text-align: left;
}

.modal-header h2 {
    margin: 0;
    
    color: #333; /* Couleur du texte du titre */
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

/* Styles pour le cadre bleu */
.border-blue-container {
    border: 2px solid transparent; /* Bordure par défaut cachée */
    border-color: #007bff; /* Couleur bleue */
    border-radius: 8px; /* Coins arrondis */
    padding: 16px;
    margin: 10px 0;
    transition: border-color 0.3s ease; /* Transition pour le changement de couleur */
}

.border-blue-container:not(:empty) {
    border-color: #007bff; /* Affiche la bordure bleue si le contenu n'est pas vide */
}

.border-blue-container:empty {
    display: none; /* Masquer le cadre si vide */
}
#main-content {
    max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
    overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
}
</style>
<style>
    #main-content {
        max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
        overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
    }
</style>


<div id="main-content" class="mx-auto w-auto overflow-x-hidden justify-center items-center  py-4  scrollable-modal">
        <!-- Start coding here -->
        <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
           
           
            <div class=" py-6 overflow-x-hidden justify-center items-center space-y-4">
                <span class="border border-blue-500 rounded p-2 text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 px-4 space-x-2">Liste des Salles de Classe du College <br> <span class="text-blue-500"> JEAN XXIII D'EFOK </span> </span>
                <div class="w-auto">
                    <a href="classe/enregistrer.php"  class="">
                        <button class="text-white bg-blue-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
                            + Ajouter une nouvelle classe
                        </button>
                        </a>
                       
                </div>
             <div class="overflow-auto w-full">
                <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                    <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-8 py-3">Libelle</th>
                            <th scope="col" class="px-8 py-3">Effectif</th>
                            <th scope="col" class="px-8 py-3">Prof titulaire</th>
                            <th scope="col" class="px-8 py-3">Description</th>
                            <th scope="col" class="px-8 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="overflow-y-auto overflow-x-auto">
                        <?php foreach ($classes as $classe): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['nom_class']); ?></td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"> <?php
  

                                // Préparer et exécuter la requête
                                // Préparer et exécuter la requête
                                $sltm = $conn->prepare("SELECT COUNT(id) AS total FROM eleve WHERE id_class = :id_class");
                                $sltm->bindParam(":id_class", $classe['id_class']);
                                $sltm->execute();

                                // Récupérer le résultat
                                $count = $sltm->fetch(PDO::FETCH_ASSOC);

                                // Afficher le nombre total d'ID    
                                echo $count['total'];

                                ?> </td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['nom_enseig']); ?></td>
                            <td class="px-8 text-center max-w-[16rem] truncate py-2"><?php echo htmlspecialchars($classe['description']); ?></td>
                            <td class="px-8 text-center py-2 flex items-center justify-end space-x-3">
                                <a href="classe/modifier.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-green-500 text-center font-medium">
                                    <button>Modifier</button>
                                </a>
                                <a href="classe/consulter.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-blue-500 text-center font-medium">
                                    <button>Consulter</button>
                                </a>
                                <a href="../../../Traitement/secretaire/classe/delete.php?id=<?php echo urlencode($classe['id_class']); ?>" class="text-red-400 text-center font-medium">
                                    <button>Supprimer</button>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
   
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('classe/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>



<!-- End block -->
<!-- Create modal -->




<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    
    <title>Fiche d'Identification de la Classe</title>
    <style>
        body {
           
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        .card {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            background-color: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #f9fafb;
            border-bottom: 1px solid #e5e7eb;
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: 600;
        }
        .card-content {
            padding: 1rem;
        }
        .card-footer {
            border-top: 1px solid #e5e7eb;
            padding: 1rem;
            text-align: right;
        }
    </style>
</head>
<body class="bg-gray-100">

    <section class="flex justify-center items-center min-h-screen p-4">
        <div class="w-full max-w-4xl">
            <div class="card">
                <div class="card-header text-blue-500">
                    Fiche d'Identification de la Classe
                </div>
                <div class="card-content">
                    <?php
                        require_once '../../../../Traitement/connexion.php';
                        
                        $id = $_GET['id'];
                        $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id");
                        $request->bindParam(':id', $id, PDO::PARAM_INT);
                        $request->execute();
                        $row = $request->fetch(PDO::FETCH_ASSOC);
                        
                        if ($row) {
                            // Les informations de la classe
                            $effectif = $row['nbre_elev'];
                            $professeur = htmlspecialchars($row['nom_enseig']);
                            $description = htmlspecialchars($row['description']);
                            $sltm = $conn->prepare("SELECT COUNT(id) AS total FROM eleve WHERE id_class = :id_class");
                          $sltm->bindParam(":id_class", $row['id_class']);
                          $sltm->execute();
                          
                          // Récupérer le résultat
                          $count = $sltm->fetch(PDO::FETCH_ASSOC);
                           ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p class="font-semibold text-gray-700">ID de la Classe :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['id_class']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Libellé :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($row['nom_class']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Effectif :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($count['total']) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Professeur Responsable :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($professeur) ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-700">Description :</p>
                            <p class="text-gray-900"><?= htmlspecialchars($description) ?></p>
                        </div>
                    </div>
                    <?php
                        } else {
                            echo "<p>Aucune classe trouvée avec cet ID.</p>";
                        }
                    ?>
                </div>
                <div class="card-footer">
                    <a href="../classe.php" class="text-blue-500 hover:text-blue-700">Retour à la liste des classes</a>
                </div>
            </div>
        </div>
    </section>

</body>
</html>

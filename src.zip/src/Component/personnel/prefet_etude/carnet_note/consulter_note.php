<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    header('Location: ../connexion_autre_poste.php');
    exit();
}

// Assurez-vous que $_SESSION['employe'] est défini
$secr = $_SESSION['employe'];

require "../../../../Traitement/connexion.php";

$classe = $_GET['nom_class'];
$query = $conn->prepare("SELECT * FROM carnet_note WHERE nom_class = :classe ORDER BY motif, nom_eleve ");
$query->bindParam(':classe', $classe, PDO::PARAM_STR);
$query->execute();
$remplissages = $query->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fiche de Notes</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="container mx-auto bg-white p-6 rounded shadow-lg">
    <div class="flex justify-between space-x-8">
            <h1 class="text-2xl text-blue-800 font-bold mb-4">Fiche de Notes</h1>
            <div class="flex justify-center py-4 space-x-12">
                <a href="../carnet_note.php" class="text-black mx-4 bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600">
                    Retour
                </a>
            </div>
        </div>
        <div class="flex justify-between space-x-8">
            <div class="mb-2">
                <p class="text-lg font-normal">Classe : <?php echo htmlspecialchars($classe); ?></p>
            </div>
        </div>

        <?php
        // Regrouper les enregistrements par motif
        $motifs = [];
        foreach ($remplissages as $remplissage) {
            $motifs[$remplissage['motif']][] = $remplissage;
        }

        // Parcourir chaque groupe de motifs et afficher les carnets de notes correspondants
        foreach ($motifs as $motif => $notes) {
            $date = htmlspecialchars($notes[0]['date']);
            $annee_scolaire = htmlspecialchars($notes[0]['annee_scolaire']);
        ?>

        <div class="mb-6">
            <h2 class="text-xl font-semibold">Motif : <?php echo htmlspecialchars($motif); ?></h2>
            <p class="text-lg font-normal">Date : <?php echo $date; ?></p>
            <p class="text-lg font-normal">Année Scolaire : <?php echo $annee_scolaire; ?></p>

            <!-- Liste des élèves avec notes et appréciations -->
            <table class="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b font-medium">Nom de l'élève</th>
                        <th class="py-2 px-4 border-b font-medium">Note</th>
                        <th class="py-2 px-4 border-b font-medium">Coef</th>
                        <th class="py-2 px-4 border-b font-medium">Appréciation</th>
                        <th class="py-2 px-4 border-b font-medium">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($notes as $note) {
                        $nom_complet = htmlspecialchars($note['nom_eleve']);
                        $note_val = htmlspecialchars($note['note']);
                        $coef = htmlspecialchars($note['coef']);
                        $appreciation = htmlspecialchars($note['appreciation']);

                        $id = htmlspecialchars($note['code_carn']); // Assurez-vous que chaque enregistrement a un ID unique

            echo '<tr>';
            echo '<td class="py-2 text-center px-4 border-b">' . $nom_complet . '</td>';
            echo '<td class="py-2 text-center px-4 border-b">' . $note_val . '</td>';
            echo '<td class="py-2 text-center px-4 border-b">' . $coef . '</td>';
            echo '<td class="py-2 text-center px-4 border-b">' . $appreciation . '</td>';
            echo '<td class="py-2 text-center px-4 border-b">';
            echo '<a href="modifier_note.php?id=' . $id . '" class="text-blue-500 hover:underline">Modifier</a>'; // Lien vers la page de modification
            echo '</td>';
            echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <?php
        } // Fin du foreach des motifs
        ?>

      
    </div>
</body>
</html>

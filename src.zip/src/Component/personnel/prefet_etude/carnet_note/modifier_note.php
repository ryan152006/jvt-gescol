<?php
session_start();

// Vérifiez si la session contient des informations sur l'employé
if (!isset($_SESSION['employe'])) {
    header('Location: ../connexion_autre_poste.php');
    exit();
}

require "../../../../Traitement/connexion.php";

// Récupérer l'ID du carnet de notes à modifier
$id = $_GET['id'];

// Récupérer les informations du carnet de notes correspondant
$query = $conn->prepare("SELECT * FROM carnet_note WHERE code_carn = :id");
$query->bindParam(':id', $id, PDO::PARAM_INT);
$query->execute();
$note = $query->fetch(PDO::FETCH_ASSOC);

// Si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_note = $_POST['note'];
    $new_coef = $_POST['coef'];

    // Mettre à jour la note et le coefficient
    $update_query = $conn->prepare("UPDATE carnet_note SET note = :note, coef = :coef WHERE code_carn = :id");
    $update_query->bindParam(':note', $new_note, PDO::PARAM_STR);
    $update_query->bindParam(':coef', $new_coef, PDO::PARAM_INT);
    $update_query->bindParam(':id', $id, PDO::PARAM_INT);
    $update_query->execute();

    // Rediriger après la modification
    header('Location: consulter_note.php?nom_class=' . urlencode($note['nom_class']));
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier la Note</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="container mx-auto bg-white p-6 rounded shadow-lg">
        <h1 class="text-2xl text-blue-800 font-semibold mb-4">Modifier la Note de <?php echo htmlspecialchars($note['nom_eleve']); ?></h1>

        <form method="POST" action="">
            <div class="mb-4">
                <label for="note" class="block text-lg font-medium">Note</label>
                <input type="number" name="note" id="note" value="<?php echo htmlspecialchars($note['note']); ?>" min="0" max="20" class="w-full px-4 py-2 border rounded">
            </div>

            <div class="mb-4">
                <label for="coef" class="block text-lg font-medium">Coef</label>
                <input type="number" name="coef" id="coef" value="<?php echo htmlspecialchars($note['coef']); ?>" min="1" max="6" class="w-full px-4 py-2 border rounded">
            </div>

            <div class="flex justify-end space-x-4">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Enregistrer</button>
                <a href="../carnet_note.php" class="text-red-500 bg-transparent rounded py-2">Retour</a>
            </div>
        </form>
    </div>
</body>
</html>

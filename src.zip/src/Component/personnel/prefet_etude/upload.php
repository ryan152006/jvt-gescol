<?php
require "../../../Traitement/connexion.php"; // Assurez-vous que le chemin est correct

// Chemin où les fichiers seront stockés
$uploadDirectory = '../../../Assets/';

// Vérifiez si le répertoire d'upload existe, sinon créez-le
if (!is_dir($uploadDirectory)) {
    mkdir($uploadDirectory, 0777, true);
}

// Vérifiez si un fichier a été envoyé
if (isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $fileName = basename($file['name']);
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];
    $fileType = $file['type'];

    // Définir les types de fichiers autorisés avec les types MIME corrects
    $allowedTypes = array(
        'pdf' => 'application/pdf',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png'
    );
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // Validation du fichier
    if ($fileError === UPLOAD_ERR_OK) {
        if (array_key_exists($fileExt, $allowedTypes) && $allowedTypes[$fileExt] === $fileType) {
            // Déplacer le fichier vers le répertoire d'upload
            $uploadPath = $uploadDirectory . $fileName;
            if (move_uploaded_file($fileTmpName, $uploadPath)) {
                // Préparation de l'insertion en base de données
                $stmt = $conn->prepare("INSERT INTO piece_jointe (file_name, file_path, file_type, file_size) VALUES (:file_name, :file_path, :file_type, :file_size)");
                $stmt->bindParam(':file_name', $fileName);
                $stmt->bindParam(':file_path', $uploadPath);
                $stmt->bindParam(':file_type', $fileType);
                $stmt->bindParam(':file_size', $fileSize);

                if ($stmt->execute()) {
                    echo "Le fichier a été téléchargé et ajouté à la base de données avec succès.";
                    header("Location: form_disc.php");
                    exit();
                } else {
                    echo "Une erreur est survenue lors de l'ajout du fichier à la base de données.";
                    header("Location: form_disc/enregistrer.php");
                    exit();
                }
            } else {
                echo "Une erreur est survenue lors du déplacement du fichier.";
            }
        } else {
            echo "Type de fichier non autorisé. Veuillez télécharger un PDF ou une image.";
            header("Location: form_disc/enregistrer.php");
            exit();
        }
    } else {
        echo "Une erreur est survenue lors du téléchargement du fichier.";
        header("Location: form_disc/enregistrer.php");
        exit();
    }
} else {
    echo "Aucun fichier n'a été envoyé.";
}
?>

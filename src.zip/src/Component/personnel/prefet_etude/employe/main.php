<?php
require '../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

// Récupération des données des élèves depuis la base de données
$query = "SELECT nom, prenom, telephone, email, sexe, matricule, poste FROM employe ORDER BY nom asc";
$stmt = $conn->prepare($query);
$stmt->execute();
$employe = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
/* Styles pour la modal */
#main-content {
    max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
    overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
}
.modal {
    display: none; /* Masquer la modal par défaut */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Couleur de l'overlay */
}

.modal-content {
    
    margin: 10% auto; /* Décalage du haut pour mieux centrer */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Largeur de la modal */
    max-width: 80%; /* Limiter la largeur maximale */
    border-radius: 8px; /* Coins arrondis */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre portée */
    position: relative;
    
}

.modal-header {
    display: flex;
    justify-content: end;
    align-items: end;
    text-align: left;
}

.modal-header h2 {
    margin: 0;
    
    color: #333; /* Couleur du texte du titre */
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

/* Styles pour le cadre bleu */
.border-blue-container {
    border: 2px solid transparent; /* Bordure par défaut cachée */
    border-color: #007bff; /* Couleur bleue */
    border-radius: 8px; /* Coins arrondis */
    padding: 16px;
    margin: 10px 0;
    transition: border-color 0.3s ease; /* Transition pour le changement de couleur */
}

.border-blue-container:not(:empty) {
    border-color: #007bff; /* Affiche la bordure bleue si le contenu n'est pas vide */
}

.border-blue-container:empty {
    display: none; /* Masquer le cadre si vide */
}
</style>



<!-- Start block -->

<div  id="main-content" class="visible mx-auto w-auto overflow-y-auto overflow-x-hidden justify-center items-center left-0 top-0 py-4  scrollable-modal">
    <!-- Start coding here -->
    <div class="w-full md:w-auto  overflow-y-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-auto overflow-y-auto justify-center items-center space-y-4">
        <!-- Utilisez la classe `border-blue-container` pour les sections avec le cadre bleu -->
        <span class="border-blue-container m text-2xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 space-x-2">
            Liste des Employés du College <br> 
            <span class="text-blue-500"> JEAN XXIII D'EFOK </span>
        </span>
   
        <div class="w-auto">
                <a href="employe/enregistrer.php" class="">
                    <button class="text-white bg-blue-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
                        + Enregistrer un Nouvel Employé
                    </button>
                </a>
            </div>
            <div class="overflow-auto w-full">
            <table class="w-full overflow-x-auto overflow-y-auto text-sm text-center text-gray-500 dark:text-gray-400">
                <thead class="text-xs overflow-x-auto text-gray-700 bg-gray-50 dark:bg-gray-700 px-12 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-2 py-4">Matricule</th>
                        <th scope="col" class="px-2 py-3">Nom</th>
                        <th scope="col" class="px-2 py-3">Prenom</th>
                        <th scope="col" class="px-2 py-3">Email</th>
    
                        <th scope="col" class="px-2 py-3">Téléphone</th>
                        <th scope="col" class="px-2 py-3">Sexe</th>
                        <th scope="col" class="px-2 py-3">Poste</th>
                        <th scope="col" class="px-2 py-3">
                            <span class="">Actions</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="overflow-y-auto overflow-x-auto">
                    <?php foreach ($employe as $row): ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-2 text-center text-gray-300 max-w-[16rem] truncate py-2 ">
                                <?php echo htmlspecialchars($row['matricule']); ?>
                            </td>
                            <td class="px-2 text-center text-gray-300 max-w-[16rem] truncate py-2">
                                <?php echo htmlspecialchars($row['nom']); ?>
                            </td>
                            <td class="px-2 text-center text-gray-300 max-w-[16rem] truncate py-2">
                                <?php echo htmlspecialchars($row['prenom']); ?>
                            </td>
                            <td class="px-2 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['email']); ?>
                            </td>
                            <td class="px-2 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['telephone']); ?>
                            </td>
                            <td class="px-2 text-left text-gray-300 py-2 max-w-[18rem] truncate">
                                <?php echo htmlspecialchars($row['sexe']); ?>
                            </td>
                            
                            <td class="px-2 text-center text-gray-300 py-2">
                                <?php echo htmlspecialchars($row['poste']); ?>
                            </td>
                            <td class="px-2 text-center py-2 flex items-center justify-end space-x-3">
                                <a href="employe/modifier.php?matricule=<?php echo urlencode($row['matricule']); ?>" class="text-green-500 text-center font-medium">
                                    <button>Modifier</button>
                                </a>
                                <a href="employe/consulter.php?matricule=<?php echo urlencode($row['matricule']); ?>" class="text-blue-500 text-center font-medium">
                                    <button>Consulter</button>
                                </a>
                                <a href="../../../Traitement/secretaire/employe/delete.php?matricule=<?php echo urlencode($row['matricule']); ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet élève ?');" class="text-red-400 text-center font-medium" 
                                onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce communiqué ?');">
                                    <button>Supprimer</button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');
    const resetButton = document.getElementById('reset-search');
    const searchInput = document.getElementById('topbar-search');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêche la soumission normale du formulaire
        
        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        // Afficher la modal et cacher le contenu principal
        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('employe/rechercher.php?search=' + encodeURIComponent(searchQuery), {
            method: 'GET',
        })
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none'; // Masquer la modal
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
    });

    // Événement pour fermer la modal en cliquant en dehors de celle-ci
    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        }
    });

    resetButton.addEventListener('click', function() {
        searchInput.value = ''; // Réinitialiser le champ de recherche
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        resultsModal.style.display = 'none'; // Masquer la modal
        resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
    });

    searchInput.addEventListener('input', function(event) {
        if (event.target.value.trim() === '') {
            // Réinitialiser la page lorsque le champ de recherche est vide
            mainContent.classList.remove('hidden');
            resultsModal.style.display = 'none'; // Masquer la modal
            resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
        }
    });
});


</script>



<!-- End block -->
<!-- Create modal -->

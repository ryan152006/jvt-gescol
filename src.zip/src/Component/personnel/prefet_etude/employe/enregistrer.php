<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Enregistrement</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">

<section class="flex justify-center items-center min-h-screen py-2 px-6">
    <!-- Modal content -->
    <div class="bg-white dark:bg-gray-800 rounded shadow p-6 w-full max-w-lg">
        <!-- Modal header -->
        <h1 class="text-2xl font-semibold text-blue-500 mb-2 text-center">
            Ajouter un employé
        </h1>
        
        <!-- Modal body -->
        <form id="registration-form" action="../../../../Traitement/secretaire/employe/enregistrer.php" method="post" class="space-y-6">
            <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="nom" class="block text-sm font-medium text-gray-900 dark:text-white ">Entrer le nom</label>
                    <input type="text" name="nom" id="nom" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div class="flex-1">
                    <label for="prenom" class="block text-sm font-medium text-gray-900 dark:text-white ">Entrer le prénom</label>
                    <input type="text" id="prenom" name="prenom" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
            </div>
            <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="tel" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le téléphone</label>
                    <input type="tel" name="telephone" id="tel" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
                <div class="flex-1">
                    <label for="email" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer l'email</label>
                    <input type="email" name="email" id="email" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
            </div>
            <div class="flex flex-col gap-4 sm:flex-row">
                <div class="flex-1">
                    <label for="matricule" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le matricule</label>
                    <input type="text" name="matricule" id="matricule" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                </div>
             <div class="flex-1">
                    <label for="poste" class="block text-sm font-medium text-gray-900 dark:text-white">Entrer le poste</label>
                    <select name="poste" id="poste" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        <option selected disabled class="text-gray-500">Sélectionner votre poste</option>
                        <option value="secretaire">Secrétaire</option>
                        <option value="caissiere">Caissière</option>
                        <option value="surveillantgeneral">Surveillant Général</option>
                        <option value="enseignant">Enseignant</option>
                        <option value="autre">Autre</option>
                    </select>
                </div>

                <div id="autre-container" class="flex flex-col hidden">
                    <label for="autre-poste" class="block text-sm font-medium text-gray-900 dark:text-white">Précisez le poste</label>
                    <input type="text" name="autre_poste" id="autre-poste" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Précisez le poste" />
                </div>
                </div>
            <div class="flex flex-col">
                <label for="sexe" class="block text-sm font-medium text-gray-900 dark:text-white">Sexe</label>
                <select name="sexe" id="sexe" title="Sélectionnez le sexe" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                    <option value="" selected disabled>Sélectionnez</option>
                    <option value="masculin">Masculin</option>
                    <option value="feminin">Féminin</option>
                </select>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-5 py-3 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Ajouter</button>
                <a href="../employe.php" class="w-full text-center text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded border border-gray-200 text-sm font-medium px-5 py-3 hover:text-gray-900 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Annuler</a>
            </div>
        </form>
    </div>
</section>
<script>
     document.addEventListener('DOMContentLoaded', function() {
    const posteSelect = document.getElementById('poste');
    const autreContainer = document.getElementById('autre-container');
    const autrePosteInput = document.getElementById('autre-poste');

    posteSelect.addEventListener('change', function() {
        if (posteSelect.value === 'autre') {
            autreContainer.classList.remove('hidden');
        } else {
            autreContainer.classList.add('hidden');
            autrePosteInput.value = ''; // Réinitialiser le champ texte
        }
    });
});

</script>

</body>
</html>

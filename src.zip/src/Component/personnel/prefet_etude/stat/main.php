<?php
require '../../../Traitement/connexion.php';

// Statistiques par classe et sexe
$classe_sexe_stats = $conn->query("
    SELECT classe, 
        SUM(CASE WHEN sexe_elev = 'masculin' THEN 1 ELSE 0 END) AS garcons,
        SUM(CASE WHEN sexe_elev = 'feminin' THEN 1 ELSE 0 END) AS filles,
        COUNT(*) AS total
    FROM eleve 
    GROUP BY classe
")->fetchAll();

// Statistiques par tranche d'âge (calcul basé sur l'année actuelle moins l'année de naissance)
$age_stats = $conn->query("SELECT YEAR(CURDATE()) - YEAR(date_naiss) AS age, COUNT(*) AS total FROM eleve GROUP BY age")->fetchAll();

// Statistiques par ethnie
$ethnie_stats = $conn->query("SELECT ethnie, COUNT(*) AS total FROM eleve GROUP BY ethnie")->fetchAll();

// Statistiques par religion
$religion_stats = $conn->query("SELECT religion, COUNT(*) AS total FROM eleve GROUP BY religion")->fetchAll();

// Statistiques financières (inscription et tranches)
// Statistiques financières (inscription et tranches)
$financial_stats = $conn->query("
    SELECT c.nom_class,
        COUNT(DISTINCT CASE WHEN e.inscription >= c.inscription THEN e.id ELSE NULL END) AS inscrits,
        COUNT(DISTINCT CASE WHEN e.tranche1 >= c.tranche1 THEN e.id ELSE NULL END) AS tranche1,
        COUNT(DISTINCT CASE WHEN e.tranche2 >= c.tranche2 THEN e.id ELSE NULL END) AS tranche2,
        COUNT(DISTINCT CASE WHEN e.tranche3 >= c.tranche3 THEN e.id ELSE NULL END) AS tranche3
    FROM eleve e
    JOIN classe c ON e.id_class = c.id_class
    GROUP BY c.nom_class
")->fetchAll();


// Statistiques sur les sacrements religieux
$sacrement_stats = $conn->query("
    SELECT 
        SUM(CASE WHEN baptise = 1 THEN 1 ELSE 0 END) AS baptises,
        SUM(CASE WHEN communie = 1 THEN 1 ELSE 0 END) AS communies,
        SUM(CASE WHEN confirme = 1 THEN 1 ELSE 0 END) AS confirmes
    FROM eleve
")->fetch();

// Statistiques des incidents disciplinaires par classe et sexe
$incident_stats = $conn->query("
    SELECT c.nom_class, 
           SUM(CASE WHEN e.sexe_elev = 'masculin' THEN 1 ELSE 0 END) AS garcons_incidents,
           SUM(CASE WHEN e.sexe_elev = 'feminin' THEN 1 ELSE 0 END) AS filles_incidents,
           COUNT(*) AS total_incidents
    FROM incident_disc i
    JOIN eleve e ON i.id_elev = e.id
    JOIN classe c ON i.id_class = c.id_class
    GROUP BY c.nom_class
")->fetchAll();
// Statistiques de présence par classe et sexe
$presence_stats = $conn->query("
    SELECT c.nom_class,
        SUM(CASE WHEN e.sexe_elev = 'masculin' AND p.present = 1 THEN 1 ELSE 0 END) AS garcons_presents,
        SUM(CASE WHEN e.sexe_elev = 'feminin' AND p.present = 1 THEN 1 ELSE 0 END) AS filles_presentes,
        SUM(CASE WHEN e.sexe_elev = 'masculin' AND p.present = 0 THEN 1 ELSE 0 END) AS garcons_absents,
        SUM(CASE WHEN e.sexe_elev = 'feminin' AND p.present = 0 THEN 1 ELSE 0 END) AS filles_absentes
    FROM presence p
    JOIN eleve e ON p.id_eleve = e.id
    JOIN classe c ON p.id_classe = c.id_class
    GROUP BY c.nom_class
")->fetchAll();
// Statistiques des recettes et dépenses par mois
$monthly_financial_stats = $conn->query("
    SELECT 
        MONTHNAME(date) AS mois,  -- Afficher le mois en lettres
        YEAR(date) AS annee,
        SUM(CASE WHEN categorie = 'recette' THEN montant ELSE 0 END) AS total_recette,
        SUM(CASE WHEN categorie = 'depense' THEN montant ELSE 0 END) AS total_depense
    FROM finance WHERE date != 0
    GROUP BY annee, mois
    ORDER BY annee, MONTH(date)
")->fetchAll();





?>

<style>
/* Styles pour la modal */
.modal {
    display: none; /* Masquer la modal par défaut */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Couleur de l'overlay */
}

.modal-content {
    
    margin: 10% auto; /* Décalage du haut pour mieux centrer */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Largeur de la modal */
    max-width: 80%; /* Limiter la largeur maximale */
    border-radius: 8px; /* Coins arrondis */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre portée */
    position: relative;
    
}

.modal-header {
    display: flex;
    justify-content: end;
    align-items: end;
    text-align: left;
}

.modal-header h2 {
    margin: 0;
    
    color: #333; /* Couleur du texte du titre */
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

/* Styles pour le cadre bleu */
.border-blue-container {
    border: 2px solid transparent; /* Bordure par défaut cachée */
    border-color: #007bff; /* Couleur bleue */
    border-radius: 8px; /* Coins arrondis */
    padding: 16px;
    margin: 10px 0;
    transition: border-color 0.3s ease; /* Transition pour le changement de couleur */
}

.border-blue-container:not(:empty) {
    border-color: #007bff; /* Affiche la bordure bleue si le contenu n'est pas vide */
}

.border-blue-container:empty {
    display: none; /* Masquer le cadre si vide */
}
#main-content {
    max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
    overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
}
</style>
<div id="main-content" class="container mx-auto p-4 min-h-screen">
    <h1 class="text-3xl font-bold text-blue-400 text-center mb-6">Statistiques du collège JEAN XIII d'EFOK</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        <!-- Statistiques par classe et sexe -->
        <div class="bg-blue-200 p-4 rounded shadow-lg">
            <h2 class="text-xl text-blue-600 font-medium">Statistiques par classe et sexe</h2>
            <ul>
                <?php foreach ($classe_sexe_stats as $classe): ?>
                    <li class="py-1"><?= $classe['classe'] ?> : 
                        <?= $classe['garcons'] ?> garçons, 
                        <?= $classe['filles'] ?> filles (<?= $classe['total'] ?> élèves)
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Statistiques par tranche d'âge -->
        <div class="bg-green-200 p-4 rounded shadow-lg">
            <h2 class="text-xl text-blue-600 font-medium">Répartition par âge</h2>
            <ul>
                <?php foreach ($age_stats as $age): ?>
                    <li class="py-2">Âge <?= $age['age'] ?> Ans : <?= $age['total'] ?> élèves</li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Statistiques par ethnie -->
        <div class="bg-yellow-200 p-4 rounded shadow-lg">
            <h2 class="text-xl text-blue-600 font-medium">Répartition par ethnie</h2>
            <ul>
                <?php foreach ($ethnie_stats as $ethnie): ?>
                    <li class="py-2"><?= $ethnie['ethnie'] ?> : <?= $ethnie['total'] ?> élèves</li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Statistiques par religion -->
        <div class="bg-purple-200 p-4 rounded shadow-lg">
            <h2 class="text-xl text-blue-600 font-medium">Répartition par religion</h2>
            <ul>
                <?php foreach ($religion_stats as $religion): ?>
                    <li class="py-1"><?= $religion['religion'] ?> : <?= $religion['total'] ?> élèves</li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Statistiques financières -->
        <div class="bg-teal-200 p-4 rounded shadow-lg">
    <h2 class="text-xl text-blue-600 font-medium">Statistiques financières par classe</h2>
    <div class="overflow-x-auto">
        <table class="w-full table-auto">
            <thead>
                <tr>
                    <th class="px-4 py-2">Classe</th>
                    <th class="px-4 py-2">Inscris</th>
                    <th class="px-4 py-2">Tranche 1</th>
                    <th class="px-4 py-2">Tranche 2</th>
                    <th class="px-4 py-2">Tranche 3</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($financial_stats as $classe): ?>
                    <tr>
                        <td class="border px-4 py-2"><?= $classe['nom_class'] ?></td>
                        <td class="border px-4 py-2"><?= $classe['inscrits'] ?></td>
                        <td class="border px-4 py-2"><?= $classe['tranche1'] ?></td>
                        <td class="border px-4 py-2"><?= $classe['tranche2'] ?></td>
                        <td class="border px-4 py-2"><?= $classe['tranche3'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>




        <!-- Statistiques sur les sacrements religieux -->
        <div class="bg-gray-200 p-4 rounded shadow-lg mb-20">
            <h2 class="text-xl text-blue-600 font-medium">Sacrements religieux</h2>
            <ul>
                <li class="py-1">Baptisés : <?= $sacrement_stats['baptises'] ?></li>
                <li class="py-1">Communiés : <?= $sacrement_stats['communies'] ?></li>
                <li class="py-1">Confirmés : <?= $sacrement_stats['confirmes'] ?></li>
            </ul>
        </div>

        <!-- Statistiques des incidents disciplinaires par classe et sexe -->
        <div class="bg-red-200 p-4 rounded shadow-lg">
            <h2 class="text-xl text-blue-600 font-medium">Incidents disciplinaires par classe et sexe</h2>
            <ul>
                <?php foreach ($incident_stats as $classe): ?>
                    <li class="py-2">
                        Classe <?= $classe['nom_class'] ?> : 
                        <?= $classe['garcons_incidents'] ?> Garçons, 
                        <?= $classe['filles_incidents'] ?> Filles 
                        (Total : <?= $classe['total_incidents'] ?> incidents)
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <!-- Statistiques de présence par classe et sexe -->
<div class="bg-orange-200 p-4 rounded shadow-lg">
    <h2 class="text-xl text-blue-600 font-medium">Présence par classe et sexe</h2>
    <ul>
        <?php foreach ($presence_stats as $classe): ?>
            <li class="py-2">
                Classe <?= $classe['nom_class'] ?> : 
                            Absents : <?= $classe['garcons_absents'] ?> Garçons, <?= $classe['filles_absentes'] ?> Filles
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<!-- Statistiques des recettes et dépenses par mois -->
<div class="bg-gray-200 p-4 rounded shadow-lg">
    <h2 class="text-xl text-blue-600 font-medium">Recettes et Dépenses par Mois</h2>
    <div class="overflow-x-auto">
        <table class="w-full table-auto">
            <thead class="text-sm">
                <tr>
                    <th class="px-2 py-1">Mois</th>
                    <th class="px-2 py-1">Année</th>
                    <th class="px-2 py-1">Total Recettes</th>
                    <th class="px-2 py-1">Total Dépenses</th>
                </tr>
            </thead>
            <tbody class="text-xm">
                <?php foreach ($monthly_financial_stats as $stats): ?>
                    <tr>
                        <td class="border px-2 py-1"><?= $stats['mois'] ?></td>
                        <td class="border px-2 py-1"><?= $stats['annee'] ?></td>
                        <td class="border px-2 py-1"><?= number_format($stats['total_recette'], 2) ?> FCFA</td>
                        <td class="border px-2 py-1"><?= number_format($stats['total_depense'], 2) ?> FCFA</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>


    </div>
    <div class="my-24"></div>
</div>
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');
    const resetButton = document.getElementById('reset-search');
    const searchInput = document.getElementById('topbar-search');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêche la soumission normale du formulaire
        
        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        // Afficher la modal et cacher le contenu principal
        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve/rechercher.php?search=' + encodeURIComponent(searchQuery), {
            method: 'GET',
        })
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none'; // Masquer la modal
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
    });

    // Événement pour fermer la modal en cliquant en dehors de celle-ci
    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        }
    });

    resetButton.addEventListener('click', function() {
        searchInput.value = ''; // Réinitialiser le champ de recherche
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        resultsModal.style.display = 'none'; // Masquer la modal
        resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
    });

    searchInput.addEventListener('input', function(event) {
        if (event.target.value.trim() === '') {
            // Réinitialiser la page lorsque le champ de recherche est vide
            mainContent.classList.remove('hidden');
            resultsModal.style.display = 'none'; // Masquer la modal
            resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
        }
    });
});


</script>
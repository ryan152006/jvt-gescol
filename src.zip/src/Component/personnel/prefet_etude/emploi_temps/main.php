<?php
// Connexion à la base de données
require '../../../Traitement/connexion.php';

try {
    $stmt = $conn->prepare("SELECT id_class, nom_class FROM classe");
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>
<style>
/* Styles pour la modal */
.modal {
    display: none; /* Masquer la modal par défaut */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Couleur de l'overlay */
}

.modal-content {
    
    margin: 10% auto; /* Décalage du haut pour mieux centrer */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Largeur de la modal */
    max-width: 80%; /* Limiter la largeur maximale */
    border-radius: 8px; /* Coins arrondis */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre portée */
    position: relative;
    
}

.modal-header {
    display: flex;
    justify-content: end;
    align-items: end;
    text-align: left;
}

.modal-header h2 {
    margin: 0;
    
    color: #333; /* Couleur du texte du titre */
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

/* Styles pour le cadre bleu */
.border-blue-container {
    border: 2px solid transparent; /* Bordure par défaut cachée */
    border-color: #007bff; /* Couleur bleue */
    border-radius: 8px; /* Coins arrondis */
    padding: 16px;
    margin: 10px 0;
    transition: border-color 0.3s ease; /* Transition pour le changement de couleur */
}

.border-blue-container:not(:empty) {
    border-color: #007bff; /* Affiche la bordure bleue si le contenu n'est pas vide */
}

.border-blue-container:empty {
    display: none; /* Masquer le cadre si vide */
}
#main-content {
    max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
    overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
}
</style>
 <div id="main-content" class="container mx-auto p-6">
 <div class="flex flex-col mb-6 md:flex-row items-center justify-between space-y-4 md:space-y-0">
        <h1 class="text-2xl text-blue-500 font-bold  text-center">Choisissez une salle de classe</h1>
    <div class="">
        <a href="emploi_temps/list_emploi.php" class="justify-end  text-md   text-green-500 hover:text-blue-300 font-normal"> voir la liste des emplois de temps des enseignants</a>
        </div>
</div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php foreach ($classes as $classe): ?>
                <a href="emploi_temps/enregistrer.php?id_class=<?php echo urlencode($classe['id_class']); ?>" class="bg-blue-500 text-white p-4 rounded shadow-lg text-center hover:bg-blue-600">
                    <?php echo htmlspecialchars($classe['nom_class']); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');
    const resetButton = document.getElementById('reset-search');
    const searchInput = document.getElementById('topbar-search');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêche la soumission normale du formulaire
        
        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        // Afficher la modal et cacher le contenu principal
        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve/rechercher.php?search=' + encodeURIComponent(searchQuery), {
            method: 'GET',
        })
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none'; // Masquer la modal
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
    });

    // Événement pour fermer la modal en cliquant en dehors de celle-ci
    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        }
    });

    resetButton.addEventListener('click', function() {
        searchInput.value = ''; // Réinitialiser le champ de recherche
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        resultsModal.style.display = 'none'; // Masquer la modal
        resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
    });

    searchInput.addEventListener('input', function(event) {
        if (event.target.value.trim() === '') {
            // Réinitialiser la page lorsque le champ de recherche est vide
            mainContent.classList.remove('hidden');
            resultsModal.style.display = 'none'; // Masquer la modal
            resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
        }
    });
});


</script>
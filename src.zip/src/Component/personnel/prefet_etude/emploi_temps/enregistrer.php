<?php
// Inclusion du fichier de connexion
require '../../../../traitement/connexion.php';

// Récupération des enseignants
$enseignants = $conn->query("SELECT * FROM employe WHERE poste = 'enseignant'")->fetchAll(PDO::FETCH_ASSOC);

// Récupération du nom de la classe et du prof titulaire
$class_id = $_GET['id_class']; // Par défaut, classe 1
$class = $conn->prepare("SELECT * FROM classe WHERE id_class = :id_class");
$class->bindParam(":id_class", $class_id);
$class->execute();
$class_info = $class->fetch(PDO::FETCH_ASSOC);

// Récupération de l'emploi du temps existant pour cette classe
$emploi_temps = $conn->prepare("SELECT * FROM emploi_Temps WHERE id_class = ? ORDER BY heure_debut ASC");
$emploi_temps->execute([$class_id]);
$emploi_temps_data = $emploi_temps->fetchAll(PDO::FETCH_ASSOC);

$jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];

// Organisation des données par heure et par jour
$emploi_temps_par_jour = [];
foreach ($emploi_temps_data as $data) {
    $jour = strtolower($data['jour']);
    $heure_debut = $data['heure_debut'];
    $heure_fin = $data['heure_fin'];

    if (!isset($emploi_temps_par_jour[$heure_debut])) {
        $emploi_temps_par_jour[$heure_debut] = [
            'heure_fin' => $heure_fin,
            'jours' => []
        ];
    }
    
    $emploi_temps_par_jour[$heure_debut]['jours'][$jour] = $data;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emploi du Temps</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
</head>
<body class="bg-gray-100 p-6">
    <div class="container mx-auto">
        <h1 class="text-2xl font-bold text-center mb-6">Emploi du temps de la <?= $class_info['nom_class'] ?> - Prof Titulaire <?= $class_info['nom_enseig'] ?></h1>
        <div class="overflow-x-auto">
            <form method="POST" action="save_emploi_temps.php?id_class=<?php echo $class_id;?>">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead class="bg-gray-200 text-gray-700">
                        <tr>
                            <th class="py-2 px-4 border-b border-gray-300 text-left">Heure / Jour</th>
                            <?php foreach ($jours as $jour): ?>
                                <th class="py-2 px-4 border-b border-gray-300 text-center"><?= $jour ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php foreach ($emploi_temps_par_jour as $heure_debut => $data): ?>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-300 text-left">
                                    <input type="time" required name="heure_debut[]" value="<?= $heure_debut ?>" class="w-full border border-gray-300 px-2 py-1 mb-2">
                                    <input type="time" required name="heure_fin[]" value="<?= $data['heure_fin'] ?>" class="w-full border border-gray-300 px-2 py-1">
                                </td>
                                <?php foreach ($jours as $jour): ?>
                                    <td class="py-2 px-4 border-b border-gray-300 text-center">
                                        <?php if (isset($data['jours'][strtolower($jour)])): ?>
                                            <?php $emploi = $data['jours'][strtolower($jour)]; ?>
                                            <input type="text" name="programme[<?= strtolower($jour) ?>][]" value="<?= $emploi['programme'] ?>" placeholder="Programme" class="w-full border border-gray-300 px-2 py-1 mb-2">
                                            <select name="enseignant[<?= strtolower($jour) ?>][]" class="w-full border border-gray-300 px-2 py-1">
                                                <option value="">Sélectionner un enseignant</option>
                                                <?php foreach ($enseignants as $enseignant): ?>
                                                    <option value="<?= $enseignant['matricule'] ?>" <?= $enseignant['matricule'] == $emploi['id_employe'] ? 'selected' : '' ?>><?= $enseignant['nom'] . " " . $enseignant['prenom'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php else: ?>
                                            <input type="text" name="programme[<?= strtolower($jour) ?>][]" placeholder="Programme" class="w-full border border-gray-300 px-2 py-1 mb-2">
                                            <select name="enseignant[<?= strtolower($jour) ?>][]" class="w-full border border-gray-300 px-2 py-1">
                                                <option value="">Sélectionner un enseignant</option>
                                                <?php foreach ($enseignants as $enseignant): ?>
                                                    <option value="<?= $enseignant['matricule'] ?>"><?= $enseignant['nom'] . " " . $enseignant['prenom'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                        <!-- Ligne vide pour saisie -->
                        <tr>
                            <td class="py-2 px-4 border-b border-gray-300 text-left">
                                <input type="time" name="heure_debut[]" class="w-full border border-gray-300 px-2 py-1 mb-2">
                                <input type="time" name="heure_fin[]" class="w-full border border-gray-300 px-2 py-1">
                            </td>
                            <?php foreach ($jours as $jour): ?>
                                <td class="py-2 px-4 border-b border-gray-300 text-center">
                                    <input type="text" name="programme[<?= strtolower($jour) ?>][]" placeholder="Programme" class="w-full border border-gray-300 px-2 py-1 mb-2">
                                    <select name="enseignant[<?= strtolower($jour) ?>][]" class="w-full border border-gray-300 px-2 py-1">
                                        <option value="">Sélectionner un enseignant</option>
                                        <?php foreach ($enseignants as $enseignant): ?>
                                            <option value="<?= $enseignant['matricule'] ?>"><?= $enseignant['nom'] . " " . $enseignant['prenom'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    </tbody>
                </table>
                <div class="mt-4 text-center">
                    <button type="button" id="add-row" class="bg-blue-500 text-white px-4 py-2 rounded">Ajouter une ligne</button>
                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Enregistrer</button>
                    <a href="../emploi_temps.php" class="text-white bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('add-row').addEventListener('click', function () {
            const table = document.querySelector('tbody');
            const newRow = table.rows[table.rows.length - 1].cloneNode(true);
            newRow.querySelectorAll('input').forEach(input => input.value = '');
            newRow.querySelectorAll('select').forEach(select => select.selectedIndex = 0);
            table.appendChild(newRow);
        });
    </script>
</body>
</html>

<?php
require '../../../Traitement/connexion.php';

$date_aujourdhui = date("Y-m-d");

// Archiver automatiquement les fiches dont la date ne correspond plus à la date actuelle
$archive_stmt = $conn->prepare("
    UPDATE presence
    SET archive = 1
    WHERE date_presence != :date_aujourdhui AND archive = 0
");
$archive_stmt->bindParam(':date_aujourdhui', $date_aujourdhui);
$archive_stmt->execute();

// Récupérer les élèves absents (présent = 0) pour la date actuelle sans filtrer par classe
$absences_stmt = $conn->prepare("
    SELECT eleve.id AS id_eleve, eleve.nom_elev, eleve.prenom_elev, classe.nom_class, 
           presence.date_presence, presence.heure_presence, presence.annee_scolaire, employe.nom AS nom_prof
    FROM presence
    JOIN eleve ON presence.id_eleve = eleve.id
    JOIN classe ON presence.id_classe = classe.id_class
    JOIN employe ON presence.id_professeur = employe.matricule
    WHERE presence.date_presence = :date_aujourdhui 
    AND presence.present = 0
    AND presence.justifie = 0  -- Exclure les absences justifiées
    AND presence.archive = 0
    ORDER BY classe.nom_class, eleve.nom_elev
");

$absences_stmt->bindParam(':date_aujourdhui', $date_aujourdhui);
$absences_stmt->execute();
$absents = $absences_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
/* Styles pour la modal */
.modal {
    display: none; /* Masquer la modal par défaut */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Couleur de l'overlay */
}

.modal-content {
    
    margin: 10% auto; /* Décalage du haut pour mieux centrer */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Largeur de la modal */
    max-width: 80%; /* Limiter la largeur maximale */
    border-radius: 8px; /* Coins arrondis */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Ombre portée */
    position: relative;
    
}

.modal-header {
    display: flex;
    justify-content: end;
    align-items: end;
    text-align: left;
}

.modal-header h2 {
    margin: 0;
    
    color: #333; /* Couleur du texte du titre */
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

/* Styles pour le cadre bleu */
.border-blue-container {
    border: 2px solid transparent; /* Bordure par défaut cachée */
    border-color: #007bff; /* Couleur bleue */
    border-radius: 8px; /* Coins arrondis */
    padding: 16px;
    margin: 10px 0;
    transition: border-color 0.3s ease; /* Transition pour le changement de couleur */
}

.border-blue-container:not(:empty) {
    border-color: #007bff; /* Affiche la bordure bleue si le contenu n'est pas vide */
}

.border-blue-container:empty {
    display: none; /* Masquer le cadre si vide */
}
#main-content {
    max-height: 80vh; /* Par exemple, 80% de la hauteur de la vue */
    overflow-y: auto; /* Permet de défiler verticalement si nécessaire */
}
</style>
<div id="main-content">


        <div class="flex justify-end mb-4">
            <a href="presence/archives.php" class="bg-blue-500 hover:bg-green-600 text-white font-semibold py-2 my-2 px-4 sm:px-6 rounded transition-colors">
                Accéder aux fiches archivées
            </a>
        </div>

        <?php if (count($absents) === 0): ?>
            <div class="bg-white rounded shadow-md p-6 w-full max-w-md text-center">
                <h2 class="text-xl font-semibold text-gray-700 mb-4">Aucune absence pour aujourd'hui</h2>
            </div>
        <?php else: ?>
            <div class="w-full max-w-4xl mx-auto p-4 sm:p-8 bg-white shadow-lg rounded">
                <?php foreach ($absents as $eleve): ?>
                    <div class="mb-6">
                        <h3 class="text-lg font-bold text-gray-700">
                            Classe: <?php echo htmlspecialchars($eleve['nom_class']); ?> | 
                            Professeur: <?php echo htmlspecialchars($eleve['nom_prof']); ?>
                        </h3>
                        <p class="text-sm text-gray-600">
                            Date: <?php echo htmlspecialchars($eleve['date_presence']); ?> | 
                            Heure: <?php echo htmlspecialchars($eleve['heure_presence']); ?> | 
                            Année Scolaire: <?php echo htmlspecialchars($eleve['annee_scolaire']); ?>
                        </p>
                    </div>

                    <form action="../../../Traitement/secretaire/presence/justifier_absence.php" method="post">
                        <div class="overflow-x-auto">
                            <table class="min-w-full border-collapse border border-gray-200 text-left rounded overflow-hidden shadow-sm">
                                <thead>
                                    <tr class="bg-blue-500 text-white">
                                        <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">ID Élève</th>
                                        <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Nom</th>
                                        <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Justifié</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-100">
                                    <tr class="hover:bg-gray-50 transition-colors">
                                        <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                            <input type="hidden" name="id_eleve[]" value="<?php echo htmlspecialchars($eleve['id_eleve']); ?>">
                                            <?php echo htmlspecialchars($eleve['id_eleve']); ?>
                                        </td>
                                        <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center"><?php echo htmlspecialchars($eleve['nom_elev'] . ' ' . $eleve['prenom_elev']); ?></td>
                                        <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                            <input type="checkbox" name="justifie[]" value="<?php echo htmlspecialchars($eleve['id_eleve']); ?>" class="form-checkbox h-5 w-5 text-green-500">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Boutons d'action -->
                        <div class="mt-8 flex justify-center space-x-4">
                            <button type="submit" class="px-6 py-2 bg-green-500 text-white font-semibold rounded hover:bg-green-600 transition-all">
                                Justifier Absences
                            </button>
                        </div>
                    </form>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
</div>
<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');
    const resetButton = document.getElementById('reset-search');
    const searchInput = document.getElementById('topbar-search');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêche la soumission normale du formulaire
        
        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        // Afficher la modal et cacher le contenu principal
        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve/rechercher.php?search=' + encodeURIComponent(searchQuery), {
            method: 'GET',
        })
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none'; // Masquer la modal
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
    });

    // Événement pour fermer la modal en cliquant en dehors de celle-ci
    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        }
    });

    resetButton.addEventListener('click', function() {
        searchInput.value = ''; // Réinitialiser le champ de recherche
        mainContent.classList.remove('hidden'); // Réafficher le contenu principal
        resultsModal.style.display = 'none'; // Masquer la modal
        resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
    });

    searchInput.addEventListener('input', function(event) {
        if (event.target.value.trim() === '') {
            // Réinitialiser la page lorsque le champ de recherche est vide
            mainContent.classList.remove('hidden');
            resultsModal.style.display = 'none'; // Masquer la modal
            resetButton.classList.add('hidden'); // Cacher le bouton d'annulation
        }
    });
});


</script>
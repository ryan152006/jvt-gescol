<?php
require '../../../../Traitement/connexion.php';

// Récupérer les fiches archivées (archive = 1)
$archives_stmt = $conn->prepare("
    SELECT eleve.id AS id_eleve, eleve.nom_elev, eleve.prenom_elev, classe.nom_class, 
           presence.date_presence, presence.heure_presence, presence.annee_scolaire, employe.nom AS nom_prof
    FROM presence
    JOIN eleve ON presence.id_eleve = eleve.id
    JOIN classe ON presence.id_classe = classe.id_class
    JOIN employe ON presence.id_professeur = employe.matricule
    WHERE presence.archive = 1
    ORDER BY classe.nom_class, presence.date_presence DESC, eleve.nom_elev
");
$archives_stmt->execute();
$archives = $archives_stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les absents du jour (present = 0 pour la date d'aujourd'hui)
$absents_stmt = $conn->prepare("
    SELECT eleve.id AS id_eleve, eleve.nom_elev, eleve.prenom_elev, classe.nom_class, 
           presence.date_presence, presence.heure_presence, presence.annee_scolaire, employe.nom AS nom_prof, presence.justifie
    FROM presence
    JOIN eleve ON presence.id_eleve = eleve.id
    JOIN classe ON presence.id_classe = classe.id_class
    JOIN employe ON presence.id_professeur = employe.matricule
    WHERE presence.date_presence = CURDATE() 
    AND presence.present = 0
    AND presence.justifie = 0  -- Exclure les absences déjà justifiées
    ORDER BY classe.nom_class, eleve.nom_elev
");

$absents_stmt->execute();
$absents = $absents_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archives des Absences</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-blue-50 to-blue-100 min-h-screen flex items-center justify-center p-4 sm:p-8">

<div class="w-full max-w-4xl mx-auto p-4 sm:p-8 bg-white shadow-lg rounded">
<div class="text-right">
                <a href="../presence.php" class=" px-4 py-2 bg-transparent text-red-500 font-semibold  transition-colors">Retour à la page principale</a>
            </div>
    <h2 class="text-xl font-semibold text-gray-700 mb-4">Fiches Archivées</h2>
    
    <!-- Affichage des fiches archivées -->
    <?php if (count($archives) === 0): ?>
        <div class="bg-white rounded shadow-md p-6 w-full max-w-md text-center">
            <h3 class="text-xl font-semibold text-gray-700 mb-4">Aucune fiche archivée disponible</h3>
        </div>
    <?php else: ?>
        <?php foreach ($archives as $archive): ?>
            <div class="mb-6">
                <h3 class="text-lg font-bold text-gray-700">
                    Classe: <?php echo htmlspecialchars($archive['nom_class']); ?> | 
                    Professeur: <?php echo htmlspecialchars($archive['nom_prof']); ?>
                </h3>
                <p class="text-sm text-gray-600">
                    Date: <?php echo htmlspecialchars($archive['date_presence']); ?> | 
                    Heure: <?php echo htmlspecialchars($archive['heure_presence']); ?> | 
                    Année Scolaire: <?php echo htmlspecialchars($archive['annee_scolaire']); ?>
                </p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Affichage des élèves absents du jour avec l'option de justification -->


    <?php if (count($absents) === 0): ?>
        <div class="bg-white rounded shadow-md p-6 w-full max-w-md text-center">
            <h3 class="text-xl font-semibold text-gray-700 mb-4">Aucun élève absent </h3>
        </div>
    <?php else: ?>
        <?php foreach ($absents as $absent): ?>
            <div class="mb-6">
                <h3 class="text-lg font-bold text-gray-700">
                    Élève: <?php echo htmlspecialchars($absent['nom_elev']) . ' ' . htmlspecialchars($absent['prenom_elev']); ?> | 
                    Classe: <?php echo htmlspecialchars($absent['nom_class']); ?>
                </h3>
                <p class="text-sm text-gray-600">
                    Date: <?php echo htmlspecialchars($absent['date_presence']); ?> | 
                    Heure: <?php echo htmlspecialchars($absent['heure_presence']); ?> | 
                    Année Scolaire: <?php echo htmlspecialchars($absent['annee_scolaire']); ?>
                </p>
                <form method="post" action="../../../../Traitement/secretaire/presence/justifier_absence.php">
                    <input type="hidden" name="id_eleve" value="<?php echo $absent['id_eleve']; ?>">
                    <input type="hidden" name="date_presence" value="<?php echo $absent['date_presence']; ?>">
                    <label for="justifie_<?php echo $absent['id_eleve']; ?>" class="text-sm text-gray-600">
                        Justifié: 
                    </label>
                    <input type="checkbox" id="justifie_<?php echo $absent['id_eleve']; ?>" name="justifie" 
                           value="1" <?php echo $absent['justifie'] ? 'checked' : ''; ?>>
                    <button type="submit" class="ml-2 px-4 py-2 bg-blue-500 text-white rounded">Justifier</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</div>
</body>
</html>

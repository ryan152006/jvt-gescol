<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../Style/categorie.css">
    <title>Connexion</title>
</head>
<body class="bg-gray-100 dark:bg-gray-900 flex items-center justify-center min-h-screen">

<section class="w-full max-w-md sm:max-w-lg md:max-w-xl px-4">
    <div class="bg-white rounded shadow-lg dark:border dark:border-gray-700 dark:bg-gray-800 p-6">
        <div class="space-y-6">
            <h1 class="text-2xl font-medium text-gray-800 dark:text-white text-center">
                Se Connecter
            </h1>
            <form action="../../Traitement/connexion_autre_poste.php" method="post" class="space-y-4">
                <div>
                    <label for="matricule" class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Matricule</label>
                    <input type="text" name="matricule" id="matricule" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Entrer votre matricule" required>
                </div>
                <div>
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                    <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Entrer votre email" required>
                </div>
                <div>
                    <label for="poste" class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300">Poste</label>
                    <select name="poste" id="poste" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-3 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        <option selected disabled>Selectionner votre poste</option>
                        <option value="enseignant">Enseignant</option>
                        <option value="secretaire">Secrétaire</option>
                        <option value="caissiere">Econome</option>
                        <option value="surveillantgeneral">Surveillant Général</option>
                        <option value="prefet_des_etudes">Préfet des Études</option>
                    </select>
                </div>
                <button type="submit" class="w-full text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-5 py-2.5 dark:bg-blue-700 dark:focus:ring-blue-800">
                    Connexion
                </button>
                <small class="block text-center text-gray-600 dark:text-gray-400 mt-4">
                    <a href="../categorie.html" class="text-red-500 underline">Retour</a>
                </small>
            </form>
        </div>
    </div>
</section>

</body>
</html>

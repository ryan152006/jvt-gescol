<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT i.id, i.id_elev, i.id_class, i.date, i.annee_scolaire, i.incident, e.nom_elev, e.prenom_elev, c.nom_class
                                    FROM incident_disc i 
                                    JOIN eleve e ON i.id_elev = e.id
                                    JOIN classe c ON i.id_class = c.id_class
          WHERE e.nom_elev LIKE :search OR e.prenom_elev LIKE :search ORDER BY e.nom_elev asc";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$incident = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mx-auto w-full overflow-x-hidden justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full flex flex-col space-y-4 md:space-y-0 items-center justify-center">
        <div class="py-3 w-full justify-center items-center">
            <span class="border border-blue-500 rounded p-2 text-2xl md:text-3xl text-white text-center flex justify-center items-center font-semibold mx-auto py-4 bg-blue-500">
                Résultats de la Recherche
            </span>
            <div class="w-full overflow-x-auto">
        <table class="min-w-full text-sm text-center text-gray-500 dark:text-gray-400">
            <thead class="bg-gray-50 dark:bg-gray-700 text-xs text-gray-700 dark:text-gray-400">
                <tr>
                    <th class="px-2 py-3">Date</th>
                    <th class="px-2 py-3">Année Scolaire</th>
                    <th class="px-2 py-3">Noms</th>
                    <th class="px-2 py-3">Prénoms</th>
                    <th class="px-2 py-3">Incident Commis</th>
                    <th class="px-2 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($incident as $inc): ?>
                <tr class="border-b dark:border-gray-700">
                    <td class="px-2 py-3 max-w-[8rem] truncate"><?php echo htmlspecialchars($inc['date']); ?></td>
                    <td class="px-2 py-3 max-w-[8rem] truncate"><?php echo htmlspecialchars($inc['annee_scolaire']); ?></td>
                    <td class="px-2 py-3 max-w-[8rem] truncate"><?php echo htmlspecialchars($inc['nom_elev']); ?></td>
                    <td class="px-2 py-3 max-w-[8rem] truncate"><?php echo htmlspecialchars($inc['prenom_elev']); ?></td>
                    <td class="px-2 py-3 max-w-[8rem] truncate"><?php echo htmlspecialchars($inc['incident']); ?></td>
                    <td class="px-2 py-3 flex justify-center space-x-3">
                        <a href="ins_disc/modifier.php?id=<?php echo urlencode($inc['id']); ?>" class="text-green-500 hover:text-green-700">
                            <button class="text-xs">Modifier</button>
                        </a>
                        <a href="ins_disc/consulter.php?id=<?php echo urlencode($inc['id']); ?>" class="text-blue-500 hover:text-blue-700">
                            <button class="text-xs">Consulter</button>
                        </a>
                        <a href="../../../Traitement/surveillantgeneral/incident/delete.php?id=<?php echo urlencode($inc['id']); ?>" class="text-red-500 hover:text-red-700" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet incident ?');">
                            <button class="text-xs">Supprimer</button>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
        </div>
    </div>
</div>

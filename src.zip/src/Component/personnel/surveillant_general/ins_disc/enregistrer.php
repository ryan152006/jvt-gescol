<?php
include '../../../../Traitement/connexion.php'; // Inclure le fichier de connexion

// Requête pour obtenir les élèves et les classes
$eleves = $conn->query("SELECT id, nom_elev, prenom_elev FROM eleve ORDER BY nom_elev")->fetchAll(PDO::FETCH_ASSOC);
$classes = $conn->query("SELECT id_class, nom_class FROM classe ORDER BY nom_class")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Enregistrer un Incident de Discipline</title>
</head>
<body class="bg-gray-100">

<div class="max-w-3xl mx-auto mt-10 p-6 bg-white rounded shadow-md">
    <h1 class="text-2xl font-semibold text-center text-blue-500">Enregistrer un Incident de Discipline</h1>
    <form action="../../../../Traitement/surveillantgeneral/incident/traiter_incident.php" method="POST" class="space-y-4 mt-4">
        
        <!-- Sélection élève -->
        <div>
            <label for="id_elev" class="block text-sm font-medium text-gray-700">Élève</label>
            <select name="id_elev" id="id_elev" class="block w-full px-3 py-2 border border-gray-300 rounded">
            <option value="" selected>Selectionner un eleve</option>
            <?php foreach ($eleves as $eleve): ?>
                <option value="<?= htmlspecialchars($eleve['id']); ?>">
                    <?= htmlspecialchars($eleve['nom_elev'] . " " . $eleve['prenom_elev']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Sélection classe -->
        <div>
            <label for="id_class" class="block text-sm font-medium text-gray-700">Classe</label>
            <select name="id_class" id="id_class" class="block w-full px-3 py-2 border border-gray-300 rounded">
            <option value="" selected>Selectionner une classe</option>
            <?php foreach ($classes as $classe): ?>
                    
                <option value="<?= htmlspecialchars($classe['id_class']); ?>">
                    <?= htmlspecialchars($classe['nom_class']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Date -->
        <div>
            <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
            <input type="date" name="date" id="date" class="block w-full px-3 py-2 border border-gray-300 rounded" required>
        </div>

        <!-- Année Scolaire -->
        <div>
            <label for="annee_academique" class="block text-sm font-medium text-gray-700">Année Scolaire</label>
            <input type="text" name="annee_academique" id="annee_academique" value="2024/2025" class="block w-full px-3 py-2 border border-gray-300 rounded" readonly>
        </div>

        <!-- Incident -->
        <div>
            <label for="incident" class="block text-sm font-medium text-gray-700">Description de l'incident</label>
            <textarea name="incident" id="incident" rows="4" class="block w-full px-3 py-2 border border-gray-300 rounded" required></textarea>
        </div>

        <!-- Bouton de soumission -->
        <div class="text-center flex-1 space-x-6">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none">Enregistrer</button>
            
            <a href="../ins_disc.php" class="text-red-500 hover:text-red-700">Retour </a>
           
        </div>

    </form>
</div>

</body>
</html>

<?php
include '../../../../Traitement/connexion.php'; // Inclure le fichier de connexion

// Vérifier si l'ID est passé en paramètre
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Requête pour récupérer les informations de l'incident
    $stmt = $conn->prepare("SELECT i.id, i.date, i.annee_scolaire, i.incident, e.nom_elev, e.prenom_elev, c.nom_class 
                            FROM incident_disc i 
                            JOIN eleve e ON i.id_elev = e.id
                            JOIN classe c ON i.id_class = c.id_class
                            WHERE i.id = ?");
    $stmt->execute([$id]);
    $incident = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    // Si aucun ID n'est passé, rediriger vers la page principale
    header("Location: ../ins_disc.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Consultation d'Incident</title>
</head>
<body class="bg-gray-100">
<div class="max-w-3xl mx-auto mt-10 p-6 bg-white rounded shadow-md">
    <h1 class="text-2xl font-semibold text-center text-blue-500">Détails de l'Incident</h1>
    
    <div class="space-y-4 mt-4">
        <div>
            <label class="block text-sm font-medium text-gray-700">Nom de l'élève</label>
            <p class="block w-full px-3 py-2 bg-gray-100 rounded-md"><?= htmlspecialchars($incident['nom_elev'] . ' ' . $incident['prenom_elev']); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Classe</label>
            <p class="block w-full px-3 py-2 bg-gray-100 rounded-md"><?= htmlspecialchars($incident['nom_class']); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Date</label>
            <p class="block w-full px-3 py-2 bg-gray-100 rounded-md"><?= htmlspecialchars($incident['date']); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Année Scolaire</label>
            <p class="block w-full px-3 py-2 bg-gray-100 rounded-md"><?= htmlspecialchars($incident['annee_scolaire']); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Description de l'incident</label>
            <p class="block w-full px-3 py-2 bg-gray-100 rounded-md"><?= htmlspecialchars($incident['incident']); ?></p>
        </div>

        <div class="text-center mt-4">
            <a href="../ins_disc.php" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Retour à la liste</a>
        </div>
    </div>
</div>
</body>
</html>

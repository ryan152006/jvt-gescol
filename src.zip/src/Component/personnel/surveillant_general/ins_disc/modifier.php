<?php
include '../../../../Traitement/connexion.php'; // Inclure le fichier de connexion

// Vérifier si l'ID est passé en paramètre
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Récupérer l'incident à modifier
    $stmt = $conn->prepare("SELECT * FROM incident_disc WHERE id = ?");
    $stmt->execute([$id]);
    $incident = $stmt->fetch(PDO::FETCH_ASSOC);

    // Récupérer les élèves et les classes pour remplir les sélections
    $eleves = $conn->query("SELECT id, nom_elev, prenom_elev FROM eleve")->fetchAll(PDO::FETCH_ASSOC);
    $classes = $conn->query("SELECT id_class, nom_class FROM classe")->fetchAll(PDO::FETCH_ASSOC);

    // Si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Récupérer les données du formulaire
        $id_elev = $_POST['id_elev'];
        $id_class = $_POST['id_class'];
        $date = $_POST['date'];
        $annee_scolaire = $_POST['annee_scolaire'];
        $incident_desc = $_POST['incident']; // Renommer la variable pour éviter les conflits

        // Préparer la requête de mise à jour
        $stmt = $conn->prepare("UPDATE incident_disc SET id_elev = ?, id_class = ?, date = ?, annee_scolaire = ?, incident = ? WHERE id = ?");
        $stmt->execute([$id_elev, $id_class, $date, $annee_scolaire, $incident_desc, $id]);

        // Rediriger vers la page principale après modification
        header("Location: ../ins_disc.php");
        exit;
    }
} else {
    // Si aucun ID n'est passé, rediriger vers la page principale
    header("Location: ../ins_disc.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Modifier un Incident</title>
</head>
<body class="bg-gray-100">
<div class="max-w-3xl mx-auto mt-10 p-6 bg-white rounded shadow-md">
    <h1 class="text-2xl font-semibold text-center text-blue-500">Modifier un Incident de Discipline</h1>
    <form action="" method="POST" class="space-y-4 mt-4">

        <!-- Sélection élève -->
        <div>
            <label for="id_elev" class="block text-sm font-medium text-gray-700">Élève</label>
            <select name="id_elev" id="id_elev" class="block w-full px-3 py-2 border border-gray-300 rounded-md">
                <?php foreach ($eleves as $eleve): ?>
                <option value="<?= htmlspecialchars($eleve['id']); ?>" <?= $incident['id_elev'] == $eleve['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($eleve['nom_elev'] . " " . $eleve['prenom_elev']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Sélection classe -->
        <div>
            <label for="id_class" class="block text-sm font-medium text-gray-700">Classe</label>
            <select name="id_class" id="id_class" class="block w-full px-3 py-2 border border-gray-300 rounded-md">
                <?php foreach ($classes as $classe): ?>
                <option value="<?= htmlspecialchars($classe['id_class']); ?>" <?= $incident['id_class'] == $classe['id_class'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($classe['nom_class']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Date -->
        <div>
            <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
            <input type="date" name="date" id="date" class="block w-full px-3 py-2 border border-gray-300 rounded-md" value="<?= htmlspecialchars($incident['date']); ?>" required>
        </div>

        <!-- Année Scolaire -->
        <div>
            <label for="annee_scolaire" class="block text-sm font-medium text-gray-700">Année Scolaire</label>
            <input type="text" name="annee_scolaire" id="annee_scolaire" value="<?= htmlspecialchars($incident['annee_scolaire']); ?>" class="block w-full px-3 py-2 border border-gray-300 rounded-md" required>
        </div>

        <!-- Incident -->
        <div>
            <label for="incident" class="block text-sm font-medium text-gray-700">Description de l'incident</label>
            <textarea name="incident" id="incident" rows="4" class="block w-full px-3 py-2 border border-gray-300 rounded-md" required><?= htmlspecialchars($incident['incident']); ?></textarea>
        </div>

        <!-- Bouton de soumission -->
        <div class="text-center flex-1 space-x-6">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 focus:outline-none">Modifier</button>
            
            <a href="../ins_disc.php" class="text-red-500 hover:text-red-700">Retour </a>
           
        </div>

    </form>
</div>
</body>
</html>

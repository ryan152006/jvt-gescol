<nav class="border-gray-800 dark:bg-gray-900 w-screen border-b-2">
  <div class="max-w-screen-x flex flex-wrap items-center justify-between mx-auto p-4">
  <div class="flex items-center space-x-2 rtl:space-x-reverse">
      <img src="../../../Assets/logo.png" class="h-10 rounded-full"  />
      <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">JVT-GESCOL</span>
</div>
  <div class="flex ">
    <button type="button" data-collapse-toggle="navbar-search" aria-controls="navbar-search" aria-expanded="false" class="md:hidden text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-2.5 me-1">
      <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
      </svg>
      <span class="sr-only">Search</span>
    </button>
    <div class="w-full md:w-1/2">
    <form action="eleve_list/rechercher.php" id="search-form" method="GET" class="">
    <label for="topbar-search" class="sr-only">Search</label>
    <div class="relative mt-1 lg:w-96">
        <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
            <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
            </svg>
        </div>
        <input type="search" name="search" id="topbar-search" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-500 focus:border-primary-500 block w-full pl-9 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Rechercher un eleve...">
    </div>
    </form>
        </div>
    <button data-collapse-toggle="navbar-search" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-search" aria-expanded="false">
        <span class="sr-only">Open main menu</span>
        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
        </svg>
    </button>
  </div>
    <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-search">
      <div class="relative mt-4 md:hidden">
        <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
          <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
          </svg>
        </div>
        <input type="text" id="search-navbar" class="block w-full p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search...">
      </div>
      <div class="flex flex-row p-4 md:p-0 mt-4 mx-[0px] font-medium  text-left  md:space-x-2 rtl:space-x-reverse md:flex-row md:mt-0 ">
        <span class="text-lg text-gray-300 font-normal text-left items-center"><?php echo htmlspecialchars($secr['nom']).' ' ; echo htmlspecialchars($secr['prenom']); ?></span>
       

        <svg fill="#000000" class="flex-shrink-0 w-7 h-7 rounded-full text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 32 32" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;" version="1.1" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:serif="http://www.serif.com/" xmlns:xlink="http://www.w3.org/1999/xlink">

          <g transform="matrix(1,0,0,1,0,-96)">

          <g transform="matrix(0.923077,0,0,1,-2.92308,-1)">

          <circle cx="20.5" cy="105.5" r="6.5" style="fill:rgb(144,224,239);"/>

          </g>

          <g transform="matrix(0.952381,0,0,1.0101,0.285714,-1.27273)">

          <ellipse cx="16.5" cy="120.5" rx="10.5" ry="5.5" style="fill:rgb(144,224,239);"/>

          </g>

          <path d="M16,113.889C12.437,113.889 9.285,114.883 7.327,116.367C5.83,117.501 5,118.932 5,120.444C5,121.957 5.83,123.388 7.327,124.522C9.285,126.006 12.437,127 16,127C19.563,127 22.715,126.006 24.673,124.522C26.17,123.388 27,121.957 27,120.444C27,118.932 26.17,117.501 24.673,116.367C22.715,114.883 19.563,113.889 16,113.889ZM16,115.889C19.06,115.889 21.783,116.687 23.466,117.961C24.396,118.667 25,119.504 25,120.444C25,121.385 24.396,122.222 23.466,122.928C21.783,124.202 19.06,125 16,125C12.94,125 10.217,124.202 8.534,122.928C7.604,122.222 7,121.385 7,120.444C7,119.504 7.604,118.667 8.534,117.961C10.217,116.687 12.94,115.889 16,115.889ZM16,97C12.159,97 9,100.339 9,104.5C9,108.661 12.159,112 16,112C19.841,112 23,108.661 23,104.5C23,100.339 19.841,97 16,97ZM16,99C18.783,99 21,101.486 21,104.5C21,107.514 18.783,110 16,110C13.217,110 11,107.514 11,104.5C11,101.486 13.217,99 16,99Z" style="fill:rgb(25,144,167);"/>

          </g>

          </svg>
      </div>
    </div>
  </div>
</nav>

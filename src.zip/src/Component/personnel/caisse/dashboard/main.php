
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
<div id="main-content" class="flex flex-col space-y-1 md:space-y-0 md:flex-row mx-2 sm:mx-4 md:mx-14 items-center justify-between py-2 md:py-14">
    <div class="block w-full md:w-1/4 flex flex-col rounded p-4 sm:p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700 dark:hover:bg-gray-700">
        <div>
            <h4 class="text-center text-base sm:text-lg md:text-xl font-normal text-gray-700 dark:text-white">Localisation</h4>
            <span class="text-blue-500 text-center text-lg sm:text-xl md:text-2xl font-bold">EFok-Obala</span>
        </div>
    </div>
    <div class="block w-full md:w-1/4 flex flex-col rounded p-4 sm:p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700 dark:hover:bg-gray-700">
        <div>
            <h4 class="text-center text-base sm:text-lg md:text-xl font-normal text-gray-700 dark:text-white">Numéro de Téléphone</h4>
            <span class="text-blue-500 text-center text-lg sm:text-xl md:text-2xl font-bold">677600537 / 672220030</span>
        </div>
    </div>
    <div class="block w-full md:w-1/4 flex flex-col rounded p-4 sm:p-6 bg-white shadow hover:bg-gray-100 dark:bg-gray-600 dark:border-gray-700 dark:hover:bg-gray-700">
        <div>
            <h4 class="text-center text-base sm:text-lg md:text-xl font-normal text-gray-700 dark:text-white">Année Scolaire</h4>
            <span class="text-blue-500 text-center text-lg sm:text-xl md:text-2xl font-bold">2024/2025</span>
        </div>
    </div>
</div>

<div class="flex flex-col justify-center items-center ">
    <div class="flex flex-row space-x-2 sm:space-x-4 uppercase mx-2 sm:mx-4 p-2 sm:p-3">
        <svg class="w-8 sm:w-10 h-8 sm:h-10" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path d="..."></path></svg>
        <span class="self-center font-normal text-base sm:text-lg md:text-3xl text-blue-500"><?php echo date("l, d-m-Y"); ?></span>
    </div>
    <div class="flex flex-row items-center justify-center space-x-2 sm:space-x-3">
        <span class="text-center text-xl sm:text-2xl md:text-4xl font-normal uppercase dark:text-white">Collège <span class="text-blue-500">JEAN XXIII D'EFOK</span></span>
    </div>
    <p class="text-center text-gray-400 text-xs sm:text-sm md:text-lg py-1   sm:py-2 uppercase">Verus et Sedulus</p>
    <div class="flex justify-center items-center">
        <img src="../../../Assets/logoecole.jpg" class="w-16 sm:w-20 h-16 sm:h-20 md:w-36 md:h-36 rounded-full object-cover" alt="Logo de l'école">
    </div>
</div>

<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve_list/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>

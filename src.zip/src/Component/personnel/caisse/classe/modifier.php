<?php
require_once '../../../../Traitement/connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["libelle"], $_POST["effectif"], $_POST["professeur"], $_POST["description"])) {
        
        // Récupération des données du formulaire
        $libelle = $_POST["libelle"];
        $effectif = $_POST["effectif"];
        $professeur = $_POST["professeur"];
        $description = $_POST["description"];
        $id = $_GET['id']; // Assurez-vous que l'ID est bien récupéré

        // Préparation de la requête SQL pour la mise à jour
        $request = $conn->prepare("UPDATE classe SET nom_class = :libelle, nbre_elev = :effectif,
        nom_enseig = :professeur, description = :description WHERE id_class = :id");

        // Liaison des paramètres
        $request->bindParam(':libelle', $libelle);
        $request->bindParam(':effectif', $effectif);
        $request->bindParam(':professeur', $professeur);
        $request->bindParam(':description', $description);
        $request->bindParam(':id', $id);

        // Exécution de la requête
        try {
            $request->execute();
            header("Location: ../classe.php");
            exit();
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}

$id = $_GET['id'] ?? null;
$row = null;
if ($id) {
    $request = $conn->prepare("SELECT * FROM classe WHERE id_class = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Modifier Classe</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Modifier les Informations de Classe
                </h1>
                <?php if ($row) : ?>
                    <?php
  

  // Préparer et exécuter la requête
// Préparer et exécuter la requête
$sltm = $conn->prepare("SELECT COUNT(id) AS total FROM eleve WHERE id_class = :id_class");
$sltm->bindParam(":id_class", $row['id_class']);
$sltm->execute();

// Récupérer le résultat
$count = $sltm->fetch(PDO::FETCH_ASSOC);

// Afficher le nombre total d'ID    


?>
                <form id="registration-form" method="post" class="space-y-2 sm:space-y-4">
                    <!-- Informations sur la Classe -->
                    <fieldset id="class-info" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations sur la Classe</legend>
                        <!-- Libellé -->
                        <div class="flex flex-col">
                            <label for="libelle" class="block text-sm font-normal text-gray-900 dark:text-white">Libellé</label>
                            <input type="text" name="libelle" id="libelle" placeholder="Ex: Mathématiques" value="<?= htmlspecialchars($row['nom_class']) ?>" title="Entrez le libellé de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Effectif -->
                        <div class="flex flex-col">
                            <label for="effectif" class="block text-sm font-normal text-gray-900 dark:text-white">Effectif</label>
                            <input type="number" name="effectif" id="effectif" placeholder="Ex: 30" value="<?= $count['total'] ?>" title="Entrez l'effectif de la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Professeur -->
                        <div class="flex flex-col">
                            <label for="professeur" class="block text-sm font-normal text-gray-900 dark:text-white">Professeur</label>
                            <input type="text" name="professeur" id="professeur" placeholder="Ex: M. Dupont" value="<?= htmlspecialchars($row['nom_enseig']) ?>" title="Entrez le nom du professeur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Description -->
                        <div class="flex flex-col">
                            <label for="description" class="block text-sm font-normal text-gray-900 dark:text-white">Description</label>
                            <textarea name="description" id="description" placeholder="Ex: Classe dédiée aux cours de mathématiques avancés" title="Entrez une description pour la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required><?= htmlspecialchars($row['description']) ?></textarea>
                        </div>
                    </fieldset>
                    <!-- Boutons -->
                    <div class="flex justify-between items-center mt-4">
                        <button type="submit" id="submit-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-normal rounded text-xl px-8 py-2 text-center dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-700">
                            Enregistrer
                        </button>
                        <a href="../classe.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                </form>
                <?php else : ?>
                    <p>Aucune classe trouvée avec cet ID.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</body>
</html>

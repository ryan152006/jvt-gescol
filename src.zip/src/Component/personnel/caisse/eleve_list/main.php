<?php
require '../../../Traitement/connexion.php'; 

$query = "SELECT e.code_elev, e.id, e.nom_elev, e.prenom_elev, e.sexe_elev, e.date_naiss, e.lieu_naiss, e.telephone, e.nationalite, c.nom_class AS classe, e.sexe_elev, e.telephone 
          FROM eleve e
          JOIN classe c ON e.id_class = c.id_class ORDER BY nom_elev asc";
$stmt = $conn->prepare($query);
$stmt->execute();
$eleves = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>

<div id="main-content" class="container mx-auto p-4">
    <div class="w-full flex flex-col space-y-4">
        <div class="text-center bg-blue-700 text-white text-2xl font-semibold py-4 rounded">
            Liste des Eleves du Collège <br> 
            <span class="text-blue-300">JEAN XXIII D'EFOK</span>
        </div>

        <div class="w-full flex justify-end">
            <a href="eleve_list/enregistrer.php">
                <button class="bg-blue-700 text-white px-4 py-2 rounded-md hover:bg-blue-800">+ Enregistrer un nouvel élève</button>
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full bg-white">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left">Matricule</th>
                        <th class="py-3 px-6 text-left">Nom</th>
                        <th class="py-3 px-6 text-left">Prénom</th>
                        <th class="py-3 px-6 text-left">Date Naiss</th>
                        <th class="py-3 px-6 text-left">Lieu Naiss</th>
                        <th class="py-3 px-6 text-left">Sexe</th>
                        <th class="py-3 px-6 text-left">Téléphone</th>
                        <th class="py-3 px-6 text-left">Nationalité</th>
                        <th class="py-3 px-6 text-left">Classe</th>
                        <th class="py-3 px-6 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                    <?php foreach ($eleves as $eleve): ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo htmlspecialchars($eleve['code_elev']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['nom_elev']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['prenom_elev']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['date_naiss']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['lieu_naiss']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['sexe_elev']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['telephone']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['nationalite']); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($eleve['classe']); ?></td>
                            <td class="py-3 px-6 text-left flex space-x-3">
                                <a href="eleve_list/modifier.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-green-500">Modifier</a>
                                <a href="eleve_list/consulter.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-blue-500">Consulter</a>
                                <a href="../../../Traitement/caisse/delete.php?id=<?php echo urlencode($eleve['id']); ?>" class="text-red-500" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet élève ?');">Supprimer</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve_list/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>

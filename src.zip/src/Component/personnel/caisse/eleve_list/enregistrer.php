<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Enregistrement</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-xl font-medium text-blue-500 text-center  dark:text-blue-400">
                    Enregistrer Un Nouvel Élève
                </h1>

                <form id="registration-form" action="../../../../Traitement/caisse/enregistrer.php" method="post" class=" ">
                    <!-- Informations Personnelles -->
                    <fieldset id="personal-info" class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Personnelles</legend>
                        <!-- Nom -->
                        <div class="flex flex-col">
                            <label for="nom" class="block text-sm font-normal text-gray-900 dark:text-white">Nom</label>
                            <input type="text" name="nom" id="nom" placeholder="Ex: Dupont" title="Entrez le nom de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Prénom -->
                        <div class="flex flex-col">
                            <label for="prenom" class="block text-sm font-normal text-gray-900 dark:text-white">Prénom</label>
                            <input type="text" name="prenom" id="prenom" placeholder="Ex: Marie" title="Entrez le prénom de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Date de Naissance -->
                        <div class="flex flex-col">
                            <label for="date" class="block text-sm font-normal text-gray-900 dark:text-white">Date de Naissance</label>
                            <input type="date" name="date" id="date" placeholder="JJ/MM/AAAA" title="Sélectionnez la date de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Lieu de Naissance -->
                        <div class="flex flex-col">
                            <label for="lieu" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Naissance</label>
                            <input type="text" name="lieu" id="lieu" placeholder="Ex: Paris" title="Entrez le lieu de naissance de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <!-- Sexe -->
                        <div class="flex flex-col">
                            <label for="sexe" class="block text-sm font-normal text-gray-900 dark:text-white">Sexe</label>
                            <select name="sexe" id="sexe" title="Sélectionnez le sexe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled class="text-gray-500">Sélectionnez</option>
                                <option value="masculin">Masculin</option>
                                <option value="feminin">Féminin</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="nationalite" class="block text-sm font-normal text-gray-900 dark:text-white">Nationalité</label>
                            <input type="text" name="nationalite" id="nationalite" placeholder="EX:Cameroun" title="Entrer la nationalité de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="telephone" class="block text-sm font-normal text-gray-900 dark:text-white">Téléphone</label>
                            <input type="tel" name="telephone" id="telephone" placeholder="Ex: 6 23 45 67 89" title="Entrez le numéro de téléphone de l'élève" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="religion" class="block text-sm font-normal text-gray-900 dark:text-white">Religion</label>
                            <select name="religion" id="religion" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled class="text-gray-500">Selectionner la religion de l'eleve</option>
                                <option value="catholique">Catholique</option>
                                <option value="protestant">Protestant</option>
                                <option value="musulman">Musulman</option>
                                <option value="orthodoxe">Orthodoxe</option>
                                <option value="avantiste">Advantiste</option>
                                <option value="temoin_Jehovah">Temoin de Jehovah</option>
                                <option value="pentecotiste">Pentecotiste</option>
                                <option value="autre">Autre</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="ethnie" class="block text-sm font-normal text-gray-900 dark:text-white">Ethnie</label>
                            <input type="text" name="ethnie" id="ethnie" placeholder="Ex: saisissez la ethnie" title="Entrez la ethnie de l'eleve" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="baptise" class="block text-sm font-normal text-gray-900 dark:text-white">Baptisé</label>
                       
                            <select name="baptise" id="baptise" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="1">Oui</option>
                                <option value="0">Non</option>
                            </select>
                            </div>    
                        <div class="flex flex-col">
                            <label for="communie" class="block text-sm font-normal text-gray-900 dark:text-white">Communié</label>
                            <select name="communie" id="communie" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="1">Oui</option>
                                <option value="0">Non</option>
                            </select>
                            </div>
                        <div class="flex flex-col">
                            <label for="confirme" class="block text-sm font-normal text-gray-900 dark:text-white">Confirmé</label>
                            <select name="confirme" id="confirme" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="1">Oui</option>
                                <option value="0">Non</option>
                            </select>
                            </div>
                    </fieldset>

                    <!-- Informations Secondaires -->
                    <fieldset id="secondary-info" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <legend class="text-lg font-semibold text-gray-900 dark:text-white">Informations Secondaires</legend>
                        <!-- Téléphone -->
                        <div class="flex flex-col">
                            <label for="classe" class="block text-sm font-normal text-gray-900 dark:text-white">Classe</label>
                            <select name="classe" id="classe" title="Sélectionnez la classe" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="" selected disabled>Selectionner la classe</option>
                                <?php
                                
                                require '../../../../Traitement/connexion.php';
                                $query = "SELECT id_class, nom_class FROM classe";
                                $stmt = $conn->prepare($query);
                                $stmt->execute();
                                $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                // Générer les options du menu déroulant
                                foreach ($classes as $classe) {
                                    echo "<option value=\"{$classe['nom_class']}\">{$classe['nom_class']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <!-- Catégorie -->
                        <div class="flex flex-col">
                            <label for="categorie" class="block text-sm font-normal text-gray-900 dark:text-white">Catégorie de l'élève</label>
                            <select name="categorie" id="categorie" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                                <option value="nouveau" selected disabled class="text-gray-500">Ancien ou Nouveau</option>
                                <option value="ancien">Ancien</option>
                                <option value="nouveau">Nouveau</option>
                            </select>
                        </div>
                        <div class="flex flex-col">
                            <label for="mere" class="block text-sm font-normal text-gray-900 dark:text-white">Nom de la Mère</label>
                            <input type="text" name="mere" id="mere" placeholder="Ex: Eveline" title="Entrez le nom de la Mère" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="telmere" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone de la Mère</label>
                            <input type="tel" name="telmere" id="telmere" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone de la Mère" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="pere" class="block text-sm font-normal text-gray-900 dark:text-white">Nom du Père</label>
                            <input type="text" name="pere" id="pere" placeholder="Ex: Pierre" title="Entrez le nom du Père" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="telpere" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone du Père</label>
                            <input type="tel" name="telpere" id="telpere" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone du Père" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="tuteur" class="block text-sm font-normal text-gray-900 dark:text-white">Nom du Tuteur</label>
                            <input type="text" name="tuteur" id="tuteur" placeholder="Ex: Martin" title="Entrez le nom du tuteur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="teltuteur" class="block text-sm font-normal text-gray-900 dark:text-white">Telephone du Tuteur</label>
                            <input type="tel" name="teltuteur" id="teltuteur" placeholder="Ex: 6 53 45 67 89" title="Entrez le numéro de téléphone du tuteur" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Classe -->
                       
                        <div class="flex flex-col">
                            <label for="lieu_res" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Residence de l'éleve</label>
                            <input type="text" name="lieu_res" id="lieu_res" placeholder="Ex: Efok" title="Entrez le lieu de residence de l'eleve" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                            <label for="lieu_res_par" class="block text-sm font-normal text-gray-900 dark:text-white">Lieu de Residence des parents</label>
                            <input type="text" name="lieu_res_par" id="lieu_res_par" placeholder="Ex: Efok" title="Entrez le lieu de residence des parents" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <!-- Personne à Prévenir -->
                        <div class="flex flex-col">
                            <label for="dernier_etab" class="block text-sm font-normal text-gray-900 dark:text-white">Dernier Etablissement Frequenté</label>
                            <input type="text" name="dernier_etab" id="dernier_etab" placeholder="Ex: College ..." title="Entrez le Dernier Etablissement Frequenté" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" >
                        </div>
                        <div class="flex flex-col">
                        <label for="antecedent" class="block text-sm font-normal text-gray-900 dark:text-white">Antécédant de santé</label>
                        <textarea name="antecedent" id="antecedent" row="4" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                        </div>
                    </fieldset>


                    <!-- Boutons -->
                    <div class="flex justify-between items-center mt-1">
                        <button type="button" id="next-button" class="text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-normal rounded text-sm px-8 py-1 text-center dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-blue-700 disabled">
                            Suivant
                        </button>
                        <button type="button" id="previous-button" class="hidden text-white bg-transparent hover:bg-gray-600  border-2 border-gray-400 hover:bg-gray-600  focus:outline-none  font-normal rounded text-sm px-8 py-1 text-center dark:focus:ring-blue-700">
                            Précédesm
                        </button>
                        <button type="submit" id="submit-button" class="hidden text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-sm px-8 py-1 text-center   dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../eleve_list.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-sm px-8 py-1 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2">Veuillez remplir tous les champs pour enregistrer un nouvel élève!</small>
                </form>
            </div>
        </div>
    </section>

    <script>
        const personalInfoFieldset = document.getElementById('personal-info');
        const secondaryInfoFieldset = document.getElementById('secondary-info');
        
        const nextButton = document.getElementById('next-button');
        const previousButton = document.getElementById('previous-button');
        const submitButton = document.getElementById('submit-button');

        function validatePersonalInfo() {
            // Sélectionner tous les champs requis dans le fieldset d'informations personnelles
            const requiredFields = personalInfoFieldset.querySelectorAll('input[required], select[required]');
            // Vérifier si tous les champs sont remplis
            return Array.from(requiredFields).every(field => field.value.trim() !== '');
        }

        function toggleNextButton() {
            if (validatePersonalInfo()) {
                nextButton.classList.remove('disabled');
                nextButton.disabled = false;
            } else {
                nextButton.classList.add('disabled');
                nextButton.disabled = true;
            }
        }

        // Ajouter des écouteurs d'événements pour surveiller les changements dans les champs
        personalInfoFieldset.addEventListener('input', toggleNextButton);

        nextButton.addEventListener('click', () => {
            if (validatePersonalInfo()) {
                personalInfoFieldset.classList.add('hidden');
                secondaryInfoFieldset.classList.remove('hidden');
                nextButton.classList.add('hidden');
                previousButton.classList.remove('hidden');
                submitButton.classList.remove('hidden');
            }
        });

        previousButton.addEventListener('click', () => {
            personalInfoFieldset.classList.remove('hidden');
            secondaryInfoFieldset.classList.add('hidden');
            nextButton.classList.remove('hidden');
            previousButton.classList.add('hidden');
            submitButton.classList.add('hidden');
        });

        // Initialiser le bouton "Suivant" lors du chargement de la page
        toggleNextButton();

        document.addEventListener("DOMContentLoaded", function() {
        const baptiseSelect = document.getElementById("baptise");
        const communieSelect = document.getElementById("communie");
        const confirmeSelect = document.getElementById("confirme");

        function toggleCommunieAndConfirme() {
            if (baptiseSelect.value == "0") {
                communieSelect.disabled = true;
                confirmeSelect.disabled = true;
                communieSelect.classList.add("disabled");
                confirmeSelect.classList.add("disabled");
            } else {
                communieSelect.disabled = false;
                communieSelect.classList.remove("disabled");
                toggleConfirme();  // Update confirmed state based on communie
            }
        }

        function toggleConfirme() {
            if (communieSelect.value == "0") {
                confirmeSelect.disabled = true;
                confirmeSelect.classList.add("disabled");
            } else {
                confirmeSelect.disabled = false;
                confirmeSelect.classList.remove("disabled");
            }
        }

        // Initial check when the page loads
        toggleCommunieAndConfirme();

        // Add event listeners
        baptiseSelect.addEventListener("change", toggleCommunieAndConfirme);
        communieSelect.addEventListener("change", toggleConfirme);
    });
    </script>
</body>
</html>

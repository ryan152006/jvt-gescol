<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
<div id="main-content" class="w-full max-w-2xl pb-2 mx-4 md:mx-8 my-6 border border-blue-500 rounded shadow hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700 overflow-hidden">
    <div class="w-full justify-between items-center">
        <div class="flex flex-col items-center justify-center">
           <h4 class="text-center py-4 text-2xl font-bold text-blue-500">College Bilingue JEAN XXIII D'EFOK</h4>
           <h2 class="text-xl text-center font-medium text-white">Compte Personnel</h2>
        </div>
    </div>

    <div class="mx-4 md:mx-8">
        <!-- Nom et Prenom -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="nom">Nom</label>
              <p id="nom" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['nom']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="prenom">Prenom</label>
              <p id="prenom" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['prenom']); ?></p>
          </div>
        </div>

        <!-- Email et Telephone -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="email">Email</label>
              <p id="email" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['email']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="telephone">Telephone</label>
              <p id="telephone" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['telephone']); ?></p>
          </div>
        </div>

        <!-- Matricule et Poste -->
        <div class="flex flex-col md:flex-row md:space-x-14">
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="matricule">Matricule</label>
              <p id="matricule" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['matricule']); ?></p>
          </div>
          <div class="mb-4 md:mb-2">
              <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="poste">Poste</label>
              <p id="poste" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['poste']); ?></p>
          </div>
        </div>

        <!-- Sexe -->
        <div class="mb-4 md:mb-2">
            <label class="block text-gray-200 text-lg md:text-xl font-medium mb-2" for="sexe">Sexe</label>
            <p id="sexe" class="text-blue-300 text-base md:text-lg"><?php echo htmlspecialchars($secr['sexe']); ?></p>
        </div>
        
        <small class="text-sm py-2 text-left text-blue-500">Nous assurons une confidentialite des informations de ce compte.</small>
    </div>
</div>

<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('eleve_list/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>

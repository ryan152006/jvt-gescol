<?php
require_once '../../../../Traitement/connexion.php';

$id = $_GET['id'] ?? null;

// Chargement des données pour le formulaire
if ($id) {
    $request = $conn->prepare("SELECT * FROM eleve WHERE id = :id");
    $request->bindParam(':id', $id, PDO::PARAM_INT);
    $request->execute();
    $row = $request->fetch(PDO::FETCH_ASSOC);

    // Récupération du nom de la classe
    $classeStmt = $conn->prepare("SELECT classe FROM eleve WHERE id = :id");
    $classeStmt->bindParam(':id', $id);
    $classeStmt->execute();
    $classeNom = $classeStmt->fetchColumn();

    // Récupération des montants de la table classe
    $stmt = $conn->prepare("SELECT pension, inscription, tranche1, tranche2, tranche3 FROM classe WHERE nom_class = :classeNom");
    $stmt->bindParam(':classeNom', $classeNom);
    $stmt->execute();
    $classe = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($classe) {
        $requiredInscription = (float) $classe['inscription'];
        $requiredTranche1 = (float) $classe['tranche1'];
        $requiredTranche2 = (float) $classe['tranche2'];
        $requiredTranche3 = (float) $classe['tranche3'];
        $pension = (float) $classe['pension'];
    } 

    // Calcul du montant restant dû
    $inscription = (float) ($row['inscription'] ?? 0);
    $tranche1 = (float) ($row['tranche1'] ?? 0);
    $tranche2 = (float) ($row['tranche2'] ?? 0);
    $tranche3 = (float) ($row['tranche3'] ?? 0);
    $totalPaye = $inscription + $tranche1 + $tranche2 + $tranche3;
    $reste = $pension - $totalPaye;
    (float) $row['reste'] = $reste;

    // Affichage du montant restant dû dans le HTML
    ob_start(); // Démarre la mise en tampon de sortie
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Paiement</title>
    <style>
        .hidden {
            display: none;
        }
        .disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="bg-gray-100">
    <section class="flex justify-center items-center min-h-screen">
        <div class="w-full max-w-4xl bg-white rounded shadow-md dark:bg-gray-800">
            <div class="p-6">
                <h1 class="text-2xl font-medium text-blue-500 text-center mb-6 dark:text-blue-400">
                    Gestion de la Scolarité 
                </h1>
                <?php if (isset($row)) : ?>
                <form id="registration-form" action="" method="post" class="space-y-2 sm:space-y-4">
                    <fieldset id="fieldset-2" class=" grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                        <div class="flex flex-col">
                            <label for="inscription" class="block text-sm font-normal text-gray-900 dark:text-white">Montant de l'Inscription</label>
                            <input type="number" value="<?= htmlspecialchars($row['inscription']) ?>" name="inscription" id="inscription" title="Entrez le montant de l'inscription" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="tranche1" class="block text-sm font-normal text-gray-900 dark:text-white">1ère Tranche</label>
                            <input type="number" value="<?= htmlspecialchars($row['tranche1'] ?? '') ?>" name="tranche1" id="tranche1" placeholder="Ex: 200" title="Entrez le montant de la 1ère tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="tranche2" class="block text-sm font-normal text-gray-900 dark:text-white">2ème Tranche</label>
                            <input type="number" name="tranche2" value="<?= htmlspecialchars($row['tranche2'] ?? '') ?>" id="tranche2" placeholder="Ex: 200 000" title="Entrez le montant de la 2ème tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                        <div class="flex flex-col">
                            <label for="tranche3" class="block text-sm font-normal text-gray-900 dark:text-white">3ème Tranche</label>
                            <input type="number" name="tranche3" value="<?= htmlspecialchars($row['tranche3'] ?? '') ?>" id="tranche3" placeholder="Ex: 100 000" title="Entrez le montant de la 3ème tranche" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded focus:ring-primary-600 focus:border-primary-600 block w-full sm:w-[300px] md:w-[400px] p-3 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
                        </div>
                    </fieldset>
                    <div class="flex justify-between items-center mt-4">
                        <button type="submit" id="submit-button" class=" text-white bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700">
                            Enregistrer
                        </button>
                        <a href="../eleve.php" class="text-white bg-transparent border-2 border-gray-400 hover:bg-gray-600 focus:outline-none font-normal rounded text-xl px-8 py-2 text-center dark:border-gray-600 dark:hover:bg-gray-600 dark:text-white">
                            Retour
                        </a>
                    </div>
                    <small class="block text-left text-gray-600 dark:text-gray-400 mt-2">Assurez-vous de bien mentionner les montants!</small>
                </form>
                <!-- <div class="mt-4 p-4 bg-gray-200 border border-gray-300 rounded">
                    <h2 class="text-xl font-medium text-gray-800">Montant Restant Dû</h2>
                    <p class="text-lg font-semibold text-red-600"><?= htmlspecialchars(number_format($reste, 2, ',', ' ') ) ?> FCFA</p>
                </div> -->
                <?php else : ?>
                    <p>Aucun élève trouvé avec cet ID.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inscription = isset($_POST["inscription"]) ? (float) $_POST["inscription"] : 0;
    $tranche1 = isset($_POST["tranche1"]) ? (float) $_POST["tranche1"] : 0;
    $tranche2 = isset($_POST["tranche2"]) ? (float) $_POST["tranche2"] : 0;
    $tranche3 = isset($_POST["tranche3"]) ? (float) $_POST["tranche3"] : 0;

    // Validation des montants
    if ($inscription > $requiredInscription || $tranche1 > $requiredTranche1 || $tranche2 > $requiredTranche2 || $tranche3 > $requiredTranche3) {
        echo "<script>alert('Erreur : Un ou plusieurs montants saisis dépassent les montants autorisés pour cette classe.');</script>";
    } else {
        try {
            // Calcul du montant restant dû après mise à jour
            $totalPaye = $inscription + $tranche1 + $tranche2 + $tranche3;
            $reste = $pension - $totalPaye;

            // Mise à jour des informations de l'élève
            $updateStmt = $conn->prepare("UPDATE eleve SET inscription = :inscription, tranche1 = :tranche1, tranche2 = :tranche2, tranche3 = :tranche3, reste = :reste WHERE id = :id");

            // Liaison des paramètres
            $updateStmt->bindParam(':inscription', $inscription);
            $updateStmt->bindParam(':tranche1', $tranche1);
            $updateStmt->bindParam(':tranche2', $tranche2);
            $updateStmt->bindParam(':tranche3', $tranche3);
            $updateStmt->bindParam(':reste', $reste);
            $updateStmt->bindParam(':id', $id);

            // Exécution de la requête
            $updateStmt->execute();

            header("Location: ../eleve.php?reste=" . urlencode($reste));
            exit;
         
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        }
    }
}
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var inscriptionInput = document.getElementById('inscription');
    var tranche1Input = document.getElementById('tranche1');
    var tranche2Input = document.getElementById('tranche2');
    var tranche3Input = document.getElementById('tranche3');

    // Valeurs requises injectées depuis PHP
    var requiredTranche1 = <?= json_encode($requiredTranche1) ?>;
    var requiredTranche2 = <?= json_encode($requiredTranche2) ?>;
    var requiredTranche3 = <?= json_encode($requiredTranche3) ?>;

    function checkFields() {
        var inscriptionValue = parseFloat(inscriptionInput.value);
        var tranche1Value = parseFloat(tranche1Input.value);
        var tranche2Value = parseFloat(tranche2Input.value);
        var tranche3Value = parseFloat(tranche3Input.value);

        // Activer tranche1 si inscription est rempli
        tranche1Input.disabled = isNaN(inscriptionValue) || inscriptionValue <= 0;

        // Activer tranche2 seulement si tranche1 atteint son montant requis
        tranche2Input.disabled = tranche1Input.disabled || tranche1Value < requiredTranche1;

        // Activer tranche3 seulement si tranche2 atteint son montant requis
        tranche3Input.disabled = tranche2Input.disabled || tranche2Value < requiredTranche2;
    }

    inscriptionInput.addEventListener('input', checkFields);
    tranche1Input.addEventListener('input', checkFields);
    tranche2Input.addEventListener('input', checkFields);

    // Vérifier l'état initial
    checkFields();
});
</script>
</body>
</html>

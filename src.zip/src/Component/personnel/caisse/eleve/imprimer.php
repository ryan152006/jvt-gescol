<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Paiement</title>
    <style>
          body {
                background-image: none; /* Supprimer le fond pour l'impression */
            }
    @media print {
            body {
                background-image: none; /* Supprimer le fond pour l'impression */
            }
            .print-hidden {
                display: none; /* Cacher les éléments non pertinents pour l'impression */
            }
            .print-visible {
                background-color: white; /* Fond blanc pour les communiqués */
                border: 1px solid black; /* Bordure noire autour du communiqué */
                justify-content:center; /* Espacement autour du communiqué */
                align-items:center;
                display: flex;
                flex-direction:column;            
            
            }
            /* Empêcher la pagination dans les impressions */
            @page {
                margin: 0.5in;
            }
        }
    </style>
    <script>
        function printrecu(communiqueId) {
            // Cacher tous les autres communiqués
            document.querySelectorAll('.recu').forEach(function(element) {
                if (!element.classList.contains('recu-' + communiqueId)) {
                    element.classList.add('print-hidden');
                } else {
                    element.classList.add('print-visible');
                }
            });

            // Lancer l'impression
            window.print();

            // Réinitialiser la visibilité des communiqués
            document.querySelectorAll('.recu').forEach(function(element) {
                element.classList.remove('print-hidden', 'print-visible');
            });
        }
    </script>
</head>

<?php
        require '../../../../Traitement/connexion.php';
        $id = $_GET['id'];
        $slmt=$conn->prepare("SELECT * FROM eleve WHERE id=$id");
        $slmt->execute();
        $elev = $slmt->fetchAll(PDO::FETCH_ASSOC);

?>
<body class="bg-gray-100">
   <section class="flex flex-col space-y-4 justify-center items-center min-h-screen">
        <div class="print-visible  w-full max-w-4xl bg-white rounded shadow-xl text-white px-14">

        <div class="flex items-center p-2 py-2 space-x-2 rtl:space-x-reverse">
                <img src="../../../../Assets/logoecole.jpg" class="h-16 w-16 rounded-full"  />
                <span class="text-2xl font-medium text-gray-900 text-center ">COLLEGE JEAN XXIII D'EFOK</span>
            </div>
            <div class="flex flex-col rounded-full justify-center bg-orange-400 items-center flex mb-2 border-2 border-red-600">
                    <h3 class="text-xl font-normal px-4 text-gray-800 text-center">FRAIS DE SCOLARITE</h3>
                    
            </div>
            <div class="flex flex-col  space-y-1 ">
            <span  class="text-sm font-normal  text-gray-500 text-center">Année scolaire 2024/2025</span>
            <?php foreach($elev as $eleve): $eleve['code_elev']="jeanefok23";?>
                <div class="flex">
                <span class="text-left w-full text-2sm text-gray-900  space-x-2  font-normal"> <span>Matricule :</span>   <span class="text-blue-800 text-right  font-normal"><?php echo htmlspecialchars($eleve['code_elev']); ?><?php echo htmlspecialchars($eleve['id']); ?></span> </span>
                <span class="text-left w-full text-2sm text-gray-900  space-x-2  font-normal"> <span>Classe :</span>   <span class="text-blue-800 text-right  font-normal"><?php echo htmlspecialchars($eleve['classe']); ?></span> </span>
                </div>
                <span class="text-left text-2sm text-gray-900  space-x-2 font-normal"><span>Nom de l'élève :</span> <span class="text-blue-800 font-normal"><?php echo htmlspecialchars($eleve['nom_elev']); ?></span> </span>
                <span class="text-left text-2sm text-gray-900  space-x-2 font-normal"><span>Prenom de l'élève : </span><span class="text-blue-800 font-normal"><?php echo htmlspecialchars($eleve['prenom_elev']); ?></span> </span>
                <table class="w-full mb-6 overflow-x-auto  text-sm text-center text-gray-500 dark:text-gray-400">
                <thead class="text-2sm overflow-x-auto text-gray-900 font-normal   ">
                    <tr>
                        <th scope="col" class="px-2 py-1">Inscription</th>
                        <th scope="col" class="px-2 py-1">1<sup>ere</sup>Tranche</th>
                        <th scope="col" class="px-2 py-1">2<sup>eme</sup>Tranche</th>
                        <th scope="col" class="px-2 py-1">3<sup>eme</sup>Tranche</th>
                        <th scope="col" class="px-2 py-1">Reste</th>
                 </tr>
            </thead>
            <tbody class="overflow-x-auto ">
            <tr class="">
                            <td class="px-1 text-center text-blue-800   ">
                            <?php echo htmlspecialchars($eleve['inscription']); ?>
                            </td>
                            <td class="px-1 text-center text-blue-800   ">
                                <?php echo htmlspecialchars($eleve['tranche1']); ?>
                            </td>
                            <td class="px-1 text-center text-blue-800   ">
                                <?php echo htmlspecialchars($eleve['tranche2']); ?>
                            </td>
                            <td class="px-1 text-center text-blue-800 ">
                                <?php echo htmlspecialchars($eleve['tranche3']); ?>
                            </td>
                            <td class="px-1 text-center text-blue-800 ">
                            <?= htmlspecialchars($eleve['reste']) ?>Fcfa
                            </td>
            </tr>
            </tbody>
            </table>
            <span class="text-right  text-2sm mb-4 py-1 text-gray-900   space-x-2 font-normal"><span>Efok, le </span><span class="text-blue-800 font-normal"><?php echo date("d/m/Y"); ?> </span> <br> <span class="text-red-600">L'Econome</span> </span>
            </div>
            <div class="py-4"></div>
            <?php endforeach;?>
        </div>
        <div class=" flex space-x-4 print-hidden">
        <button type="button" onclick="printrecu(<?php echo $id; ?>)"  class="recu text-white bg-green-500 hover:bg-green-600  font-normal rounded text-xl px-8 py-2 text-center dark:focus:ring-green-700">
            Imprimer
        </button>
        <a href="../eleve.php" class="recu text-white bg-blue-500 font-normal rounded text-xl px-8 py-2 text-center  dark:text-white">
            Retour
        </a>
        </div>
        
    </section>

</body>
</html>
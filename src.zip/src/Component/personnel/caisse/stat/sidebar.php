<button data-drawer-target="separator-sidebar" data-drawer-toggle="separator-sidebar" aria-controls="separator-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
   <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>
<aside id="separator-sidebar" class=" relative top-0 left-0 z-40 w-full  h-screen overflow-hidden  transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto dark:bg-gray-900">
      <ul class="space-y-2 font-medium">
         <li >   
            <a href="dashboard.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               <svg class="w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 21">
                  <path d="M16.975 11H10V4.025a1 1 0 0 0-1.066-.998 8.5 8.5 0 1 0 9.039 9.039.999.999 0 0 0-1-1.066h.002Z"/>
                  <path d="M12.5 0c-.157 0-.311.01-.565.027A1 1 0 0 0 11 1.02V10h8.975a1 1 0 0 0 1-.935c.013-.188.028-.374.028-.565A8.51 8.51 0 0 0 12.5 0Z"/>
               </svg>
               <span class="ms-3 ">Dashboard</span>
            </a>
         </li>
         <li  >
            <a href="eleve_list.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               
            <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 18">
                  <path d="M14 2a3.963 3.963 0 0 0-1.4.267 6.439 6.439 0 0 1-1.331 6.638A4 4 0 1 0 14 2Zm1 9h-1.264A6.957 6.957 0 0 1 15 15v2a2.97 2.97 0 0 1-.184 1H19a1 1 0 0 0 1-1v-1a5.006 5.006 0 0 0-5-5ZM6.5 9a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9ZM8 10H5a5.006 5.006 0 0 0-5 5v2a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-2a5.006 5.006 0 0 0-5-5Z"/>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Eleves</span>
               <span class="inline-flex items-center justify-center px-2 ms-3 text-sm font-medium text-gray-800 bg-gray-100 rounded-full dark:bg-gray-700 dark:text-gray-300">Pro</span>
            </a>
         </li>
         <li >
            <a href="eleve.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               
            <svg class="flex-shrink-0 w-5 h-5 text-white transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
               <path d="M18.6667 11C20.5513 10.7213 22 9.04574 22 7.02036C22 4.79998 20.2589 3 18.1111 3H5.88889C3.74112 3 2 4.79998 2 7.02036C2 9.04574 3.44873 10.7213 5.33333 11" stroke="#1C274C" stroke-width="1.5"/>
               <path d="M12 6V13M12 13L14 10.6667M12 13L10 10.6667" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               <path d="M5 10C5 8.11438 5 7.17157 5.58579 6.58579C6.17157 6 7.11438 6 9 6H15C16.8856 6 17.8284 6 18.4142 6.58579C19 7.17157 19 8.11438 19 10V16C19 17.8856 19 18.8284 18.4142 19.4142C17.8284 20 16.8856 20 15 20H9C7.11438 20 6.17157 20 5.58579 19.4142C5 18.8284 5 17.8856 5 16V10Z" stroke="#1C274C" stroke-width="1.5"/>
               <path d="M5 17H19" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Scolarité</span>
               <span class="inline-flex items-center justify-center px-2 ms-3 text-sm font-medium text-gray-800 bg-gray-100 rounded-full dark:bg-gray-700 dark:text-gray-300">Pro</span>
            </a>
         </li>
         <li >
            <a href="communique.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                  <path d="m17.418 3.623-.018-.008a6.713 6.713 0 0 0-2.4-.569V2h1a1 1 0 1 0 0-2h-2a1 1 0 0 0-1 1v2H9.89A6.977 6.977 0 0 1 12 8v5h-2V8A5 5 0 1 0 0 8v6a1 1 0 0 0 1 1h8v4a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-4h6a1 1 0 0 0 1-1V8a5 5 0 0 0-2.582-4.377ZM6 12H4a1 1 0 0 1 0-2h2a1 1 0 0 1 0 2Z"/>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Communiqué</span>
               <span class="inline-flex items-center justify-center w-3 h-3 p-3 ms-3 text-sm font-medium text-blue-800 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-300">3</span>
            </a>
         </li>
         <li >
            <a href="moncompte.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
           
          <svg class="flex-shrink-0 w-5 h-5 text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 128 128" id="Слой_1" version="1.1" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

          <style type="text/css">
            .st0{fill:#FFE0B2;}
            .st1{fill:#424242;}
            .st2{fill:#90CAF9;}
            .st3{fill:#FFFFFF;}
          </style>

          <g>

          <g>

          <circle class="st0" cx="64" cy="33" r="31"/>

          <path class="st1" d="M64,66c-18.2,0-33-14.8-33-33S45.8,0,64,0s33,14.8,33,33S82.2,66,64,66z M64,4C48,4,35,17,35,33s13,29,29,29    s29-13,29-29S80,4,64,4z"/>

          </g>

          <path class="st2" d="M126,126c0-34.2-27.8-62-62-62S2,91.8,2,126H126z"/>

          <path class="st1" d="M126,128H2c-1.1,0-2-0.9-2-2c0-25.9,15.5-48.3,37.7-58.3c8-3.6,17-5.7,26.3-5.7c6.6,0,13,1,19,2.9   c26,8.1,45,32.4,45,61.1C128,127.1,127.1,128,126,128z M4,124h60h60c-0.6-19.4-10.5-36.4-25.3-46.9c-6.1-4.4-13.1-7.6-20.6-9.4   C73.5,66.6,68.8,66,64,66c-5.9,0-11.6,0.9-17,2.4c-5,1.5-9.7,3.6-14,6.2C16.2,84.8,4.7,103.1,4,124z"/>

          </g>

          <path class="st3" d="M56,127"/>

          </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">Mon compte</span>
            </a>
         </li>
        
           
         <li class="bg-gray-600  rounded">
            <a href="stat.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
               <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 20">
                  <path d="M16 14V2a2 2 0 0 0-2-2H2a2 2 0 0 0-2 2v15a3 3 0 0 0 3 3h12a1 1 0 0 0 0-2h-1v-2a2 2 0 0 0 2-2ZM4 2h2v12H4V2Zm8 16H3a1 1 0 0 1 0-2h9v2Z"/>
               </svg>
               <span class="ms-3">Statisques</span>
            </a>
         </li>
      </ul>
      <ul class="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700">
      <li >
            <a href="finance.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
            <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" viewBox="0 0 48 48" id="svg5" version="1.1" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg">

<defs id="defs2"/>

<g id="layer1" transform="translate(-314.00003,-377)">

<path d="m 334.1226,388.15607 11.31865,-1.86916 c 0.91644,-0.15134 1.80338,0.39915 2.07495,1.28785 l 3.35416,10.97606 -14.93488,21.34903 -16.74778,-10.39475 z" id="path34743" style="fill:#fcca3d;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1"/>

<path d="m 334.90209,393.41809 9.66358,-7.97875 c 0.78243,-0.64601 1.95071,-0.64601 2.73314,0 l 9.66359,7.97875 v 27.18511 h -22.06031 z" id="rect34634" style="fill:#e7e7e7;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1"/>

<path d="m 345.93164,384.95475 c -0.48767,0 -0.97402,0.16137 -1.36523,0.48437 l -9.66407,7.97852 1e-5,27.18554 7.7832,10e-6 a 21.652178,31.512308 17.952719 0 0 11.84375,-18.32227 21.652178,31.512308 17.952719 0 0 1.95312,-9.25977 l -9.18359,-7.58203 c -0.39122,-0.323 -0.87951,-0.48438 -1.36719,-0.48437 z" id="path58151" style="fill:#fafafa;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1;stroke-opacity:1"/>

<path d="m 345.93164,401.94107 a 1.0052433,0.9947851 0 0 0 -1.00391,0.99414 v 1.36328 c -1.42542,0.4155 -2.49218,1.68815 -2.49218,3.21289 0,1.86655 1.59875,3.35938 3.49609,3.35938 0.85638,0 1.48828,0.62495 1.48828,1.36914 0,0.74421 -0.63191,1.36913 -1.48828,1.36913 -0.85638,0 -1.48828,-0.62492 -1.48828,-1.36913 a 1.0052433,0.9947851 0 0 0 -1.00391,-0.99414 1.0052433,0.9947851 0 0 0 -1.0039,0.99414 c 0,1.52475 1.06676,2.79739 2.49218,3.21289 v 1.36328 a 1.0052433,0.9947851 0 0 0 1.00391,0.99414 1.0052433,0.9947851 0 0 0 1.00586,-0.99414 v -1.36328 c 1.42464,-0.41596 2.49218,-1.68869 2.49219,-3.21289 0,-1.86652 -1.60071,-3.35938 -3.49805,-3.35938 -0.85639,0 -1.48828,-0.62492 -1.48828,-1.36914 0,-0.74419 0.63189,-1.36914 1.48828,-1.36914 0.85639,0 1.48828,0.62495 1.48828,1.36914 a 1.0052433,0.9947851 0 0 0 1.00586,0.99609 1.0052433,0.9947851 0 0 0 1.00391,-0.99609 c 0,-1.52419 -1.06755,-2.79692 -2.49219,-3.21289 v -1.36328 a 1.0052433,0.9947851 0 0 0 -1.00586,-0.99414 z" id="path34626" style="color:#000000;fill:#808b9b;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:0.999998;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1;stroke-opacity:1"/>

<path d="m 346,381.38638 c -0.55228,0 -1,0.44772 -1,1 v 9.6558 c 0,0.55228 0.44772,1 1,1 0.55228,0 1,-0.44772 1,-1 v -9.6558 c 0,-0.55228 -0.44772,-1 -1,-1 z" id="path57955" style="color:#000000;fill:#808b9b;fill-opacity:1;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1;-inkscape-stroke:none"/>

<path d="m 349.04819,394.71907 c 0,1.72088 -1.39506,3.11592 -3.11596,3.11592 -1.72089,0 -3.11594,-1.39504 -3.11594,-3.11592 0,-1.72086 1.39505,-3.11589 3.11594,-3.11589 1.7209,0 3.11596,1.39503 3.11596,3.11589 z" id="path34737" style="fill:#ff5576;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4.1"/>

</g>

</svg>
               <span class="ms-3">Finance</span>
            </a>
         </li>
        
         <li >
            <a href="form_disc.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
            <svg version="1.1" class="flex-shrink-0 w-5 h-5 text-gray-200 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 512 512" xml:space="preserve">
<rect x="68" y="4" style="fill:#FFFFFF;" width="376" height="504"/>
<path style="fill:#8AD5DD;" d="M440,8v496H72V8H440 M448,0H64v512h384V0L448,0z"/>
<g>
	<polygon style="fill:#999999;" points="292.048,431.344 256,468.632 219.952,431.344 231.208,420.208 256,445.848 280.792,420.208 
			"/>
	<rect x="106.744" y="109.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="141.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="173.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.744" y="205.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="237.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="269.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="301.336" style="fill:#999999;" width="298.48" height="10.664"/>
	<rect x="106.736" y="333.336" style="fill:#999999;" width="298.48" height="10.664"/>
</g>
<rect x="106.744" y="40" style="fill:#DB2B42;" width="298.48" height="32"/>
<rect x="106.736" y="365.336" style="fill:#999999;" width="298.48" height="10.664"/>
</svg>

               <span class="ms-3">Formulaire de Discipline</span>
            </a>
         </li>
         <li>
            <a href="propos.php" class="flex items-center p-2 text-gray-900 transition duration-75 rounded hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white group">
                <svg class="flex-shrink-0 w-7 h-7 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"  viewBox="0 0 48 48" version="1" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 48 48">
                  <path fill="#2196F3" d="M37,40H11l-6,6V12c0-3.3,2.7-6,6-6h26c3.3,0,6,2.7,6,6v22C43,37.3,40.3,40,37,40z"/>
                  <g fill="#ffffff">
                     <rect x="22" y="20" width="4" height="11"/>
                     <circle cx="24" cy="15" r="2"/>
                  </g>
               </svg>
               <span class="flex-1 ms-3 whitespace-nowrap">A propos</span>
            </a>
         </li>
         <li>
            <a href="deconnexion.php" class="flex items-center p-2 text-gray-900 rounded dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
                    
                              <svg width="800px" class="flex-shrink-0 w-5 h-5 text-gray-300 transition duration-75 dark:text-gray-200 group-hover:text-gray-900 dark:group-hover:text-white" height="800px" viewBox="0 0 24 24" id="meteor-icon-kit__regular-sign-out" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M20.5858 12.9999H5C4.44772 12.9999 4 12.5522 4 11.9999C4 11.4476 4.44772 10.9999 5 10.9999H20.5858L18.2929 8.70701C17.9024 8.31648 17.9024 7.68332 18.2929 7.29279C18.6834 6.90227 19.3166 6.90227 19.7071 7.29279L23.7071 11.2928C24.0976 11.6833 24.0976 12.3165 23.7071 12.707L19.7071 16.707C19.3166 17.0975 18.6834 17.0975 18.2929 16.707C17.9024 16.3165 17.9024 15.6833 18.2929 15.2928L20.5858 12.9999ZM14 6.9999C14 7.55218 13.5523 7.9999 13 7.9999C12.4477 7.9999 12 7.55218 12 6.9999V4.69415C12 4.20531 11.6466 3.78812 11.1644 3.70776L3.1644 2.37443C2.61963 2.28363 2.1044 2.65165 2.01361 3.19642C2.00455 3.25075 2 3.30574 2 3.36082V20.639C2 21.1913 2.44772 21.639 3 21.639C3.05508 21.639 3.11007 21.6344 3.1644 21.6254L11.1644 20.292C11.6466 20.2117 12 19.7945 12 19.3056V16.9999C12 16.4476 12.4477 15.9999 13 15.9999C13.5523 15.9999 14 16.4476 14 16.9999V19.3056C14 20.7722 12.9398 22.0237 11.4932 22.2648L3.4932 23.5982C3.3302 23.6253 3.16524 23.639 3 23.639C1.34315 23.639 0 22.2958 0 20.639V3.36082C0 3.19558 0.0136525 3.03062 0.0408182 2.86762C0.313203 1.23331 1.85889 0.129253 3.4932 0.401638L11.4932 1.73497C12.9398 1.97607 14 3.22764 14 4.69415V6.9999Z" fill="#758CA3"/></svg>
               <span class="flex-1 ms-3 whitespace-nowrap text-red-800">Deconnexion</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

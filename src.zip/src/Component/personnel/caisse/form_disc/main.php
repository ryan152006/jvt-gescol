<?php
require_once '../../../Traitement/connexion.php';

// Préparation de la requête SQL pour récupérer tous les règlements triés par ID croissant
$request = $conn->prepare("SELECT * FROM formulaire_disci ORDER BY id_form ASC");
$request->execute();
$regulations = $request->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
<div id="main-content" class="md:container md:mx-auto flex flex-col justify-content items-center py-8 px-8">
            <div class="border-2 border-blue-500 bg-transparent w-full 	place-content:center py-4 p-2">
                <p class="text-center text-2xl text-blue-500 font-semibold">Formulaire de Discipline du College JEAN XXIII d'EFOK</p>
            </div>
                <div class="text-blue-500 py-4">
                    Liste des Règlements
                </div>
                <div class="card-content">
                    <div class="space-y-2">
                        <?php if ($regulations) : ?>
                            <?php foreach ($regulations as $regulation) : ?>
                                <div class="border-b border-gray-300 pb-4 mb-4">
                                    <div class="text-lg font-medium text-blue-600">
                                        Article N<sup>o</sup><?php echo htmlspecialchars($regulation['id_form']); ?>: <?php echo htmlspecialchars($regulation['titre']); ?>
                                    </div>
                                    <div class="mt-1 text-sm text-white">
                                        <?php echo nl2br(htmlspecialchars($regulation['contenu'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                           <p> Aucun reglement</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php
    // Récupération des fichiers depuis la base de données
    $stmt = $conn->prepare("SELECT * FROM piece_jointe");
    $stmt->execute();
    $pieces_jointes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="w-full py-4">
        <h2 class="text-blue-500 font-semibold mb-2">Pièces Jointes</h2>
        <div class="flex flex-col items-center">
            <?php foreach ($pieces_jointes as $piece): ?>
                <div class="rounded p-4 mb-2 w-full max-w-md text-center bg-white dark:bg-gray-800">
                   
                    <p class="mb-2 text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($piece['file_name']); ?></p>
                    <a href="<?php echo htmlspecialchars($piece['file_path']); ?>" download class="text-blue-500 hover:underline">Télécharger</a>
                   
                </div>
            <?php endforeach; ?>
        </div>
    </div>
            </div>
        </div>
    </section>


    <div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('form_disc/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>



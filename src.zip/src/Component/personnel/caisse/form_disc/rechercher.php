<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT * FROM formulaire_disci
          WHERE titre LIKE :search ORDER BY id_form asc";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$regulations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="mx-auto w-full md:w-auto overflow-x-auto justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-auto justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-xl md:text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4">Résultats de la Recherche</span>
            <div class="card-content">
                    <div class="space-y-2">
                        <?php if ($regulations) : ?>
                            <?php foreach ($regulations as $regulation) : ?>
                                <div class="border-b border-gray-300 pb-4 mb-4">
                                    <div class="text-lg font-medium text-blue-600">
                                        Article N<sup>o</sup><?php echo htmlspecialchars($regulation['id_form']); ?>: <?php echo htmlspecialchars($regulation['titre']); ?>
                                    </div>
                                    <div class="mt-1 text-sm text-white">
                                        <?php echo nl2br(htmlspecialchars($regulation['contenu'])); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                           <p> Aucun reglement</p>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
</div>

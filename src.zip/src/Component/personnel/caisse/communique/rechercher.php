<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = " SELECT * FROM communique
          WHERE titre LIKE :search ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$communiques = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="mx-auto w-full md:w-auto overflow-x-auto justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-auto justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-xl md:text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4">Résultats de la Recherche</span>
            <?php
                    
            foreach ($communiques as $communique) {
                $alertClass = "border-blue-500 bg-transparent"; // Bordure bleue et fond transparent
                $cardWidth = "w-full max-w-8xl"; // Largeur des cartes augmentée
                
                $piecejointeText = !empty($communique['piecejointe'])
                    ? '<p class="mt-2"><a href="../../../Traitement/principal/communique/uploads/' . htmlspecialchars($communique['piecejointe']) . '" target="_blank" class="text-blue-600 hover:underline">Télécharger la pièce jointe</a></p>'
                    : '<p class="mt-2 text-gray-500">Pas de pièce jointe.</p>';
                
                echo '<div class="p-4 mb-4 communique communique-' . htmlspecialchars($communique['id']) . ' ' . $alertClass . ' border rounded ' . $cardWidth . ' text-blue-800">';
                echo '<div class="flex items-center">';
                echo '<svg class="flex-shrink-0 w-4 h-4 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">';
                echo '<path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>';
                echo '</svg>';
                echo '<h3 class="text-lg font-medium text-white">Communiqué du ' .htmlspecialchars($communique['date']). '</h3>';
                echo '</div>';
                echo '<div class="mt-2 mb-4 text-sm text-blue-500">';
                echo '<h2 class="text-xl font-semibold">' . htmlspecialchars($communique['titre']) . '</h2>';
                echo '<p class="mt-2 text-white">' . nl2br(htmlspecialchars($communique['contenu'])) . '</p>';
                echo $piecejointeText;
                echo '</div>';
                echo '<div class="text-right flex space-x-2">';
                ?>
                <a href="../../../Traitement/secretaire/communique/supprimer.php?id=<?php echo $communique['id']; ?>" 
                    onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce communiqué ?');">
                    <button type="button" class="text-red-500 bg-transparent border border-red-500 hover:bg-red-500 hover:text-white focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded text-xs px-3 py-1.5 text-center">
                        Supprimer le communiqué
                    </button>
                </a>
               
                <?php
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</div>

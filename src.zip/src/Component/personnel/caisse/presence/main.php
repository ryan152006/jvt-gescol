<?php
require '../../../Traitement/connexion.php';

$date_aujourdhui = date("Y-m-d");

// Archiver automatiquement les fiches dont la date ne correspond plus à la date actuelle
$archive_stmt = $conn->prepare("
    UPDATE presence
    SET archive = 1
    WHERE date_presence != :date_aujourdhui AND archive = 0
");
$archive_stmt->bindParam(':date_aujourdhui', $date_aujourdhui);
$archive_stmt->execute();

// Récupérer les élèves absents (présent = 0) pour la date actuelle sans filtrer par classe
$absences_stmt = $conn->prepare("
    SELECT eleve.id AS id_eleve, eleve.nom_elev, eleve.prenom_elev, classe.nom_class, 
           presence.date_presence, presence.heure_presence, presence.annee_scolaire, employe.nom AS nom_prof
    FROM presence
    JOIN eleve ON presence.id_eleve = eleve.id
    JOIN classe ON presence.id_classe = classe.id_class
    JOIN employe ON presence.id_professeur = employe.matricule
    WHERE presence.date_presence = :date_aujourdhui 
    AND presence.present = 0
    AND presence.justifie = 0  -- Exclure les absences justifiées
    AND presence.archive = 0
    ORDER BY classe.nom_class, eleve.nom_elev
");

$absences_stmt->bindParam(':date_aujourdhui', $date_aujourdhui);
$absences_stmt->execute();
$absents = $absences_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
<div id="main-content">  
<div class="flex justify-end mb-4">
    <a href="presence/archives.php" class="bg-blue-500 hover:bg-green-600 text-white font-semibold py-2 my-2 px-4 sm:px-6 rounded transition-colors">
        Accéder aux fiches archivées
    </a>
</div>

<?php if (count($absents) === 0): ?>
    <div class="bg-white rounded shadow-md p-6 w-full max-w-md text-center">
        <h2 class="text-xl font-semibold text-gray-700 mb-4">Aucune absence pour aujourd'hui</h2>
    </div>
<?php else: ?>
    <div class="w-full max-w-4xl mx-auto p-4 sm:p-8 bg-white shadow-lg rounded">
        <?php foreach ($absents as $eleve): ?>
            <div class="mb-6">
                <h3 class="text-lg font-bold text-gray-700">
                    Classe: <?php echo htmlspecialchars($eleve['nom_class']); ?> | 
                    Professeur: <?php echo htmlspecialchars($eleve['nom_prof']); ?>
                </h3>
                <p class="text-sm text-gray-600">
                    Date: <?php echo htmlspecialchars($eleve['date_presence']); ?> | 
                    Heure: <?php echo htmlspecialchars($eleve['heure_presence']); ?> | 
                    Année Scolaire: <?php echo htmlspecialchars($eleve['annee_scolaire']); ?>
                </p>
            </div>

            <form action="../../../Traitement/caisse/presence/justifier_absence.php" method="post">
                <div class="overflow-x-auto">
                    <table class="min-w-full border-collapse border border-gray-200 text-left rounded overflow-hidden shadow-sm">
                        <thead>
                            <tr class="bg-blue-500 text-white">
                                <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">ID Élève</th>
                                <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Nom</th>
                                <th class="py-3 px-2 sm:px-6 border-b-2 border-gray-300 text-center">Justifié</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                    <input type="hidden" name="id_eleve[]" value="<?php echo htmlspecialchars($eleve['id_eleve']); ?>">
                                    <?php echo htmlspecialchars($eleve['id_eleve']); ?>
                                </td>
                                <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center"><?php echo htmlspecialchars($eleve['nom_elev'] . ' ' . $eleve['prenom_elev']); ?></td>
                                <td class="py-3 px-2 sm:px-6 border-b border-gray-200 text-center">
                                    <input type="checkbox" name="justifie[]" value="<?php echo htmlspecialchars($eleve['id_eleve']); ?>" class="form-checkbox h-5 w-5 text-green-500">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Boutons d'action -->
                <div class="mt-8 flex justify-center space-x-4">
                    <button type="submit" class="px-6 py-2 bg-green-500 text-white font-semibold rounded hover:bg-green-600 transition-all">
                        Justifier Absences
                    </button>
                </div>
            </form>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
</div>
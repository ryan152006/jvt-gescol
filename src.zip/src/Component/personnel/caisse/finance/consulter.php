<?php
require '../../../../Traitement/connexion.php';

if (isset($_GET['id'])) {
    $operation_id = $_GET['id'];

    // Récupération des détails de l'opération
    $operation_query = "SELECT id, date, libelle, description, categorie, montant FROM finance WHERE id = :id";
    $stmt = $conn->prepare($operation_query);
    $stmt->bindParam(':id', $operation_id, PDO::PARAM_INT);
    $stmt->execute();
    $operation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$operation) {
        echo "Opération non trouvée.";
        exit;
    }
} else {
    echo "ID d'opération manquant.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Détails de l'Opération</title>
</head>
<body class="bg-gray-100">

    <div class="max-w-4xl mx-auto mt-4 p-6 bg-white rounded shadow-lg">
        <div class="mb-4">
            <h2 class="text-2xl font-bold text-blue-600 mb-4">Fiche de l'Opération Financière</h2>
        </div>

        <div class="space-y-4">
            <div class="flex justify-between">
                <span class="text-sm font-medium text-gray-600">Libellé :</span>
                <span class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($operation['libelle']); ?></span>
            </div>

            <div class="flex justify-between">
                <span class="text-sm font-medium text-gray-600">Catégorie :</span>
                <span class="text-lg font-semibold text-gray-900"><?php echo ($operation['categorie'] == 'recette') ? 'Recette' : 'Dépense'; ?></span>
            </div>

            <div class="flex justify-between">
                <span class="text-sm font-medium text-gray-600">Description :</span>
                <span class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($operation['description']); ?></span>
            </div>

            <div class="flex justify-between">
                <span class="text-sm font-medium text-gray-600">Montant (Fcfa) :</span>
                <span class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($operation['montant']); ?> Fcfa</span>
            </div>

            <div class="flex justify-between">
                <span class="text-sm font-medium text-gray-600">Date :</span>
                <span class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($operation['date']); ?></span>
            </div>
        </div>

        <div class="flex justify-between items-center mt-6">
            <a href="../finance.php" class="text-sm text-blue-500 hover:underline">Retour à la liste</a>
            <a href="modifier.php?id=<?php echo $operation_id; ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded">Modifier</a>
        </div>
    </div>

</body>
</html>

<?php
require '../../../Traitement/connexion.php';

// Récupération du montant total des dépenses
$depenses_query = "SELECT SUM(montant) as total_depenses FROM finance WHERE categorie = 'depense'";
$stmt = $conn->prepare($depenses_query);
$stmt->execute();
$total_depenses = $stmt->fetch(PDO::FETCH_ASSOC)['total_depenses'] ?? 0;

// Récupération du montant total des recettes
$recettes_query = "SELECT SUM(montant) as total_recettes FROM finance WHERE categorie = 'recette'";
$stmt = $conn->prepare($recettes_query);
$stmt->execute();
$total_recettes = $stmt->fetch(PDO::FETCH_ASSOC)['total_recettes'] ?? 0;

// Mise à jour du budget dépense et recette dans la base de données
$update_budget_query = "UPDATE finance SET budget_depense = :total_depenses, budget_recette = :total_recettes WHERE id = 1"; // ou la ligne appropriée pour stocker les budgets
$stmt = $conn->prepare($update_budget_query);
$stmt->bindParam(':total_depenses', $total_depenses);
$stmt->bindParam(':total_recettes', $total_recettes);
$stmt->execute();

// Récupération des opérations financières
// Récupération des opérations financières (excluant l'enregistrement avec id = 1)
$operations_query = "SELECT id, date, libelle, description, categorie, montant FROM finance WHERE id != 1 ORDER BY date ASC";
$stmt = $conn->prepare($operations_query);
$stmt->execute();
$operations = $stmt->fetchAll(PDO::FETCH_ASSOC);
$budget_difference = $total_recettes - $total_depenses;

$check_query = "SELECT id FROM finance WHERE id = 1";
$stmt = $conn->prepare($check_query);
$stmt->execute();
$exists = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$exists) {
    // Créer un nouvel enregistrement pour stocker les budgets si id = 1 n'existe pas
    $insert_budget_query = "INSERT INTO finance (id, budget_depense, budget_recette) VALUES (1, :total_depenses, :total_recettes)";
    $stmt = $conn->prepare($insert_budget_query);
} else {
    // Mettre à jour si l'enregistrement existe déjà
    $update_budget_query = "UPDATE finance SET budget_depense = :total_depenses, budget_recette = :total_recettes WHERE id = 1";
    $stmt = $conn->prepare($update_budget_query);
}

$stmt->bindParam(':total_depenses', $total_depenses);
$stmt->bindParam(':total_recettes', $total_recettes);
$stmt->execute();

?>

<style>
    #addOperationModal {
        z-index: 100;
    }
</style>
<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 80%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close {
    color: #aaa;
    font-size: 1.5em;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
}

#main-content {
    max-height: 80vh;
    overflow-y: auto;
}
</style>
<div id="main-content" class="container mx-auto py-8 px-4">
    <!-- En-tête -->
    <span class="border border-blue-500 rounded p-2 text-2xl md:text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4 px-4 space-x-2">
        Gestion financière du Collège<br>
        <span class="text-blue-500">JEAN XXIII D'EFOK</span>
    </span>

    <!-- Section des totaux des dépenses et recettes -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-center mb-6 my-4">
        <div class="text-lg md:text-xl font-semibold text-red-500">
            Dépenses Totales : <?php echo number_format($total_depenses, 2, ',', ' '); ?> Fcfa
            <?php if ($budget_difference < 0): ?>
                <span class="text-green-500">↑</span>
            <?php else: ?>
                <span class="text-red-500">↓</span>
            <?php endif; ?>
        </div>
        <div class="text-lg md:text-xl font-semibold text-green-500">
            Recettes Totales : <?php echo number_format($total_recettes, 2, ',', ' '); ?> Fcfa
            <?php if ($budget_difference > 0): ?>
                <span class="text-green-500">↑</span>
            <?php else: ?>
                <span class="text-red-500">↓</span>
            <?php endif; ?>
        </div>
        <div class="text-center">
            <button class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded w-full md:w-auto" onclick="toggleModal()">+ Ajouter une opération</button>
        </div>
    </div>

    <!-- Tableau des opérations financières -->
    <div class="overflow-x-auto bg-white shadow-md rounded">
        <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-gray-50 border-b text-xs text-gray-700 ">
                <tr>
                    <th class="px-2  md:px-4 py-3">Date</th>
                    <th class="px-2  md:px-4 py-3">Libellé</th>
                    <th class="px-2  md:px-4 py-3">Description</th>
                    <th class="px-2  md:px-4 py-3">Catégorie</th>
                    <th class="px-2  md:px-4 py-3">Montant</th>
                    <th class="px-2  md:px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($operations as $op): ?>
                    <tr class="bg-white border-b hover:bg-gray-50">
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['date']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['libelle']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['description']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['categorie']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo number_format($op['montant'], 2, ',', ' '); ?> Fcfa</td>
                        <td class="px-2 md:px-4 py-3 text-center flex space-x-2">
                            <a href="finance/modifier.php?id=<?php echo $op['id']; ?>" class="text-green-500 text-center hover:underline">Modifier</a>
                            <a href="../../../Traitement/caisse/finance/supprimer.php?id=<?php echo $op['id']; ?>" class="text-red-500 text-center hover:underline" onclick="return confirm('Voulez-vous vraiment supprimer cette opération ?');">Supprimer</a>
                            <a href="finance/consulter.php?id=<?php echo $op['id']; ?>" class="text-blue-500 text-center hover:underline">Consulter</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal d'ajout d'opération -->
<div id="addOperationModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
    <div class="bg-white p-6 rounded shadow-lg max-w-md w-full">
        <h2 class="text-xl font-semibold mb-4">Ajouter une Opération Financière</h2>
        <form action="../../../Traitement/caisse/finance/enregistrer.php" method="POST">
            <div class="mb-4">
                <label for="libelle" class="block text-sm font-medium text-gray-700">Libellé</label>
                <input type="text" name="libelle" id="libelle" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" required>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"></textarea>
            </div>
            <div class="mb-4">
                <label for="montant" class="block text-sm font-medium text-gray-700">Montant (Fcfa)</label>
                <input type="number" step="0.01" name="montant" id="montant" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" required>
            </div>
            <div class="mb-4">
                <label for="categorie" class="block text-sm font-medium text-gray-700">Catégorie</label>
                <select name="categorie" id="categorie" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" required>
                    <option value="recette">Recette</option>
                    <option value="depense">Dépense</option>
                </select>
            </div>
            <div class="mb-4">
                <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
                <input type="text" name="date" id="date" value="<?php echo date('Y-m-d'); ?>" disabled class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
            </div>
            <div class="flex justify-end">
                <button type="button" class="mr-4 bg-gray-300 px-4 py-2 rounded" onclick="toggleModal()">Annuler</button>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Ajouter</button>
            </div>
        </form>
    </div>
</div>

<div id="results-modal" class="modal">
    <div class="modal-content bg-white dark:bg-gray-800">
        <div class="modal-header">
            <span class="close">&times;</span>
        </div>
        <div id="results-container">
            <!-- Les résultats de recherche seront injectés ici -->
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const resultsModal = document.getElementById('results-modal');
    const resultsContainer = document.getElementById('results-container');
    const mainContent = document.getElementById('main-content');
    const closeModal = document.querySelector('.close');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const searchQuery = formData.get('search');

        mainContent.classList.add('hidden');
        resultsModal.style.display = 'block';

        fetch('finance/rechercher.php?search=' + encodeURIComponent(searchQuery))
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    closeModal.addEventListener('click', function() {
        resultsModal.style.display = 'none';
        mainContent.classList.remove('hidden');
    });

    window.addEventListener('click', function(event) {
        if (event.target === resultsModal) {
            resultsModal.style.display = 'none';
            mainContent.classList.remove('hidden');
        }
    });
});
</script>

<script>
    function toggleModal() {
        const modal = document.getElementById('addOperationModal');
        modal.classList.toggle('hidden');
    }
</script>

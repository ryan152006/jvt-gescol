<?php
require '../../../../Traitement/connexion.php';

if (isset($_GET['id'])) {
    $operation_id = $_GET['id'];

    // Récupération des détails de l'opération à modifier
    $operation_query = "SELECT id, date, libelle, description, categorie, montant FROM finance WHERE id = :id";
    $stmt = $conn->prepare($operation_query);
    $stmt->bindParam(':id', $operation_id, PDO::PARAM_INT);
    $stmt->execute();
    $operation = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$operation) {
        echo "Opération non trouvée.";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Mise à jour de l'opération
        $libelle = $_POST['libelle'];
        $description = $_POST['description'];
        $categorie = $_POST['categorie'];
        $montant = $_POST['montant'];

        $update_query = "UPDATE finance SET libelle = :libelle, description = :description, categorie = :categorie, montant = :montant WHERE id = :id";
        $stmt = $conn->prepare($update_query);
        $stmt->bindParam(':libelle', $libelle);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':categorie', $categorie);
        $stmt->bindParam(':montant', $montant);
        $stmt->bindParam(':id', $operation_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "Opération mise à jour avec succès.";
            header('Location: consulter.php?id=' . $operation_id);
            exit;
        } else {
            echo "Erreur lors de la mise à jour.";
        }
    }
} else {
    echo "ID d'opération manquant.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../../../../Style/categorie.css">
    <title>Modification de l'Opération</title>
</head>
<body class="bg-gray-100">

    <div class="max-w-4xl mx-auto mt-4 p-6 bg-white rounded shadow-lg">
        <div class="mb-4">
            <h2 class="text-xl font-bold text-blue-500 mb-2">Modifier l'Opération Financière</h2>
            <p class="text-gray-600 text-md mb-2">Utilisez le formulaire ci-dessous pour modifier les détails de l'opération.</p>
        </div>

        <form action="" method="POST" class="space-y-2">
            <div class="mb-2">
                <label for="libelle" class="block text-sm font-medium text-gray-700">Libellé</label>
                <input type="text" name="libelle" id="libelle" value="<?php echo htmlspecialchars($operation['libelle']); ?>" class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md focus:ring focus:ring-blue-200 focus:outline-none" required>
            </div>

            <div class="mb-2">
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md focus:ring focus:ring-blue-200 focus:outline-none" rows="4" required><?php echo htmlspecialchars($operation['description']); ?></textarea>
            </div>

            <div class="mb-2">
                <label for="categorie" class="block text-sm font-medium text-gray-700">Catégorie</label>
                <select name="categorie" id="categorie" class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md focus:ring focus:ring-blue-200 focus:outline-none" required>
                    <option value="recette" <?php echo ($operation['categorie'] == 'recette') ? 'selected' : ''; ?>>Recette</option>
                    <option value="depense" <?php echo ($operation['categorie'] == 'depense') ? 'selected' : ''; ?>>Dépense</option>
                </select>
            </div>

            <div class="mb-2">
                <label for="montant" class="block text-sm font-medium text-gray-700">Montant (Fcfa)</label>
                <input type="number" step="0.01" name="montant" id="montant" value="<?php echo htmlspecialchars($operation['montant']); ?>" class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md focus:ring focus:ring-blue-200 focus:outline-none" required>
            </div>

            <div class="flex justify-between items-center">
                <a href="../finance.php?id=<?php echo $operation_id; ?>" class="text-sm text-gray-600 hover:underline">Retour</a>
                <div>
                    
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded">Modifier</button>
                </div>
            </div>
        </form>
    </div>

</body>
</html>

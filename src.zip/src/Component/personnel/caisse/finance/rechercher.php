<?php
require '../../../../Traitement/connexion.php'; // Assurez-vous que ce fichier établit la connexion à la base de données

$search = isset($_GET['search']) ? $_GET['search'] : '';

$query = "SELECT id, date, libelle, description, categorie, montant FROM finance
          WHERE libelle LIKE :search AND id != 1 ORDER BY date asc";
$stmt = $conn->prepare($query);
$stmt->execute(['search' => '%' . $search . '%']);
$operations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="mx-auto w-full md:w-auto overflow-x-auto justify-center items-center left-0 top-0 py-4 scrollable-modal">
    <div class="w-full md:w-auto flex flex-col space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
        <div class="py-3 overflow-x-auto justify-center items-center space-y-4">
            <span class="border border-blue-500 rounded p-2 text-xl md:text-3xl text-white text-center justify-center items-center flex font-semibold mx-auto py-4">Résultats de la Recherche</span>
            <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-gray-50 border-b text-xs text-gray-700 ">
                <tr>
                    <th class="px-2  md:px-4 py-3">Date</th>
                    <th class="px-2  md:px-4 py-3">Libellé</th>
                    <th class="px-2  md:px-4 py-3">Description</th>
                    <th class="px-2  md:px-4 py-3">Catégorie</th>
                    <th class="px-2  md:px-4 py-3">Montant</th>
                    <th class="px-2  md:px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($operations as $op): ?>
                    <tr class="bg-white border-b hover:bg-gray-50">
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['date']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['libelle']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['description']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo htmlspecialchars($op['categorie']); ?></td>
                        <td class="px-2 md:px-4 truncate max-w-[10rem] py-3 text-center"><?php echo number_format($op['montant'], 2, ',', ' '); ?> Fcfa</td>
                        <td class="px-2 md:px-4 py-3 text-center flex space-x-2">
                            <a href="finance/modifier.php?id=<?php echo $op['id']; ?>" class="text-green-500 text-center hover:underline">Modifier</a>
                            <a href="../../../Traitement/caisse/finance/supprimer.php?id=<?php echo $op['id']; ?>" class="text-red-500 text-center hover:underline" onclick="return confirm('Voulez-vous vraiment supprimer cette opération ?');">Supprimer</a>
                            <a href="finance/consulter.php?id=<?php echo $op['id']; ?>" class="text-blue-500 text-center hover:underline">Consulter</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
